/*
 * disksim_org_repair_ckg.c
 *
 *  Created on: Dec 17, 2015
 *      Author: zzytgx
 */

#include <string.h>

#include "disksim_logorg.h"
extern int logorg_get_flag_is_rebuilding();
extern int logorg_stop_rebuild();
extern int logorg_start_rebuilding_set_flag();
extern int __check_id_appear_in_know_char_list(char *acList, int nList_len,
        int id);

void logorg_init_hot_spare_drive_stripe(struct logorg *stpLogorg, int logorgnum)
{
	org_ckg_hot_spare_map *stpHot_spare_drive_stripe;
	stpHot_spare_drive_stripe = &(stpLogorg->stRebuild_event_fsm.stHot_spare_drive_stripes );

	stpLogorg->stRebuild_event_fsm. nCurrent_id_hot_spare_drive_stripe = 0;
	int ss, dd; // ss for stripe-id, dd for drive-id
	int iCurr_hot_spare_id;
	iCurr_hot_spare_id = 0;
	int iFlag_drive_is_rebuild;

	for(ss = stpLogorg->nTotal_active_stripes_per_zone; ss < stpLogorg->nTotal_stripes_per_zone; ss++)
	{
		for(dd = 0; dd< stpLogorg->actualnumdisks; dd++)
		{
			iFlag_drive_is_rebuild = 0;
			if(stpLogorg->nTotal_drive_to_rebuild == 1)
			{
				if(dd == stpLogorg->iNode_id_org_rebuild)
				{
					iFlag_drive_is_rebuild = 1;
				}
			}
			else if(stpLogorg->nTotal_drive_to_rebuild >= 2)
			{
				iFlag_drive_is_rebuild = logorg_check_id_in_rebuild_list(stpLogorg , dd);
			}
			else
			{
				iFlag_drive_is_rebuild = 0;
			}

			if(iFlag_drive_is_rebuild == 0)
			{
				stpHot_spare_drive_stripe->anDrive_id_per_hot_spare[iCurr_hot_spare_id] = dd;
				stpHot_spare_drive_stripe->anStripe_id_hot_spare[iCurr_hot_spare_id] = ss;
				iCurr_hot_spare_id ++;
				stpHot_spare_drive_stripe->nTotal_drive_stripes = iCurr_hot_spare_id;

				if(iCurr_hot_spare_id >= MAX_NUM_DRIVE_STRIPE_PER_HOT_SPARE)
				{
					return;
				}

			}
		}
	}
}

int logorg_find_next_drv_stripe_in_hot_spare(org_ckg_hot_spare_map *stpHot_spare_drive_stripe,
		org_node_rebuild_event_fsm *stpRebuild_one_node_fsm, // int nCurr_id_hot_spare_drv_stripe_unit,
		struct logorg *stpLogorg
		)
{
	//org_node_rebuild_event_fsm *stpRebuild_one_node_fsm = &stpLogorg->stRebuild_event_fsm;
	int nCurr_id_hot_spare_drv_stripe_unit =
			stpRebuild_one_node_fsm->nCurrent_id_hot_spare_drive_stripe;
	org_rebuild_ckg_list_per_zone *stpCurrend_rebuild_ckg_per_zone =
			stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;
	org_chunk_group_map *stpCurrent_repair_ckg =
			stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg;

	int iRet_id_drv_stripe = -1;

	int nCkg_rebuild_id = stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_id;
	int ii, cc, iFlag_found_valid_hot_spare_drv_stripe = 0, iCurr_drv_id;

	for(ii = 0; ii<stpHot_spare_drive_stripe->nTotal_drive_stripes; ii++)
	{
		iCurr_drv_id =
				stpHot_spare_drive_stripe->anDrive_id_per_hot_spare[nCurr_id_hot_spare_drv_stripe_unit];

		cc = 0;
		while(cc < stpLogorg->nNum_drives_per_ckg)
		{
			iFlag_found_valid_hot_spare_drv_stripe = 1;
			if(stpCurrent_repair_ckg ->anDrive_id_per_ckg[cc] == iCurr_drv_id)
			{
				iFlag_found_valid_hot_spare_drv_stripe = 0;
			}
			cc ++;
		}
		if(iFlag_found_valid_hot_spare_drv_stripe == 1)
		{
			iRet_id_drv_stripe = nCurr_id_hot_spare_drv_stripe_unit;
			stpRebuild_one_node_fsm->nCurrent_id_hot_spare_drive_stripe =
					iRet_id_drv_stripe + 1;
			if(stpRebuild_one_node_fsm->nCurrent_id_hot_spare_drive_stripe
					>= stpHot_spare_drive_stripe->nTotal_drive_stripes)
			{
//				iRet_id_drv_stripe = 0;
				stpRebuild_one_node_fsm->nCurrent_id_hot_spare_drive_stripe = 0;
			}
			break;
		}
		else
		{
			nCurr_id_hot_spare_drv_stripe_unit ++;
			if(nCurr_id_hot_spare_drv_stripe_unit >= stpHot_spare_drive_stripe->nTotal_drive_stripes)
			{
				nCurr_id_hot_spare_drv_stripe_unit = 0;
			}
		}
	}

	return iRet_id_drv_stripe;
}


void logorg_decluster_init_hot_spare_all_zones(logorg *stpLogorg)
{
org_ckg_hot_spare_map *stpHot_spare_drive_stripe;
stpHot_spare_drive_stripe = &(stpLogorg->stRebuild_event_fsm.stHot_spare_drive_stripes );
org_node_rebuild_event_fsm *stpRebuild_one_node_fsm = &stpLogorg->stRebuild_event_fsm;
org_rebuild_ckg_list_per_zone *stpCurrend_rebuild_ckg_per_zone =
		stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;
org_hot_spare_mapping_per_zone_ckg * astHot_spare_mapping_per_zone_ckg = stpLogorg->astHot_spare_mapping_per_zone_ckg[0];
int nCkg_rebuild_count;
int zz;
int iDev_org_id;
int iNew_id_found_hot_spare_drv_stripe;
int iHot_spare_drv_id_in_org;
static int nTotal_active_ckgs_per_zone = stpLogorg->nTotal_active_ckgs_per_zone;
int iCkg_id;
int nTotal_drv_failure_in_ckg;
    for(zz = 0; zz<stpLogorg->nTotal_stripes_zones_to_rebuild; zz++)
    {
    	for(nCkg_rebuild_count = 0; nCkg_rebuild_count < stpLogorg->nTotal_ckg_rebuild_per_zone; nCkg_rebuild_count ++)
    	{
    		nTotal_drv_failure_in_ckg = 0;
    		for(int dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
    		{
    			iDev_org_id = stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anDrive_id_per_ckg[dd];
				if(logorg_check_id_in_rebuild_list(stpLogorg, iDev_org_id))
				{
	//				find a drv-stripe in the hot-spare
					   iNew_id_found_hot_spare_drv_stripe =
							   logorg_find_next_drv_stripe_in_hot_spare(&(stpRebuild_one_node_fsm->stHot_spare_drive_stripes),
									   stpRebuild_one_node_fsm,
									   stpLogorg);
					   if(iNew_id_found_hot_spare_drv_stripe >= 0)
					   {
						   iHot_spare_drv_id_in_org =
								   stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anDrive_id_per_hot_spare[iNew_id_found_hot_spare_drv_stripe];
						   iCkg_id = stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_id;

						   astHot_spare_mapping_per_zone_ckg[zz * nTotal_active_ckgs_per_zone + iCkg_id].nTotal_drv_failure
						   = nTotal_drv_failure_in_ckg;

						   astHot_spare_mapping_per_zone_ckg[zz * nTotal_active_ckgs_per_zone + iCkg_id].aiFailure_drv_id_in_org[nTotal_drv_failure_in_ckg]
						            = iDev_org_id;
						   astHot_spare_mapping_per_zone_ckg[zz * nTotal_active_ckgs_per_zone + iCkg_id].aiHot_spare_drv_id_in_org[nTotal_drv_failure_in_ckg]
						            = iHot_spare_drv_id_in_org;

						   astHot_spare_mapping_per_zone_ckg[zz * nTotal_active_ckgs_per_zone + iCkg_id].aiHot_spare_drv_id_global[nTotal_drv_failure_in_ckg]
							        =   stpRebuild_one_node_fsm->anDev_id_per_org[iHot_spare_drv_id_in_org];
						   astHot_spare_mapping_per_zone_ckg[zz * nTotal_active_ckgs_per_zone + iCkg_id].aiHot_spare_tripe_id[nTotal_drv_failure_in_ckg]
						            = stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anStripe_id_hot_spare[iNew_id_found_hot_spare_drv_stripe]
								          + (stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg * stpLogorg->nTotal_stripes_per_zone) ;

						   nTotal_drv_failure_in_ckg ++;

					   }
					   else
					   {
						   fprintf(stderr, "File: %s, line: %d, func:%s, Error cannot find a hot spare drive-stripe unit to repair. \n",
								   __FILE__, __LINE__, __func__);
						   exit(0);
					   }
				}
    		}
			stpCurrend_rebuild_ckg_per_zone = stpCurrend_rebuild_ckg_per_zone->stpNext_list_item;
    	}
    }

    stpRebuild_one_node_fsm->nCurrent_id_hot_spare_drive_stripe = 0;

}

void logorg_repair_ckg_nodes_by_hot_spare_fsm(struct logorg *stpLogorg, int logorgnum)
{
	switch(stpLogorg->stpChunk_group_mapping->nType_raid)
	{
	case 5:
		logorg_repair_ckg_one_node_by_hot_spare_fsm(stpLogorg, logorgnum);
		break;
	case 6:
		break;
	case __ORG_DECLUSTER_GENERAL_REED_SOLOMON__:
		logorg_repair_ckg_reed_solomon_nodes_by_hot_spare_fsm(stpLogorg, logorgnum);
		break;
	case __ORG_DECLUSTER_LOCAL_RECONSTRUCTION__:
		logorg_repair_ckg_local_reconstruct_nodes_by_hot_spare_fsm(stpLogorg, logorgnum);
		break;
	}

}

// for repair by hot-spare, local reconstruct, LRC
void logorg_repair_ckg_local_reconstruct_nodes_by_hot_spare_fsm(struct logorg *stpLogorg, int logorgnum)
{
int dd, ll, lldd;

org_node_rebuild_event_fsm *stpRebuild_one_node_fsm = &stpLogorg->stRebuild_event_fsm;
org_rebuild_ckg_list_per_zone * stpOriginal_rebuild_zone_ckg_list_in_org;

stpOriginal_rebuild_zone_ckg_list_in_org = stpLogorg->stpRebuid_ckg_list_per_zone;
org_rebuild_ckg_list_per_zone *stpCurrend_rebuild_ckg_per_zone =
		stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

int iRebuildNodeId = stpLogorg->iNode_id_org_rebuild;
logorgdev *stpLogorg_dev = stpLogorg->devs;
int nTotal_nodes_read = 0, nNum_drive_rebuild=0;
int iDev_global_id, iDev_org_id;
int iNew_id_found_hot_spare_drv_stripe;
org_parity_pattern * stpCurr_parity_pattern;
org_chunk_group_map *stpCurr_ckg;
int iFlag_use_node_for_read;
org_local_parity *stpCurr_local_parity;

	// Cond-1: initialization of a new rebuild
	if(stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg == 0)
	{
		// initialize
		   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg =
				   (int)(stpLogorg->dStarting_stripe_rebuild_percentage * stpLogorg->nTotal_ckg_zones );
		   stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg = stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg;

		   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				   stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anStripe_id_per_ckg[0]  +
					( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
							stpLogorg->nTotal_stripes_per_zone);
		   stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				   stpLogorg->stpRebuid_ckg_list_per_zone;
		   stpCurrend_rebuild_ckg_per_zone =
		   			stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

           logorg_decluster_init_hot_spare_all_zones(stpLogorg); // @021

		//
		   stpLogorg_dev = stpLogorg->devs;
		   nTotal_nodes_read = 0; nNum_drive_rebuild=0;

		   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg = stpLogorg->nTotal_stripes_zones_to_rebuild;

		   stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				   stpOriginal_rebuild_zone_ckg_list_in_org->nCkg_rebuild_id;

		   stpCurr_parity_pattern =
				   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->stpCurr_parity_pattern;

		   for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		   {
			   iFlag_use_node_for_read = 0;
			   iDev_org_id = stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			   if(logorg_check_id_in_rebuild_list(stpLogorg, iDev_org_id)) // iDev_org_id == iRebuildNodeId)
			   {

				   iNew_id_found_hot_spare_drv_stripe =
						   logorg_find_next_drv_stripe_in_hot_spare(&(stpRebuild_one_node_fsm->stHot_spare_drive_stripes),
								   stpRebuild_one_node_fsm,
								   stpLogorg);
				   if(iNew_id_found_hot_spare_drv_stripe >= 0)
				   {
					   //stpRebuild_one_node_fsm->nCurrent_id_hot_spare_drive_stripe = iNew_id_found_hot_spare_drv_stripe;
					   stpRebuild_one_node_fsm->anDevno_rebuild[nNum_drive_rebuild] =
							   stpRebuild_one_node_fsm->anDev_id_per_org[stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anDrive_id_per_hot_spare[iNew_id_found_hot_spare_drv_stripe]];
					   stpRebuild_one_node_fsm->anStripe_id_repair_from_hot_spare[nNum_drive_rebuild] =
							   stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anStripe_id_hot_spare[iNew_id_found_hot_spare_drv_stripe];
					   nNum_drive_rebuild ++;

				   }
				   else
				   {
					   fprintf(stderr, "File: %s, line: %d, func:%s, Error cannot find a hot spare drive-stripe unit to repair. \n",
							   __FILE__, __LINE__, __func__);
					   exit(0);
				   }
			   }
			   else
			   {
				   if(__check_id_appear_in_know_int_list(
						   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anData_list_node_id,
						   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->nNum_data_nodes,
						   iDev_org_id) == 0)
				   {
					   // for a parity node
					   if(__check_id_appear_in_know_int_list(
							   stpOriginal_rebuild_zone_ckg_list_in_org->anParity_node_read_list,
							   stpOriginal_rebuild_zone_ckg_list_in_org->nTotal_parity_read,
							   iDev_org_id) == 1)
					   {
						   iFlag_use_node_for_read = 1;
					   }
				   }
				   else
				   {
					   // further check if any global parity failure
					   if(stpCurrend_rebuild_ckg_per_zone->cFlag_has_failure_in_global_parity == 1)
					   {
						   iFlag_use_node_for_read = 1;
					   }

					   if(iFlag_use_node_for_read == 0)
					   {
						   // for a data node in local parity,
						   // need to check any failure in this local parity group
						   stpCurr_local_parity = stpCurr_parity_pattern->stpLocal_parity_group;
						   for(ll=0; ll < stpCurr_parity_pattern->nNum_local_parity_nodes; ll++)
						   {
							   if(stpCurrend_rebuild_ckg_per_zone->anFailure_nodes_per_local_parity[ll] >= 1)
							   {
								   for(lldd = 0; lldd< stpCurr_local_parity->nNum_data_in_group; lldd ++)
								   {
									   if(stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[stpCurr_local_parity->aData_nodes[lldd]]
									         ==  iDev_org_id )
									   {
										   iFlag_use_node_for_read = 1;
										   break;
									   }
								   }
								   if(iFlag_use_node_for_read == 1)
								   {
									   break; // ll = stpCurr_parity_pattern->nNum_local_parity_nodes;
								   }
							   }
							   stpCurr_local_parity ++;
						   }
					   }
				   }

				   if(iFlag_use_node_for_read == 1)
				   {
					   stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
							   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
					   nTotal_nodes_read ++;
				   }
			   }
		   }

		   stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		   stpRebuild_one_node_fsm->nNum_drive_rebuild = nNum_drive_rebuild;

		   stpRebuild_one_node_fsm->nTotal_stripes =
				   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg *
				   stpLogorg->nTotal_ckg_rebuild_per_zone;

		   stpRebuild_one_node_fsm->nLBA_end = stpLogorg_dev->nLBA_end;
		   stpCurrend_rebuild_ckg_per_zone = stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

//		   iFlag_org_is_rebuilding = 1;
           logorg_start_rebuilding_set_flag();
	}
	else if(((stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg - stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg == stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg) &&
			stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone >= stpLogorg->nTotal_ckg_rebuild_per_zone)  ||
			(stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg - stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg)> stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg
			)
	{
		   stpRebuild_one_node_fsm->nTotal_stripes = 0;
		   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe = 0;
		   stpLogorg->iNode_id_org_rebuild = -1;

		   logorg_stop_rebuild();
	}

	else if(stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count < stpLogorg->nTotal_ckg_rebuild_per_zone)
	{ // build next ckg within current zone

		stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				stpCurrend_rebuild_ckg_per_zone->stpNext_list_item;
		stpCurrend_rebuild_ckg_per_zone =
				stpCurrend_rebuild_ckg_per_zone->stpNext_list_item;
		stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_id;
		nTotal_nodes_read = 0; nNum_drive_rebuild=0;

		stpCurr_parity_pattern =
					   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->stpCurr_parity_pattern;

		for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		{
			iFlag_use_node_for_read = 0;
			iDev_org_id = stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			if(logorg_check_id_in_rebuild_list(stpLogorg, iDev_org_id)) // iDev_org_id == iRebuildNodeId)
			{
//				find a drv-stripe in the hot-spare
				   iNew_id_found_hot_spare_drv_stripe =
						   logorg_find_next_drv_stripe_in_hot_spare(&(stpRebuild_one_node_fsm->stHot_spare_drive_stripes),
								   stpRebuild_one_node_fsm,
								   stpLogorg);
				   if(iNew_id_found_hot_spare_drv_stripe >= 0)
				   {
//					   stpRebuild_one_node_fsm->nCurrent_id_hot_spare_drive_stripe = iNew_id_found_hot_spare_drv_stripe;
					   stpRebuild_one_node_fsm->anDevno_rebuild[nNum_drive_rebuild] =
							   stpRebuild_one_node_fsm->anDev_id_per_org[stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anDrive_id_per_hot_spare[iNew_id_found_hot_spare_drv_stripe]];
					   stpRebuild_one_node_fsm->anStripe_id_repair_from_hot_spare[nNum_drive_rebuild] =
							   stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anStripe_id_hot_spare[iNew_id_found_hot_spare_drv_stripe]
							          + (stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg * stpLogorg->nTotal_stripes_per_zone) ;

					   nNum_drive_rebuild ++;
				   }
				   else
				   {
					   fprintf(stderr, "File: %s, line: %d, func:%s, Error cannot find a hot spare drive-stripe unit to repair. \n",
							   __FILE__, __LINE__, __func__);
					   exit(0);
				   }
			}
			else
			{
				if(__check_id_appear_in_know_int_list(
						stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anData_list_node_id,
						stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->nNum_data_nodes,
						iDev_org_id) == 0)
				{
					// for a parity node
					if(__check_id_appear_in_know_int_list(
							stpCurrend_rebuild_ckg_per_zone->anParity_node_read_list,
							stpCurrend_rebuild_ckg_per_zone->nTotal_parity_read,
							iDev_org_id) == 1)
					{
						iFlag_use_node_for_read = 1;
					}
				}
				else
				{
				   // further check if any global parity failure
				   if(stpCurrend_rebuild_ckg_per_zone->cFlag_has_failure_in_global_parity == 1)
				   {
					   iFlag_use_node_for_read = 1;
				   }

				   if(iFlag_use_node_for_read == 0)
				   {
						// for a data node in local parity,
						// need to check any failure in this local parity group
						stpCurr_local_parity = stpCurr_parity_pattern->stpLocal_parity_group;
						for(ll=0; ll < stpCurr_parity_pattern->nNum_local_parity_nodes; ll++)
						{
						   if(stpCurrend_rebuild_ckg_per_zone->anFailure_nodes_per_local_parity[ll] >= 1)
						   {
							   for(lldd = 0; lldd< stpCurr_local_parity->nNum_data_in_group; lldd ++)
							   {
								   if(stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[stpCurr_local_parity->aData_nodes[lldd]]
										 ==  iDev_org_id )
								   {
									   iFlag_use_node_for_read = 1;
									   break;
								   }
							   }
							   if(iFlag_use_node_for_read == 1)
							   {
								   break; // ll = stpCurr_parity_pattern->nNum_local_parity_nodes;
							   }
						   }
						   stpCurr_local_parity ++;
						}
				   }
				}

				if(iFlag_use_node_for_read == 1)
				{
					stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
							stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
					nTotal_nodes_read ++;
				}
			}
		}
//		stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg
		stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		stpRebuild_one_node_fsm->nNum_drive_rebuild = nNum_drive_rebuild;
		stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anStripe_id_per_ckg[0] +
				( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
						stpLogorg->nTotal_stripes_per_zone);


	}
	else if(stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count == stpLogorg->nTotal_ckg_rebuild_per_zone)
	{ // build next zone,
		stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg ++;

		//
		stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				stpOriginal_rebuild_zone_ckg_list_in_org->nCkg_rebuild_id;
		stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				stpOriginal_rebuild_zone_ckg_list_in_org; // stpLogorg->stpRebuid_ckg_list_per_zone;
		stpCurrend_rebuild_ckg_per_zone =
					stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;
		nTotal_nodes_read = 0; nNum_drive_rebuild=0;

		stpCurr_parity_pattern =
					   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->stpCurr_parity_pattern;

		for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		{
			iDev_org_id = stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			iFlag_use_node_for_read = 0;

			if(logorg_check_id_in_rebuild_list(stpLogorg, iDev_org_id)) // iDev_org_id == iRebuildNodeId)
			{
				//				find a drv-stripe in the hot-spare
				iNew_id_found_hot_spare_drv_stripe =
						logorg_find_next_drv_stripe_in_hot_spare(&(stpRebuild_one_node_fsm->stHot_spare_drive_stripes),
								stpRebuild_one_node_fsm,
								stpLogorg);
				if(iNew_id_found_hot_spare_drv_stripe >= 0)
				{
//					stpRebuild_one_node_fsm->nCurrent_id_hot_spare_drive_stripe = iNew_id_found_hot_spare_drv_stripe;
					stpRebuild_one_node_fsm->anDevno_rebuild[nNum_drive_rebuild] =
							stpRebuild_one_node_fsm->anDev_id_per_org[stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anDrive_id_per_hot_spare[iNew_id_found_hot_spare_drv_stripe]];
					stpRebuild_one_node_fsm->anStripe_id_repair_from_hot_spare[nNum_drive_rebuild] =
							stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anStripe_id_hot_spare[iNew_id_found_hot_spare_drv_stripe]
							                    + (stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg * stpLogorg->nTotal_stripes_per_zone) ;

					nNum_drive_rebuild ++;
				}
				else
				{
					fprintf(stderr, "File: %s, line: %d, func:%s, Error cannot find a hot spare drive-stripe unit to repair. \n",
							__FILE__, __LINE__, __func__);
					exit(0);
				}

			}
			else
			{
				if(__check_id_appear_in_know_int_list(
						stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anData_list_node_id,
						stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->nNum_data_nodes,
						iDev_org_id) == 0)
				{
					// for a parity node
					if(__check_id_appear_in_know_int_list(
							stpCurrend_rebuild_ckg_per_zone->anParity_node_read_list,
							stpCurrend_rebuild_ckg_per_zone->nTotal_parity_read,
							iDev_org_id) == 1)
					{
						iFlag_use_node_for_read = 1;
					}
				}
				else
				{
				   // further check if any global parity failure
				   if(stpCurrend_rebuild_ckg_per_zone->cFlag_has_failure_in_global_parity == 1)
				   {
					   iFlag_use_node_for_read = 1;
				   }

				   if(iFlag_use_node_for_read == 0)
				   {
						// for a data node in local parity,
						// need to check any failure in this local parity group
						stpCurr_local_parity = stpCurr_parity_pattern->stpLocal_parity_group;
						for(ll=0; ll < stpCurr_parity_pattern->nNum_local_parity_nodes; ll++)
						{
						   if(stpCurrend_rebuild_ckg_per_zone->anFailure_nodes_per_local_parity[ll] >= 1)
						   {
							   for(lldd = 0; lldd< stpCurr_local_parity->nNum_data_in_group; lldd ++)
							   {
								   if(stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[stpCurr_local_parity->aData_nodes[lldd]]
										 ==  iDev_org_id )
								   {
									   iFlag_use_node_for_read = 1;
									   break;
								   }
							   }
							   if(iFlag_use_node_for_read == 1)
							   {
								   break; // ll = stpCurr_parity_pattern->nNum_local_parity_nodes;
							   }
						   }
						   stpCurr_local_parity ++;
						}
				   }
				}

				if(iFlag_use_node_for_read == 1)
				{
					stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
							stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
					nTotal_nodes_read ++;
				}
			}
		}
		stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		stpRebuild_one_node_fsm->nNum_drive_rebuild = nNum_drive_rebuild;
		stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anStripe_id_per_ckg[0] +
				( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
						stpLogorg->nTotal_stripes_per_zone);

	}

	if(	stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count == 1)
		// (stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg % 10) == 1 &&, prompt at the beginning of each zone
	{
	   fprintf(stderr, "%d/(%d, %d, %d)\n",
			   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg, stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg,
			   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg, stpLogorg->nTotal_ckg_zones);
	}


}

// for repair by hot-spare, general RS
void logorg_repair_ckg_reed_solomon_nodes_by_hot_spare_fsm(struct logorg *stpLogorg, int logorgnum)
{
	int dd;

	org_node_rebuild_event_fsm *stpRebuild_one_node_fsm = &stpLogorg->stRebuild_event_fsm;
	org_rebuild_ckg_list_per_zone * stpOriginal_rebuild_zone_ckg_list_in_org;

	stpOriginal_rebuild_zone_ckg_list_in_org = stpLogorg->stpRebuid_ckg_list_per_zone;
	org_rebuild_ckg_list_per_zone *stpCurrend_rebuild_ckg_per_zone =
			stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

	int iRebuildNodeId = stpLogorg->iNode_id_org_rebuild;
	logorgdev *stpLogorg_dev = stpLogorg->devs;
	int nTotal_nodes_read = 0, nNum_drive_rebuild=0;
	int iDev_global_id, iDev_org_id;
	int iNew_id_found_hot_spare_drv_stripe;
	org_parity_pattern * stpCurr_parity_pattern;
	org_chunk_group_map *stpCurr_ckg;
	int iFlag_use_node_for_read;

	// Cond-1: initialization of a new rebuild
	if(stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg == 0)
	{
		   stpLogorg_dev = stpLogorg->devs;
		   nTotal_nodes_read = 0; nNum_drive_rebuild=0;

		   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg = stpLogorg->nTotal_stripes_zones_to_rebuild;

		   stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				   stpOriginal_rebuild_zone_ckg_list_in_org->nCkg_rebuild_id;
		   stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				   stpLogorg->stpRebuid_ckg_list_per_zone;
		   stpCurrend_rebuild_ckg_per_zone =
		   			stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

		   stpCurr_parity_pattern =
				   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->stpCurr_parity_pattern;

		   for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		   {
			   iFlag_use_node_for_read = 0;
			   iDev_org_id = stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			   if(logorg_check_id_in_rebuild_list(stpLogorg, iDev_org_id)) // iDev_org_id == iRebuildNodeId)
			   {

				   iNew_id_found_hot_spare_drv_stripe =
						   logorg_find_next_drv_stripe_in_hot_spare(&(stpRebuild_one_node_fsm->stHot_spare_drive_stripes),
								   stpRebuild_one_node_fsm,
								   stpLogorg);
				   if(iNew_id_found_hot_spare_drv_stripe >= 0)
				   {
					   //stpRebuild_one_node_fsm->nCurrent_id_hot_spare_drive_stripe = iNew_id_found_hot_spare_drv_stripe;
					   stpRebuild_one_node_fsm->anDevno_rebuild[nNum_drive_rebuild] =
							   stpRebuild_one_node_fsm->anDev_id_per_org[stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anDrive_id_per_hot_spare[iNew_id_found_hot_spare_drv_stripe]];
					   stpRebuild_one_node_fsm->anStripe_id_repair_from_hot_spare[nNum_drive_rebuild] =
							   stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anStripe_id_hot_spare[iNew_id_found_hot_spare_drv_stripe];
					   nNum_drive_rebuild ++;

				   }
				   else
				   {
					   fprintf(stderr, "File: %s, line: %d, func:%s, Error cannot find a hot spare drive-stripe unit to repair. \n",
							   __FILE__, __LINE__, __func__);
					   exit(0);
				   }
			   }
			   else
			   {
				   if(__check_id_appear_in_know_int_list(
						   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anData_list_node_id, //
						   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->nNum_data_nodes, 	//
						   iDev_org_id) == 1)
				   {
					   iFlag_use_node_for_read = 1;
				   }
				   else
				   {
					   if(__check_id_appear_in_know_int_list(
							   stpOriginal_rebuild_zone_ckg_list_in_org->anParity_node_read_list,
							   stpOriginal_rebuild_zone_ckg_list_in_org->nTotal_parity_read,
							   iDev_org_id) == 1)
					   {
						   iFlag_use_node_for_read = 1;
					   }
				   }

				   if(iFlag_use_node_for_read == 1)
				   {
					   stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
							   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
					   nTotal_nodes_read ++;
				   }
			   }
		   }
		   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg =
				   (int)(stpLogorg->dStarting_stripe_rebuild_percentage * stpLogorg->nTotal_ckg_zones );
		   stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg = stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg;

		   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				   stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anStripe_id_per_ckg[0]  +
					( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
							stpLogorg->nTotal_stripes_per_zone);

		   stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		   stpRebuild_one_node_fsm->nNum_drive_rebuild = nNum_drive_rebuild;

		   stpRebuild_one_node_fsm->nTotal_stripes =
				   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg *
				   stpLogorg->nTotal_ckg_rebuild_per_zone;

		   stpRebuild_one_node_fsm->nLBA_end = stpLogorg_dev->nLBA_end;
		   stpCurrend_rebuild_ckg_per_zone = stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

           logorg_decluster_init_hot_spare_all_zones(stpLogorg); // @021

//		   iFlag_org_is_rebuilding = 1;
           logorg_start_rebuilding_set_flag();
	}
	else if(((stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg - stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg == stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg) &&
			stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone >= stpLogorg->nTotal_ckg_rebuild_per_zone)  ||
			(stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg - stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg)> stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg
			)
	{
		   stpRebuild_one_node_fsm->nTotal_stripes = 0;
		   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe = 0;
		   stpLogorg->iNode_id_org_rebuild = -1;

		   logorg_stop_rebuild();
	}

	else if(stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count < stpLogorg->nTotal_ckg_rebuild_per_zone)
	{ // build next ckg within current zone

		stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				stpCurrend_rebuild_ckg_per_zone->stpNext_list_item;
		stpCurrend_rebuild_ckg_per_zone =
				stpCurrend_rebuild_ckg_per_zone->stpNext_list_item;
		stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_id;
		nTotal_nodes_read = 0; nNum_drive_rebuild=0;

		for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		{
			iFlag_use_node_for_read = 0;
			iDev_org_id = stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			if(logorg_check_id_in_rebuild_list(stpLogorg, iDev_org_id)) // iDev_org_id == iRebuildNodeId)
			{
//				find a drv-stripe in the hot-spare
				   iNew_id_found_hot_spare_drv_stripe =
						   logorg_find_next_drv_stripe_in_hot_spare(&(stpRebuild_one_node_fsm->stHot_spare_drive_stripes),
								   stpRebuild_one_node_fsm,
								   stpLogorg);
				   if(iNew_id_found_hot_spare_drv_stripe >= 0)
				   {
//					   stpRebuild_one_node_fsm->nCurrent_id_hot_spare_drive_stripe = iNew_id_found_hot_spare_drv_stripe;
					   stpRebuild_one_node_fsm->anDevno_rebuild[nNum_drive_rebuild] =
							   stpRebuild_one_node_fsm->anDev_id_per_org[stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anDrive_id_per_hot_spare[iNew_id_found_hot_spare_drv_stripe]];
					   stpRebuild_one_node_fsm->anStripe_id_repair_from_hot_spare[nNum_drive_rebuild] =
							   stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anStripe_id_hot_spare[iNew_id_found_hot_spare_drv_stripe]
							          + (stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg * stpLogorg->nTotal_stripes_per_zone) ;

					   nNum_drive_rebuild ++;
				   }
				   else
				   {
					   fprintf(stderr, "File: %s, line: %d, func:%s, Error cannot find a hot spare drive-stripe unit to repair. \n",
							   __FILE__, __LINE__, __func__);
					   exit(0);
				   }
			}
			else
			{
				if(__check_id_appear_in_know_int_list(
						stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anData_list_node_id,
						stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->nNum_data_nodes,
						iDev_org_id) == 1)
				{
					iFlag_use_node_for_read = 1;
				}
				else
				{
					if(__check_id_appear_in_know_int_list(
							stpCurrend_rebuild_ckg_per_zone->anParity_node_read_list,
							stpCurrend_rebuild_ckg_per_zone->nTotal_parity_read,
							iDev_org_id) == 1)
					{
						iFlag_use_node_for_read = 1;
					}
				}
				if(iFlag_use_node_for_read == 1)
				{
					stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
							stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
					nTotal_nodes_read ++;
				}
			}
		}
//		stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg
		stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		stpRebuild_one_node_fsm->nNum_drive_rebuild = nNum_drive_rebuild;
		stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anStripe_id_per_ckg[0] +
				( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
						stpLogorg->nTotal_stripes_per_zone);


	}
	else if(stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count == stpLogorg->nTotal_ckg_rebuild_per_zone)
	{ // build next zone,
		stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg ++;

		//
		stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				stpOriginal_rebuild_zone_ckg_list_in_org->nCkg_rebuild_id;
		stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				stpOriginal_rebuild_zone_ckg_list_in_org; // stpLogorg->stpRebuid_ckg_list_per_zone;
		stpCurrend_rebuild_ckg_per_zone =
					stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;
		nTotal_nodes_read = 0; nNum_drive_rebuild=0;

		for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		{
			iDev_org_id = stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			iFlag_use_node_for_read = 0;

			if(logorg_check_id_in_rebuild_list(stpLogorg, iDev_org_id)) // iDev_org_id == iRebuildNodeId)
			{
				//				find a drv-stripe in the hot-spare
				iNew_id_found_hot_spare_drv_stripe =
						logorg_find_next_drv_stripe_in_hot_spare(&(stpRebuild_one_node_fsm->stHot_spare_drive_stripes),
								stpRebuild_one_node_fsm,
								stpLogorg);
				if(iNew_id_found_hot_spare_drv_stripe >= 0)
				{
//					stpRebuild_one_node_fsm->nCurrent_id_hot_spare_drive_stripe = iNew_id_found_hot_spare_drv_stripe;
					stpRebuild_one_node_fsm->anDevno_rebuild[nNum_drive_rebuild] =
							stpRebuild_one_node_fsm->anDev_id_per_org[stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anDrive_id_per_hot_spare[iNew_id_found_hot_spare_drv_stripe]];
					stpRebuild_one_node_fsm->anStripe_id_repair_from_hot_spare[nNum_drive_rebuild] =
							stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anStripe_id_hot_spare[iNew_id_found_hot_spare_drv_stripe]
							                    + (stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg * stpLogorg->nTotal_stripes_per_zone) ;

					nNum_drive_rebuild ++;
				}
				else
				{
					fprintf(stderr, "File: %s, line: %d, func:%s, Error cannot find a hot spare drive-stripe unit to repair. \n",
							__FILE__, __LINE__, __func__);
					exit(0);
				}

			}
			else
			{
				if(__check_id_appear_in_know_int_list(
						stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anData_list_node_id,
						stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->nNum_data_nodes,
						iDev_org_id) == 1)
				{
					iFlag_use_node_for_read = 1;
				}
				else
				{
					if(__check_id_appear_in_know_int_list(
							stpCurrend_rebuild_ckg_per_zone->anParity_node_read_list,
							stpCurrend_rebuild_ckg_per_zone->nTotal_parity_read,
							iDev_org_id) == 1)
					{
						iFlag_use_node_for_read = 1;
					}
				}

				if(iFlag_use_node_for_read == 1)
				{
					stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
							stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
					nTotal_nodes_read ++;
				}
			}
		}
		stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		stpRebuild_one_node_fsm->nNum_drive_rebuild = nNum_drive_rebuild;
		stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anStripe_id_per_ckg[0] +
				( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
						stpLogorg->nTotal_stripes_per_zone);

	}

	if(	stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count == 1)
		// (stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg % 10) == 1 &&, prompt at the beginning of each zone
	{
	   fprintf(stderr, "%d/(%d, %d, %d)\n",
			   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg, stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg,
			   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg, stpLogorg->nTotal_ckg_zones);
	}

}

// repair one node for decluster-RAID5 only
void logorg_repair_ckg_one_node_by_hot_spare_fsm(struct logorg *stpLogorg, int logorgnum)
{
	int dd;

	org_node_rebuild_event_fsm *stpRebuild_one_node_fsm = &stpLogorg->stRebuild_event_fsm;
	org_rebuild_ckg_list_per_zone * stpOriginal_rebuild_zone_ckg_list_in_org;

	stpOriginal_rebuild_zone_ckg_list_in_org = stpLogorg->stpRebuid_ckg_list_per_zone;
	org_rebuild_ckg_list_per_zone *stpCurrend_rebuild_ckg_per_zone =
			stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

	int iRebuildNodeId = stpLogorg->iNode_id_org_rebuild;
	logorgdev *stpLogorg_dev = stpLogorg->devs;
	int nTotal_nodes_read = 0;
	int iDev_global_id, iDev_org_id;
	int iNew_id_found_hot_spare_drv_stripe;

	if(stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg == 769)
	{
		fprintf(stderr, "Debug: %d\n", stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg);
	}

	// Cond-1: initialization of a new rebuild
	if(stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg == 0)
	{
//		   iRebuildNodeId = stpLogorg->iNode_id_org_rebuild;
		   stpLogorg_dev = stpLogorg->devs;
		   nTotal_nodes_read = 0;

		   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg = stpLogorg->nTotal_stripes_zones_to_rebuild;
//				   * stpLogorg->nTotal_ckg_rebuild_per_zone;
				   //stpLogorg->nTotal_ckg_zones;
//				   stpLogorg->aiCkg_id_rebuild_per_zone[0];

		   stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				   stpOriginal_rebuild_zone_ckg_list_in_org->nCkg_rebuild_id;
		   stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				   stpLogorg->stpRebuid_ckg_list_per_zone;

		   for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		   {
			   iDev_org_id = stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			   if(iDev_org_id == iRebuildNodeId) // stpLogorg->iNode_id_org_rebuild)
			   {
//				   stpRebuild_one_node_fsm->iDevno_rebuild =
//						   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
				   iNew_id_found_hot_spare_drv_stripe =
						   logorg_find_next_drv_stripe_in_hot_spare(&(stpRebuild_one_node_fsm->stHot_spare_drive_stripes),
								   stpRebuild_one_node_fsm,
								   stpLogorg);
				   if(iNew_id_found_hot_spare_drv_stripe >= 0)
				   {
					   //stpRebuild_one_node_fsm->nCurrent_id_hot_spare_drive_stripe = iNew_id_found_hot_spare_drv_stripe;
					   stpRebuild_one_node_fsm->iDevno_rebuild =
							   stpRebuild_one_node_fsm->anDev_id_per_org[stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anDrive_id_per_hot_spare[iNew_id_found_hot_spare_drv_stripe]];
					   stpRebuild_one_node_fsm->nStripe_id_repair_from_hot_spare =
							   stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anStripe_id_hot_spare[iNew_id_found_hot_spare_drv_stripe];

				   }
				   else
				   {
					   fprintf(stderr, "File: %s, line: %d, func:%s, Error cannot find a hot spare drive-stripe unit to repair. \n",
							   __FILE__, __LINE__, __func__);
					   exit(0);
				   }
			   }
			   else
			   {
				   stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
						   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
				   nTotal_nodes_read ++;
			   }
		   }
		   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg =
				   (int)(stpLogorg->dStarting_stripe_rebuild_percentage * stpLogorg->nTotal_ckg_zones );
		   stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg = stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg;

		   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				   stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anStripe_id_per_ckg[0]  +
					( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
							stpLogorg->nTotal_stripes_per_zone);

		   stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;

		   stpRebuild_one_node_fsm->nTotal_stripes =
				   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg *
				   stpLogorg->nTotal_ckg_rebuild_per_zone;

		   stpRebuild_one_node_fsm->nLBA_end = stpLogorg_dev->nLBA_end;
		   stpCurrend_rebuild_ckg_per_zone = stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

           logorg_decluster_init_hot_spare_all_zones(stpLogorg); // @021

           logorg_start_rebuilding_set_flag();  //		   iFlag_org_is_rebuilding = 1;
	}
	else if(((stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg - stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg == stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg) &&
			stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone >= stpLogorg->nTotal_ckg_rebuild_per_zone)  ||
			(stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg - stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg)> stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg
			)
	{
		   stpRebuild_one_node_fsm->nTotal_stripes = 0;
		   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe = 0;
		   stpLogorg->iNode_id_org_rebuild = -1;

		   // disksim_simstop();
		   logorg_stop_rebuild(); //iFlag_org_is_rebuilding = 0;

	}

	else if(stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count < stpLogorg->nTotal_ckg_rebuild_per_zone)
	{ // build next ckg within current zone

		stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				stpCurrend_rebuild_ckg_per_zone->stpNext_list_item;
		stpCurrend_rebuild_ckg_per_zone =
				stpCurrend_rebuild_ckg_per_zone->stpNext_list_item;
		stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_id;

		for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		{
			iDev_org_id = stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			if(iDev_org_id == iRebuildNodeId) // stpLogorg->iNode_id_org_rebuild)
			{
//				find a drv-stripe in the hot-spare
				   iNew_id_found_hot_spare_drv_stripe =
						   logorg_find_next_drv_stripe_in_hot_spare(&(stpRebuild_one_node_fsm->stHot_spare_drive_stripes),
								   stpRebuild_one_node_fsm,
								   stpLogorg);
				   if(iNew_id_found_hot_spare_drv_stripe >= 0)
				   {
//					   stpRebuild_one_node_fsm->nCurrent_id_hot_spare_drive_stripe = iNew_id_found_hot_spare_drv_stripe;
					   stpRebuild_one_node_fsm->iDevno_rebuild =
							   stpRebuild_one_node_fsm->anDev_id_per_org[stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anDrive_id_per_hot_spare[iNew_id_found_hot_spare_drv_stripe]];
					   stpRebuild_one_node_fsm->nStripe_id_repair_from_hot_spare =
							   stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anStripe_id_hot_spare[iNew_id_found_hot_spare_drv_stripe]
							          + (stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg * stpLogorg->nTotal_stripes_per_zone) ;

				   }
				   else
				   {
					   fprintf(stderr, "File: %s, line: %d, func:%s, Error cannot find a hot spare drive-stripe unit to repair. \n",
							   __FILE__, __LINE__, __func__);
					   exit(0);
				   }
			}
			else
			{
				stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
						stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
				nTotal_nodes_read ++;
			}
		}
//		stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg
		stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anStripe_id_per_ckg[0] +
				( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
						stpLogorg->nTotal_stripes_per_zone);


	}
	else if(stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count == stpLogorg->nTotal_ckg_rebuild_per_zone)
	{ // build next zone,
		stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg ++;

		//
		stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				stpOriginal_rebuild_zone_ckg_list_in_org->nCkg_rebuild_id;
		stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				stpOriginal_rebuild_zone_ckg_list_in_org; // stpLogorg->stpRebuid_ckg_list_per_zone;
		stpCurrend_rebuild_ckg_per_zone =
					stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

		for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		{
			iDev_org_id = stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			if(iDev_org_id == iRebuildNodeId) // stpLogorg->iNode_id_org_rebuild)
			{
				//				find a drv-stripe in the hot-spare
				iNew_id_found_hot_spare_drv_stripe =
						logorg_find_next_drv_stripe_in_hot_spare(&(stpRebuild_one_node_fsm->stHot_spare_drive_stripes),
								stpRebuild_one_node_fsm,
								stpLogorg);
				if(iNew_id_found_hot_spare_drv_stripe >= 0)
				{
//					stpRebuild_one_node_fsm->nCurrent_id_hot_spare_drive_stripe = iNew_id_found_hot_spare_drv_stripe;
					stpRebuild_one_node_fsm->iDevno_rebuild =
							stpRebuild_one_node_fsm->anDev_id_per_org[stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anDrive_id_per_hot_spare[iNew_id_found_hot_spare_drv_stripe]];
					stpRebuild_one_node_fsm->nStripe_id_repair_from_hot_spare =
							stpRebuild_one_node_fsm->stHot_spare_drive_stripes.anStripe_id_hot_spare[iNew_id_found_hot_spare_drv_stripe]
							                    + (stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg * stpLogorg->nTotal_stripes_per_zone) ;

				}
				else
				{
					fprintf(stderr, "File: %s, line: %d, func:%s, Error cannot find a hot spare drive-stripe unit to repair. \n",
							__FILE__, __LINE__, __func__);
					exit(0);
				}

			}
			else
			{
				stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
						stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
				nTotal_nodes_read ++;
			}
		}
		stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anStripe_id_per_ckg[0] +
				( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
						stpLogorg->nTotal_stripes_per_zone);

	}

	if(	stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count == 1)
		// (stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg % 10) == 1 &&, prompt at the beginning of each zone
	{
	   fprintf(stderr, "%d/(%d, %d, %d)\n",
			   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg, stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg,
			   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg, stpLogorg->nTotal_ckg_zones);
	}

}
