/*
 * disksim_org_rebuild.c
 *
 *  Created on: Apr 28, 2015
 *      Author: zhengyi.zhao@wdc.com
 */

#include <string.h>

#include "disksim_logorg.h"
#include "modules/modules.h"

void logorg_rebuild_ckg_stripe(struct logorg *stpLogorg)
{

}

int __check_id_appear_in_know_char_list(char *acList, int nList_len,
		                       int id)
{
int iFlag_appear = 0;
int ii;
    for(ii=0; ii<nList_len; ii++)
    {
    	if(acList[ii] == id)
    	{
    		iFlag_appear = 1;
    		break;
    	}
    }

    return iFlag_appear;
}

int __check_id_appear_in_know_int_list(int *aiList, int nList_len,
		                       int id)
{
int iFlag_appear = 0;
int ii;
    for(ii=0; ii<nList_len; ii++)
    {
    	if(aiList[ii] == id)
    	{
    		iFlag_appear = 1;
    		break;
    	}
    }

    return iFlag_appear;
}

int logorg_check_id_in_rebuild_list(logorg *stpCurr_org, int iNode)
{
int iFlag_in_rebuild;
// int dd;
	iFlag_in_rebuild =
			__check_id_appear_in_know_int_list(stpCurr_org->anNode_id_list_rebuild,
					stpCurr_org->nTotal_drive_to_rebuild,
					iNode);

	return iFlag_in_rebuild;
}

int logorg_check_num_drive_rebuild_by_ckg_list(logorg *stpCurrorg, int *aDrive_list_in_ckg)
{
int nNum_drives_rebuild = 0;
int dd, nNum_drives_in_ckg;
	nNum_drives_in_ckg = stpCurrorg->nNum_drives_per_ckg;

	for(dd = 0; dd<nNum_drives_in_ckg; dd++)
	{
		if(logorg_check_id_in_rebuild_list(stpCurrorg, aDrive_list_in_ckg[dd]) == 1)
		{
			nNum_drives_rebuild ++;
		}
	}

	return nNum_drives_rebuild;
}


// redunlist is READ trace, must take place befor reqlist
void __logorg_parity_table_dodeps_sync (logorg *currlogorg,
		ioreq_event *curr, ioreq_event **redunlist, ioreq_event **reqlist)
{
   int i, j;
   depends *depend;
   depends *tmpdep;
   int opid = 0;
   int numdeps = 0;
   ioreq_event *temp;
   ioreq_event *deplist = NULL;
   int devno = 1;

   for (i=0; i<currlogorg->actualnumdisks; i++)
   {
      temp = redunlist[i];
      while (temp)
      {
		 temp->opid = curr->opid;
		 opid++;
		 if (temp->next == NULL)
		 {
			temp->next = curr->next;
			curr->next = redunlist[i];
			break;
		 }
		 temp = temp->next;
      }
      temp = reqlist[i];
      while (temp)
      {
		 numdeps++;
		 if (temp->next == NULL)
		 {
			temp->next = deplist;
			deplist = reqlist[i];
			break;
		 }
		 temp = temp->next;
      }
   }
   if (numdeps <= 0)
   {
      fprintf(stderr, "Can't have zero requests at logorg_parity_table_dodeps_sync\n");
      exit(1);
   }
   if (opid == 0)
   {
      curr->prev = NULL;
      curr->next = deplist;
      return;
   }
   depend = (depends *) getfromextraq();
   depend->blkno = curr->next->blkno;
   depend->devno = curr->next->devno;
   depend->numdeps = numdeps;
   curr->prev = (ioreq_event *) depend;
   depend->deps[0] = deplist;
   deplist->opid = opid;
   temp = deplist->next;
   for (i=1; i<numdeps; i++)
   {
      if (devno == 0)
      {
		 depend->cont = (depends *) getfromextraq();
		 depend = depend->cont;
      }
      depend->deps[devno] = temp;
      temp->opid = opid;
      devno = logorg_modulus_update(1, devno, 10);
      temp = temp->next;
   }
   temp = curr->next->next;
   for (i=1; i<opid; i++)
   {
      depend = (depends *) ioreq_copy(curr->prev);
      depend->next = (depends *) curr->prev;
      curr->prev = (ioreq_event *) depend;
      depend->blkno = temp->blkno;
      depend->devno = temp->devno;
      tmpdep = depend->cont;
      for (j=0; j<(numdeps/10); j++)
      {
		 depend->cont = (depends *) ioreq_copy((ioreq_event *) tmpdep);
		 tmpdep = tmpdep->cont;
		 depend = depend->cont;
      }
      temp = temp->next;
   }
}
// Is there any chance that different iodriver access the same one org,
// we reserve the possibility by putting the input: int iodriverno
void iodriver_rebuild_org_node_one_stripe(int iodriverno, struct logorg *stpLogorg)
{
	// in logorg.c
	if(stpLogorg->reduntype == DECLUSTER_RAID)
	{
		switch(stpLogorg->stpChunk_group_mapping->nType_raid)
		{
		case 5:
			//		logorg_rebuild_ckg_one_stripe_with_sync(stpLogorg);  // @020
			logorg_rebuild_one_stripe(stpLogorg); // logorg_rebuild_ckg_stripe, now reuse the same rebuild routine
			break;
		case 6:
		case __ORG_DECLUSTER_GENERAL_REED_SOLOMON__:
		case __ORG_DECLUSTER_LOCAL_RECONSTRUCTION__:
			logorg_general_parity_rebuild_one_stripe(stpLogorg);
			break;
		}
	}
	else
	{
		logorg_rebuild_one_stripe(stpLogorg);
	}

}

void logorg_decluster_ckg_init_setting(logorg *stpLogorg)
{
	int nTotalStripesPerZone = stpLogorg->nTotal_active_stripes_per_zone;
	int nTotal_active_ckgs_per_zone = stpLogorg->nTotal_active_ckgs_per_zone;
	int nNum_drives_per_ckg = stpLogorg->nNum_drives_per_ckg;

	int nType_raid = stpLogorg->stpChunk_group_mapping->nType_raid;

	stpLogorg->nTotal_stripes_per_zone = (int)((double)nTotalStripesPerZone / (1.0 - stpLogorg->dHot_spare_reserve_percentage)) + 1;


	stpLogorg->nTotal_active_ckgs_per_zone = nTotal_active_ckgs_per_zone;
	stpLogorg->nTotal_chunk_groups_per_zone =
			stpLogorg->nTotal_stripes_per_zone * stpLogorg->actualnumdisks  / nNum_drives_per_ckg;
			//(int)(nTotal_active_ckgs_per_zone / (1.0 - stpLogorg->dHot_spare_reserve_percentage)) + 1;

	stpLogorg->nTotal_OBAs_per_zone = stpLogorg->nTotal_chunk_groups_per_zone * nNum_drives_per_ckg;
	stpLogorg->nTotal_LBAs_per_ckg_zone = stpLogorg->nTotal_OBAs_per_zone * stpLogorg->stripeunit;

	if(nType_raid == 5)
	{
		stpLogorg->nTotal_active_OBAs_per_zone =
				stpLogorg->nTotal_active_ckgs_per_zone * (nNum_drives_per_ckg - 1);
	}
	else if (nType_raid == 6)
	{
		stpLogorg->nTotal_active_OBAs_per_zone =
				stpLogorg->nTotal_active_ckgs_per_zone * (nNum_drives_per_ckg - 2);
	}
	else if (nType_raid == __ORG_DECLUSTER_GENERAL_REED_SOLOMON__ ||  nType_raid == __ORG_DECLUSTER_LOCAL_RECONSTRUCTION__)
	{
		stpLogorg->nTotal_active_OBAs_per_zone =
						stpLogorg->nTotal_active_ckgs_per_zone * stpLogorg->stpOrg_parity_pattern->nNum_total_data_nodes;
	}
	stpLogorg->nTotal_active_LBAs_per_ckg_zone = stpLogorg->nTotal_active_OBAs_per_zone * stpLogorg->stripeunit;

	stpLogorg->nTotal_ckg_zones = (LBA_TYPE)(stpLogorg->blksperpart * stpLogorg->actualnumdisks / stpLogorg->nTotal_LBAs_per_ckg_zone);

	int nTotal_hot_spare_mapping = stpLogorg->nTotal_stripes_zones_to_rebuild * stpLogorg->nTotal_active_ckgs_per_zone;
	stpLogorg->astHot_spare_mapping_per_zone_ckg =
			(org_hot_spare_mapping_per_zone_ckg**) calloc(nTotal_hot_spare_mapping,
					sizeof(org_hot_spare_mapping_per_zone_ckg*));  // @021
	for(int zzcc = 0; zzcc < nTotal_hot_spare_mapping; zzcc++)
	{
		stpLogorg->astHot_spare_mapping_per_zone_ckg[zzcc] =
				(org_hot_spare_mapping_per_zone_ckg*) calloc(1, sizeof(org_hot_spare_mapping_per_zone_ckg));  // @021
	}
}

void logorg_check_rebuild_at_io_driver(int iodriverno, struct logorg *stpLogorg, int nLogorgId)
{
			// setup the rebuild-fsm and current-stripe
	if(stpLogorg->nTotal_drive_to_rebuild >= 1)
	{
		if(	stpLogorg->reduntype == DECLUSTER_RAID  )
			// stpLogorg->iFlag_repair_node_stage == ORG_REPAIR_BY_HOT_SPARE_CKG &&
		{

			int nCurrent_rebuild_zone_fsm = stpLogorg->stRebuild_event_fsm.nCurrent_rebuild_zone_ckg;

			while(nCurrent_rebuild_zone_fsm ==
					stpLogorg->stRebuild_event_fsm.nCurrent_rebuild_zone_ckg)
			{
			   if(stpLogorg->iFlag_repair_node_stage == ORG_REPAIR_BY_FULL_DRIVE_REBUILD)
			   {
				   logorg_rebuild_nodes_by_ckg_fsm(stpLogorg, nLogorgId);
			   }
			   else
			   {

				   logorg_repair_ckg_nodes_by_hot_spare_fsm(stpLogorg, nLogorgId); // @021
			   }
				if(logorg_get_flag_is_rebuilding() == 0)
				{
					break;  // if(disksim->stop_sim == TRUE)
				}
				else
				{
					iodriver_rebuild_org_node_one_stripe(iodriverno, stpLogorg);
				}
			}
		}
		else
		{

			logorg_idletime_detected (stpLogorg, nLogorgId);

			if(stpLogorg->iFlag_check_idle_task_in_org == 1)
			{
				// send cmd to iodriver
				if(stpLogorg->iNode_id_org_rebuild >= 0 &&
						stpLogorg->stRebuild_event_fsm.nTotal_stripes > 0)
				{
					iodriver_rebuild_org_node_one_stripe(iodriverno, stpLogorg);
				}
			}
		}
	}
			// rebuild-event and checking-event are exclusive to each other
			// assume that no more than 1 drive can be rebuilt at any time
			if(stpLogorg->iNode_id_org_rebuild < 0 &&
					stpLogorg->stPeriodic_checking_fsm.iFlag_enable_checking >= TRUE)
			{
				if(stpLogorg->stPeriodic_checking_fsm.iFlag_has_issue_cmd_to_iodriver == 0)
				{
					logorg_checking_drive_stripes_fsm(stpLogorg);
					stpLogorg->stPeriodic_checking_fsm.iFlag_has_issue_cmd_to_iodriver = 1;
				}
			}
}
// @021
void logorg_general_parity_rebuild_one_stripe(struct logorg *stpLogorg)
{
	ioreq_event *new_read_event, *ret, *new_wr_event;
	outstand * req;
	org_node_rebuild_event_fsm *stpRebuild_one_node_fsm = &stpLogorg->stRebuild_event_fsm;
	int dd;

	if(stpRebuild_one_node_fsm->fptrDebug != NULL)
	{
		fprintf(stpRebuild_one_node_fsm->fptrDebug, "Rd:");
	}
   for(dd = 0; dd< stpRebuild_one_node_fsm->nTotal_nodes_read; dd++)
   {
	   new_read_event = (ioreq_event*) getfromextraq();
	   new_read_event->blkno = stpRebuild_one_node_fsm->nCurrent_rebuild_stripe
			   * stpLogorg->stripeunit;
	   new_read_event->devno = stpRebuild_one_node_fsm->anRead_nodes_dev_no[dd];
	   if(stpLogorg->iFlag_rebuild_node_priority == ORG_REBUILD_PRIORITY_CRITIAL)
	   {
		   new_read_event->flags = READ | MAPPED | DISKSIM_TIME_CRITICAL; //
	   }
	   else if(stpLogorg->iFlag_rebuild_node_priority == ORG_REBUILD_PRIORITY_BASE)
	   {
		   new_read_event->flags = READ | MAPPED;
	   }
	   else
	   {
		   new_read_event->flags = READ | MAPPED | BACKGROUND;
	   }
	   new_read_event->time = simtime;

	   LBA_TYPE nMaxLBA_at_dev;

	   if(new_read_event->blkno + stpLogorg->stripeunit >= stpRebuild_one_node_fsm->nLBA_end)
	   {
		   new_read_event->bcount =
				   stpRebuild_one_node_fsm->nLBA_end - new_read_event->blkno + 1;
	   }
	   else
	   {
		   new_read_event->bcount = stpLogorg->stripeunit;
	   }
	   new_read_event->type = IO_REQUEST_ARRIVE;
	   new_read_event->buf = 0;
	   new_read_event->opid = stpLogorg->opid;
	   new_read_event->busno = 0;
	   new_read_event->cause = 0;

	   addtointq((event *)new_read_event);

		if(stpRebuild_one_node_fsm->fptrDebug != NULL)
		{
			fprintf(stpRebuild_one_node_fsm->fptrDebug, "<%d, %d, %ld>",
					new_read_event->devno, stpRebuild_one_node_fsm->nCurrent_rebuild_stripe, new_read_event->blkno);
		}

   }

	    req = (outstand *) getfromextraq();
	    ASSERT (req != NULL);
	    req->arrtime = new_read_event->time;
	    req->bcount = new_read_event->bcount;
	    req->blkno = new_read_event->blkno;
	    req->devno = new_read_event->devno;
	    req->flags = new_read_event->flags;
	    req->busno = new_read_event->busno;
	    req->buf = new_read_event->buf;
	    req->reqopid = new_read_event->opid;
	    req->depend = NULL;
	    req->opid = stpLogorg->opid;
	    req->numreqs = stpRebuild_one_node_fsm->nTotal_nodes_read;
	    logorg_addnewtooutstandq(stpLogorg, req);

		stpLogorg->opid++;

		//// for write trace, the same number of Num_drive_rebuild
	   for(dd = 0; dd< stpRebuild_one_node_fsm->nNum_drive_rebuild; dd++)
	   {

		new_wr_event = (ioreq_event*) getfromextraq();
		// according to Flag of repair stage // stpRebuild_one_node_fsm = &stpLogorg
		if(stpLogorg ->iFlag_repair_node_stage == ORG_REPAIR_BY_HOT_SPARE_CKG)
		{
			new_wr_event->blkno =
					stpRebuild_one_node_fsm->anStripe_id_repair_from_hot_spare[dd] * stpLogorg->stripeunit;
		}
		else
		{
			new_wr_event->blkno = stpRebuild_one_node_fsm->nCurrent_rebuild_stripe
					   * stpLogorg->stripeunit;
		}
		new_wr_event->devno = stpRebuild_one_node_fsm->anDevno_rebuild[dd];

		new_wr_event->bcount= new_read_event->bcount;
	//	new_wr_event->flags = WRITE | MAPPED | BACKGROUND;
		   if(stpLogorg->iFlag_rebuild_node_priority == ORG_REBUILD_PRIORITY_CRITIAL)
		   {
			   new_wr_event->flags = WRITE | MAPPED | DISKSIM_TIME_CRITICAL;
		   }
		   else if(stpLogorg->iFlag_rebuild_node_priority == ORG_REBUILD_PRIORITY_BASE)
		   {
			   new_wr_event->flags = WRITE | MAPPED;
		   }
		   else
		   {
			   new_wr_event->flags = WRITE | MAPPED | BACKGROUND;
		   }
		new_wr_event->time = new_read_event->time + TIME_DELAY_READ_CALC_ms;

		new_wr_event->type = IO_REQUEST_ARRIVE;
		new_wr_event->buf = 0;
		new_wr_event->opid = stpLogorg->opid;
		new_wr_event->busno = 0;
		new_wr_event->cause = 0;
		addtointq((event *)new_wr_event);

		if(stpRebuild_one_node_fsm->fptrDebug != NULL)
		{
			fprintf(stpRebuild_one_node_fsm->fptrDebug, ", Wr: <%d, %d, %ld> ",
					new_wr_event->devno,
					(stpLogorg ->iFlag_repair_node_stage == ORG_REPAIR_BY_HOT_SPARE_CKG)?
							(stpRebuild_one_node_fsm->anStripe_id_repair_from_hot_spare[dd]):(stpRebuild_one_node_fsm->nCurrent_rebuild_stripe),
					new_wr_event->blkno);
			fflush(stpRebuild_one_node_fsm->fptrDebug);

		}

	   }
	   fprintf(stpRebuild_one_node_fsm->fptrDebug, "\n");

		req = (outstand *) getfromextraq();
		ASSERT (req != NULL);
		req->arrtime = new_wr_event->time;
		req->bcount = new_wr_event->bcount;
		req->blkno = new_wr_event->blkno;
		req->devno = new_wr_event->devno;
		req->flags = new_wr_event->flags;
		req->busno = new_wr_event->busno;
		req->buf = new_wr_event->buf;
		req->reqopid = new_wr_event->opid;
		req->depend = NULL;
		req->opid = stpLogorg->opid;
		req->numreqs = stpRebuild_one_node_fsm->nNum_drive_rebuild;
		logorg_addnewtooutstandq(stpLogorg, req);

		stpLogorg->opid++;


}


// @016
void logorg_rebuild_one_stripe(struct logorg *stpLogorg)
{
	ioreq_event *new_read_event, *ret, *new_wr_event;
	outstand * req;
	org_node_rebuild_event_fsm *stpRebuild_one_node_fsm = &stpLogorg->stRebuild_event_fsm;
	int dd;

	if(stpRebuild_one_node_fsm->fptrDebug != NULL)
	{
		fprintf(stpRebuild_one_node_fsm->fptrDebug, "Rd:");
	}
		   for(dd = 0; dd< stpRebuild_one_node_fsm->nTotal_nodes_read; dd++)
		   {
			   new_read_event = (ioreq_event*) getfromextraq();
			   new_read_event->blkno = stpRebuild_one_node_fsm->nCurrent_rebuild_stripe
					   * stpLogorg->stripeunit;
			   new_read_event->devno = stpRebuild_one_node_fsm->anRead_nodes_dev_no[dd];
			   if(stpLogorg->iFlag_rebuild_node_priority == ORG_REBUILD_PRIORITY_CRITIAL)
			   {
				   new_read_event->flags = READ | MAPPED | DISKSIM_TIME_CRITICAL;
			   }
			   else if(stpLogorg->iFlag_rebuild_node_priority == ORG_REBUILD_PRIORITY_BASE)
			   {
				   new_read_event->flags = READ | MAPPED;
			   }
			   else
			   {
				   new_read_event->flags = READ | MAPPED | BACKGROUND;
			   }
			   new_read_event->time = simtime;

			   LBA_TYPE nMaxLBA_at_dev;

			   if(new_read_event->blkno + stpLogorg->stripeunit >= stpRebuild_one_node_fsm->nLBA_end)
			   {
				   new_read_event->bcount =
						   stpRebuild_one_node_fsm->nLBA_end - new_read_event->blkno + 1;
			   }
			   else
			   {
				   new_read_event->bcount = stpLogorg->stripeunit;
			   }
			   new_read_event->type = IO_REQUEST_ARRIVE;
			   new_read_event->buf = 0;
			   new_read_event->opid = stpLogorg->opid;
			   new_read_event->busno = 0;
			   new_read_event->cause = 0;

			   addtointq((event *)new_read_event);

				if(stpRebuild_one_node_fsm->fptrDebug != NULL)
				{
					fprintf(stpRebuild_one_node_fsm->fptrDebug, "<%d, %d, %ld>",
							new_read_event->devno, stpRebuild_one_node_fsm->nCurrent_rebuild_stripe, new_read_event->blkno);
				}

		   }

	    req = (outstand *) getfromextraq();
	    ASSERT (req != NULL);
	    req->arrtime = new_read_event->time;
	    req->bcount = new_read_event->bcount;
	    req->blkno = new_read_event->blkno;
	    req->devno = new_read_event->devno;
	    req->flags = new_read_event->flags;
	    req->busno = new_read_event->busno;
	    req->buf = new_read_event->buf;
	    req->reqopid = new_read_event->opid;
	    req->depend = NULL;
	    req->opid = new_read_event->opid; // @021
	    req->numreqs = stpRebuild_one_node_fsm->nTotal_nodes_read;
	    logorg_addnewtooutstandq(stpLogorg, req);

		stpLogorg->opid++;

		new_wr_event = (ioreq_event*) getfromextraq();
		// according to Flag of repair stage // stpRebuild_one_node_fsm = &stpLogorg
		if(stpLogorg ->iFlag_repair_node_stage == ORG_REPAIR_BY_HOT_SPARE_CKG)
		{
			new_wr_event->blkno =
					stpRebuild_one_node_fsm->nStripe_id_repair_from_hot_spare * stpLogorg->stripeunit;
			new_wr_event->devno = stpRebuild_one_node_fsm->iDevno_rebuild;
		}
		else
		{
			new_wr_event->blkno = stpRebuild_one_node_fsm->nCurrent_rebuild_stripe
					   * stpLogorg->stripeunit;
			new_wr_event->devno = stpRebuild_one_node_fsm->iDevno_rebuild;
		}

		new_wr_event->bcount= new_read_event->bcount;
	//	new_wr_event->flags = WRITE | MAPPED | BACKGROUND;
		   if(stpLogorg->iFlag_rebuild_node_priority == ORG_REBUILD_PRIORITY_CRITIAL)
		   {
			   new_wr_event->flags = WRITE | MAPPED | DISKSIM_TIME_CRITICAL;
		   }
		   else if(stpLogorg->iFlag_rebuild_node_priority == ORG_REBUILD_PRIORITY_BASE)
		   {
			   new_wr_event->flags = WRITE | MAPPED;
		   }
		   else
		   {
			   new_wr_event->flags = WRITE | MAPPED | BACKGROUND;
		   }
		new_wr_event->time = new_read_event->time + TIME_DELAY_READ_CALC_ms;

		new_wr_event->type = IO_REQUEST_ARRIVE;
		new_wr_event->buf = 0;
		new_wr_event->opid = stpLogorg->opid;
		new_wr_event->busno = 0;
		new_wr_event->cause = 0;
		addtointq((event *)new_wr_event);

		req = (outstand *) getfromextraq();
		ASSERT (req != NULL);
		req->arrtime = new_wr_event->time;
		req->bcount = new_wr_event->bcount;
		req->blkno = new_wr_event->blkno;
		req->devno = new_wr_event->devno;
		req->flags = new_wr_event->flags;
		req->busno = new_wr_event->busno;
		req->buf = new_wr_event->buf;
		req->reqopid = new_wr_event->opid;
		req->depend = NULL;
		req->opid = stpLogorg->opid;
		req->numreqs = 1;
		logorg_addnewtooutstandq(stpLogorg, req);

		stpLogorg->opid++;

		if(stpRebuild_one_node_fsm->fptrDebug != NULL)
		{
			fprintf(stpRebuild_one_node_fsm->fptrDebug, ", Wr: <%d, %d, %ld>\n",
					stpRebuild_one_node_fsm->iDevno_rebuild, stpRebuild_one_node_fsm->nStripe_id_repair_from_hot_spare,
					new_wr_event->blkno);
			fflush(stpRebuild_one_node_fsm->fptrDebug);
			if(stpRebuild_one_node_fsm->iDevno_rebuild == 3 &&
					stpRebuild_one_node_fsm->nStripe_id_repair_from_hot_spare == 54 &&
					new_wr_event->blkno == 55296
					)
			{
				fprintf(stpRebuild_one_node_fsm->fptrDebug, "Stop for debugging");
			}
		}

}

// @016 org rebuild
static int iFlag_org_is_rebuilding = 0;
int logorg_stop_rebuild()
{
	iFlag_org_is_rebuilding = 0;
}
int logorg_get_flag_is_rebuilding()
{
	return iFlag_org_is_rebuilding;
}
int logorg_start_rebuilding_set_flag()
{
	if(iFlag_org_is_rebuilding == 0)
	{
		iFlag_org_is_rebuilding = 1;
	}
}

void logorg_rebuild_nodes_by_ckg_fsm(struct logorg *stpLogorg, int logorgnum)
{
	switch(stpLogorg->stpChunk_group_mapping->nType_raid)
	{
	case 5:
		logorg_rebuild_one_node_by_ckg_fsm(stpLogorg, logorgnum);
		break;
	case 6: // RAID-6 can use the general RS with D+2
		break;
	case __ORG_DECLUSTER_GENERAL_REED_SOLOMON__: // General RS
		logorg_rebuild_nodes_reed_solomon_ckg_fsm(stpLogorg, logorgnum);
		break;
	case __ORG_DECLUSTER_LOCAL_RECONSTRUCTION__: // LRC
		logorg_rebuild_nodes_local_reconstruct_ckg_fsm(stpLogorg, logorgnum);
		break;
	}
}
// This function is for de-cluster LRC(Local Reconstruction)
void logorg_rebuild_nodes_local_reconstruct_ckg_fsm(struct logorg *stpLogorg, int logorgnum)
{
	int dd, ll, gg, lldd;

	org_node_rebuild_event_fsm *stpRebuild_one_node_fsm = &stpLogorg->stRebuild_event_fsm;
	org_rebuild_ckg_list_per_zone * stpOriginal_rebuild_zone_ckg_list_in_org;

	stpOriginal_rebuild_zone_ckg_list_in_org = stpLogorg->stpRebuid_ckg_list_per_zone;
	org_rebuild_ckg_list_per_zone *stpCurrend_rebuild_ckg_per_zone =
			stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

	int iRebuildNodeId = stpLogorg->iNode_id_org_rebuild;
	logorgdev *stpLogorg_dev = stpLogorg->devs;
	int nTotal_nodes_read = 0, nNum_drive_rebuild=0;
	int iDev_global_id, iDev_org_id;
	org_parity_pattern * stpCurr_parity_pattern;
	org_chunk_group_map *stpCurr_ckg;
	int iFlag_use_node_for_read;
    org_local_parity *stpCurr_local_parity;
    org_global_parity *stpGlobal_parity;

	// Cond-1: initialization of a new rebuild
	if(stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg == 0)
	{
		   stpLogorg_dev = stpLogorg->devs;
		   nTotal_nodes_read = 0; nNum_drive_rebuild=0;

		   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg = stpLogorg->nTotal_stripes_zones_to_rebuild;

		   stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				   stpOriginal_rebuild_zone_ckg_list_in_org->nCkg_rebuild_id;
		   stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				   stpLogorg->stpRebuid_ckg_list_per_zone;
		   stpCurrend_rebuild_ckg_per_zone =
		   			stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

		   stpCurr_parity_pattern =
				   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->stpCurr_parity_pattern;

		   for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		   {
			   iFlag_use_node_for_read = 0;
			   iDev_org_id =
					   stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			   if(logorg_check_id_in_rebuild_list(stpLogorg, iDev_org_id))
			   {
				   stpRebuild_one_node_fsm->anDevno_rebuild[nNum_drive_rebuild] =
						   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
				   nNum_drive_rebuild ++;
			   }
			   else
			   {
				   if(__check_id_appear_in_know_int_list(
						   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anData_list_node_id,
						   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->nNum_data_nodes,
						   iDev_org_id) == 0)
				   {
					   // for a parity node
					   if(__check_id_appear_in_know_int_list(
						   stpOriginal_rebuild_zone_ckg_list_in_org->anParity_node_read_list,
						   stpOriginal_rebuild_zone_ckg_list_in_org->nTotal_parity_read,
						   iDev_org_id) == 1)
					   {
						   iFlag_use_node_for_read = 1;
					   }
				   }
				   else
				   {
					   // further check if any global parity failure
					   if(stpCurrend_rebuild_ckg_per_zone->cFlag_has_failure_in_global_parity == 1)
					   {
						   iFlag_use_node_for_read = 1;
					   }

					   if(iFlag_use_node_for_read == 0)
					   {
						   // for a data node in local parity,
						   // need to check any failure in this local parity group
						   stpCurr_local_parity = stpCurr_parity_pattern->stpLocal_parity_group;
						   for(ll=0; ll < stpCurr_parity_pattern->nNum_local_parity_nodes; ll++)
						   {
							   if(stpCurrend_rebuild_ckg_per_zone->anFailure_nodes_per_local_parity[ll] >= 1)
							   {
								   for(lldd = 0; lldd< stpCurr_local_parity->nNum_data_in_group; lldd ++)
								   {
									   if(stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[stpCurr_local_parity->aData_nodes[lldd]]
									         ==  iDev_org_id )
									   {
										   iFlag_use_node_for_read = 1;
										   break;
									   }
								   }
								   if(iFlag_use_node_for_read == 1)
								   {
									   break; // ll = stpCurr_parity_pattern->nNum_local_parity_nodes;
								   }
							   }
							   stpCurr_local_parity ++;
						   }
					   }
				   }

				   if(iFlag_use_node_for_read == 1)
				   {
					   stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
							   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
					   nTotal_nodes_read ++;
				   }
			   }
		   }
//		   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg = 0;
		   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg =
				   (int)(stpLogorg->dStarting_stripe_rebuild_percentage * stpLogorg->nTotal_ckg_zones );
		   stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg = stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg;


		   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				   stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anStripe_id_per_ckg[0]+
					( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
							stpLogorg->nTotal_stripes_per_zone);

		   stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		   stpRebuild_one_node_fsm->nNum_drive_rebuild = nNum_drive_rebuild;

		   stpRebuild_one_node_fsm->nTotal_stripes =
				   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg *
				   stpLogorg->nTotal_ckg_rebuild_per_zone;

		   stpRebuild_one_node_fsm->nLBA_end = stpLogorg_dev->nLBA_end;
		   stpCurrend_rebuild_ckg_per_zone = stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

           logorg_decluster_init_hot_spare_all_zones(stpLogorg); // @021
		   iFlag_org_is_rebuilding = 1;

	}
	else if(((stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg - stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg)== stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg &&
			stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone >= stpLogorg->nTotal_ckg_rebuild_per_zone)  ||
			(stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg - stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg) > stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg
			)
	{
		   stpRebuild_one_node_fsm->nTotal_stripes = 0;
		   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe = 0;
		   stpLogorg->iNode_id_org_rebuild = -1;

		   logorg_stop_rebuild();  // iFlag_org_is_rebuilding = 0;  // disksim_simstop();
	}

	else if(stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count < stpLogorg->nTotal_ckg_rebuild_per_zone)
	{ // build next ckg within current zone

		stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				stpCurrend_rebuild_ckg_per_zone->stpNext_list_item;
		stpCurrend_rebuild_ckg_per_zone =
				stpCurrend_rebuild_ckg_per_zone->stpNext_list_item;
		stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_id;
		nTotal_nodes_read = 0; nNum_drive_rebuild=0;

	   stpCurr_parity_pattern =
				   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->stpCurr_parity_pattern;

		for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		{
			iFlag_use_node_for_read = 0;
			iDev_org_id = stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anDrive_id_per_ckg[dd];

		   if(logorg_check_id_in_rebuild_list(stpLogorg, iDev_org_id))
		   {
			   stpRebuild_one_node_fsm->anDevno_rebuild[nNum_drive_rebuild] =
					   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
			   nNum_drive_rebuild ++;
		   }
		   else
		   {
			   if(__check_id_appear_in_know_int_list(
					   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anData_list_node_id,
					   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->nNum_data_nodes,
					   iDev_org_id) == 0)
			   {
				   // for a parity node
				   if(__check_id_appear_in_know_int_list(
						   stpCurrend_rebuild_ckg_per_zone->anParity_node_read_list,
						   stpCurrend_rebuild_ckg_per_zone->nTotal_parity_read,
					   iDev_org_id) == 1)
				   {
					   iFlag_use_node_for_read = 1;
				   }
			   }
			   else
			   {
				   // further check if any global parity failure
				   if(stpCurrend_rebuild_ckg_per_zone->cFlag_has_failure_in_global_parity == 1)
				   {
					   iFlag_use_node_for_read = 1;
				   }

				   if(iFlag_use_node_for_read == 0)
				   {
					   // for a data node in local parity,
					   // need to check any failure in this local parity group
					   stpCurr_local_parity = stpCurr_parity_pattern->stpLocal_parity_group;
					   for(ll=0; ll < stpCurr_parity_pattern->nNum_local_parity_nodes; ll++)
					   {
						   if(stpCurrend_rebuild_ckg_per_zone->anFailure_nodes_per_local_parity[ll] >= 1)
						   {
							   for(lldd = 0; lldd< stpCurr_local_parity->nNum_data_in_group; lldd ++)
							   {
								   if(stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[stpCurr_local_parity->aData_nodes[lldd]]
								         ==  iDev_org_id )
								   {
									   iFlag_use_node_for_read = 1;
									   break;
								   }
							   }
							   if(iFlag_use_node_for_read == 1)
							   {
								   break; // ll = stpCurr_parity_pattern->nNum_local_parity_nodes;
							   }
						   }
						   stpCurr_local_parity ++;
					   }
				   }
			   }

			   if(iFlag_use_node_for_read == 1)
			   {
				   stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
						   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
				   nTotal_nodes_read ++;
			   }
		   }

		}

		stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		stpRebuild_one_node_fsm->nNum_drive_rebuild = nNum_drive_rebuild;
		stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anStripe_id_per_ckg[0] +
				( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
						stpLogorg->nTotal_stripes_per_zone);


	}
	else if(stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count == stpLogorg->nTotal_ckg_rebuild_per_zone)
	{ // build next zone,
		stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg ++;

		//
		stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				stpOriginal_rebuild_zone_ckg_list_in_org->nCkg_rebuild_id;
		stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				stpOriginal_rebuild_zone_ckg_list_in_org; // stpLogorg->stpRebuid_ckg_list_per_zone;
		stpCurrend_rebuild_ckg_per_zone =
					stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

		nTotal_nodes_read = 0; nNum_drive_rebuild=0;

	   stpCurr_parity_pattern =
				   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->stpCurr_parity_pattern;

		for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		{
			iDev_org_id = stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			iFlag_use_node_for_read = 0;

		   if(logorg_check_id_in_rebuild_list(stpLogorg, iDev_org_id))
		   {
			   stpRebuild_one_node_fsm->anDevno_rebuild[nNum_drive_rebuild] =
					   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
			   nNum_drive_rebuild ++;
		   }
		   else
		   {
			   if(__check_id_appear_in_know_int_list(
					   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anData_list_node_id,
					   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->nNum_data_nodes,
					   iDev_org_id) == 0)
			   {
				   // for a parity node
				   if(__check_id_appear_in_know_int_list(
						   stpCurrend_rebuild_ckg_per_zone->anParity_node_read_list,
						   stpCurrend_rebuild_ckg_per_zone->nTotal_parity_read,
					   iDev_org_id) == 1)
				   {
					   iFlag_use_node_for_read = 1;
				   }
			   }
			   else
			   {
				   // further check if any global parity failure
				   if(stpCurrend_rebuild_ckg_per_zone->cFlag_has_failure_in_global_parity == 1)
				   {
					   iFlag_use_node_for_read = 1;
				   }

				   if(iFlag_use_node_for_read == 0)
				   {
					   // for a data node in local parity,
					   // need to check any failure in this local parity group
					   stpCurr_local_parity = stpCurr_parity_pattern->stpLocal_parity_group;
					   for(ll=0; ll < stpCurr_parity_pattern->nNum_local_parity_nodes; ll++)
					   {
						   if(stpCurrend_rebuild_ckg_per_zone->anFailure_nodes_per_local_parity[ll] >= 1)
						   {
							   for(lldd = 0; lldd< stpCurr_local_parity->nNum_data_in_group; lldd ++)
							   {
								   if(stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[stpCurr_local_parity->aData_nodes[lldd]]
								         ==  iDev_org_id )
								   {
									   iFlag_use_node_for_read = 1;
									   break;
								   }
							   }
							   if(iFlag_use_node_for_read == 1)
							   {
								   break; // ll = stpCurr_parity_pattern->nNum_local_parity_nodes;
							   }
						   }
						   stpCurr_local_parity ++;
					   }
				   }
			   }

			   if(iFlag_use_node_for_read == 1)
			   {
				   stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
						   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
				   nTotal_nodes_read ++;
			   }
		   }

		}
		stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		stpRebuild_one_node_fsm->nNum_drive_rebuild = nNum_drive_rebuild;
		stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anStripe_id_per_ckg[0] +
				( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
						stpLogorg->nTotal_stripes_per_zone);

	}

	if(	stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count == 1)
		// (stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg % 10) == 1 &&, prompt at the beginning of each zone
	{
	   fprintf(stderr, "%d/(%d, %d, %d)\n",
			   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg, stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg,
			   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg, stpLogorg->nTotal_ckg_zones);
	}


}

// This function is for de-cluster- general RS
void logorg_rebuild_nodes_reed_solomon_ckg_fsm(struct logorg *stpLogorg, int logorgnum)
{
	int dd;

	org_node_rebuild_event_fsm *stpRebuild_one_node_fsm = &stpLogorg->stRebuild_event_fsm;
	org_rebuild_ckg_list_per_zone * stpOriginal_rebuild_zone_ckg_list_in_org;

	stpOriginal_rebuild_zone_ckg_list_in_org = stpLogorg->stpRebuid_ckg_list_per_zone;
	org_rebuild_ckg_list_per_zone *stpCurrend_rebuild_ckg_per_zone =
			stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

	int iRebuildNodeId = stpLogorg->iNode_id_org_rebuild;
	logorgdev *stpLogorg_dev = stpLogorg->devs;
	int nTotal_nodes_read = 0, nNum_drive_rebuild=0;
	int iDev_global_id, iDev_org_id;
	org_parity_pattern * stpCurr_parity_pattern;
	org_chunk_group_map *stpCurr_ckg;
	int iFlag_use_node_for_read;

	// Cond-1: initialization of a new rebuild
	if(stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg == 0)
	{
		   stpLogorg_dev = stpLogorg->devs;
		   nTotal_nodes_read = 0; nNum_drive_rebuild=0;

		   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg = stpLogorg->nTotal_stripes_zones_to_rebuild;

		   stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				   stpOriginal_rebuild_zone_ckg_list_in_org->nCkg_rebuild_id;
		   stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				   stpLogorg->stpRebuid_ckg_list_per_zone;
		   stpCurrend_rebuild_ckg_per_zone =
		   			stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

		   stpCurr_parity_pattern =
				   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->stpCurr_parity_pattern;

		   for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		   {
			   iFlag_use_node_for_read = 0;
			   iDev_org_id =
					   stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			   if(logorg_check_id_in_rebuild_list(stpLogorg, iDev_org_id))
			   {
				   stpRebuild_one_node_fsm->anDevno_rebuild[nNum_drive_rebuild] =
						   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
				   nNum_drive_rebuild ++;
			   }
			   else
			   {
				   if(__check_id_appear_in_know_int_list(
						   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anData_list_node_id, // stpCurr_parity_pattern->aIdx_data_nodes,
						   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->nNum_data_nodes, 	//stpCurr_parity_pattern->nNum_total_data_nodes,
						   iDev_org_id) == 1)
				   {
					   iFlag_use_node_for_read = 1;
				   }
				   else
				   {
					   if(__check_id_appear_in_know_int_list(
						   stpOriginal_rebuild_zone_ckg_list_in_org->anParity_node_read_list,
						   stpOriginal_rebuild_zone_ckg_list_in_org->nTotal_parity_read,
						   iDev_org_id) == 1)
					   {
						   iFlag_use_node_for_read = 1;
					   }
				   }

				   if(iFlag_use_node_for_read == 1)
				   {
					   stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
							   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
					   nTotal_nodes_read ++;
				   }
			   }
		   }
//		   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg = 0;
		   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg =
				   (int)(stpLogorg->dStarting_stripe_rebuild_percentage * stpLogorg->nTotal_ckg_zones );
		   stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg = stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg;


		   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				   stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anStripe_id_per_ckg[0]+
					( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
							stpLogorg->nTotal_stripes_per_zone);

		   stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		   stpRebuild_one_node_fsm->nNum_drive_rebuild = nNum_drive_rebuild;

		   stpRebuild_one_node_fsm->nTotal_stripes =
				   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg *
				   stpLogorg->nTotal_ckg_rebuild_per_zone;

		   stpRebuild_one_node_fsm->nLBA_end = stpLogorg_dev->nLBA_end;
		   stpCurrend_rebuild_ckg_per_zone = stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

           logorg_decluster_init_hot_spare_all_zones(stpLogorg); // @021
		   iFlag_org_is_rebuilding = 1;

	}
	else if(((stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg - stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg)== stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg &&
			stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone >= stpLogorg->nTotal_ckg_rebuild_per_zone)  ||
			(stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg - stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg) > stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg
			)
	{
		   stpRebuild_one_node_fsm->nTotal_stripes = 0;
		   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe = 0;
		   stpLogorg->iNode_id_org_rebuild = -1;

		   logorg_stop_rebuild();  // iFlag_org_is_rebuilding = 0;  // disksim_simstop();
	}

	else if(stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count < stpLogorg->nTotal_ckg_rebuild_per_zone)
	{ // build next ckg within current zone

		stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				stpCurrend_rebuild_ckg_per_zone->stpNext_list_item;
		stpCurrend_rebuild_ckg_per_zone =
				stpCurrend_rebuild_ckg_per_zone->stpNext_list_item;
		stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_id;
		nTotal_nodes_read = 0; nNum_drive_rebuild=0;

		for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		{
			iFlag_use_node_for_read = 0;
			iDev_org_id = stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anDrive_id_per_ckg[dd];

		   if(logorg_check_id_in_rebuild_list(stpLogorg, iDev_org_id))
		   {
			   stpRebuild_one_node_fsm->anDevno_rebuild[nNum_drive_rebuild] =
					   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
			   nNum_drive_rebuild ++;
		   }
		   else
		   {
			   if(__check_id_appear_in_know_int_list(
					   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anData_list_node_id, // stpCurr_parity_pattern->aIdx_data_nodes,
					   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->nNum_data_nodes, 	//stpCurr_parity_pattern->nNum_total_data_nodes,
					   iDev_org_id) == 1)
			   {
				   iFlag_use_node_for_read = 1;
			   }
			   else
			   {
				   if(__check_id_appear_in_know_int_list(
						   stpCurrend_rebuild_ckg_per_zone->anParity_node_read_list,
						   stpCurrend_rebuild_ckg_per_zone->nTotal_parity_read,
					   iDev_org_id) == 1)
				   {
					   iFlag_use_node_for_read = 1;
				   }
			   }

			   if(iFlag_use_node_for_read == 1)
			   {
				   stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
						   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
				   nTotal_nodes_read ++;
			   }
		   }

//			if(iDev_org_id == iRebuildNodeId) // stpLogorg->iNode_id_org_rebuild)
//			{
//				stpRebuild_one_node_fsm->iDevno_rebuild =
//						stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
//			}
//			else
//			{
//				stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
//						stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
//				nTotal_nodes_read ++;
//			}
		}

		stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		stpRebuild_one_node_fsm->nNum_drive_rebuild = nNum_drive_rebuild;
		stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anStripe_id_per_ckg[0] +
				( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
						stpLogorg->nTotal_stripes_per_zone);


	}
	else if(stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count == stpLogorg->nTotal_ckg_rebuild_per_zone)
	{ // build next zone,
		stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg ++;

		//
		stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				stpOriginal_rebuild_zone_ckg_list_in_org->nCkg_rebuild_id;
		stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				stpOriginal_rebuild_zone_ckg_list_in_org; // stpLogorg->stpRebuid_ckg_list_per_zone;
		stpCurrend_rebuild_ckg_per_zone =
					stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

		nTotal_nodes_read = 0; nNum_drive_rebuild=0;

		for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		{
			iDev_org_id = stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			iFlag_use_node_for_read = 0;

		   if(logorg_check_id_in_rebuild_list(stpLogorg, iDev_org_id))
		   {
			   stpRebuild_one_node_fsm->anDevno_rebuild[nNum_drive_rebuild] =
					   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
			   nNum_drive_rebuild ++;
		   }
		   else
		   {
			   if(__check_id_appear_in_know_int_list(
					   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anData_list_node_id, // stpCurr_parity_pattern->aIdx_data_nodes,
					   stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->nNum_data_nodes, 	//stpCurr_parity_pattern->nNum_total_data_nodes,
					   iDev_org_id) == 1)
			   {
				   iFlag_use_node_for_read = 1;
			   }
			   else
			   {
				   if(__check_id_appear_in_know_int_list(
						   stpCurrend_rebuild_ckg_per_zone->anParity_node_read_list,
						   stpCurrend_rebuild_ckg_per_zone->nTotal_parity_read,
					   iDev_org_id) == 1)
				   {
					   iFlag_use_node_for_read = 1;
				   }
			   }

			   if(iFlag_use_node_for_read == 1)
			   {
				   stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
						   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
				   nTotal_nodes_read ++;
			   }
		   }

//			if(iDev_org_id == iRebuildNodeId) // stpLogorg->iNode_id_org_rebuild)
//			{
//				stpRebuild_one_node_fsm->iDevno_rebuild =
//						stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
//			}
//			else
//			{
//				stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
//						stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
//				nTotal_nodes_read ++;
//			}
		}
		stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		stpRebuild_one_node_fsm->nNum_drive_rebuild = nNum_drive_rebuild;
		stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anStripe_id_per_ckg[0] +
				( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
						stpLogorg->nTotal_stripes_per_zone);

	}

	if(	stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count == 1)
		// (stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg % 10) == 1 &&, prompt at the beginning of each zone
	{
	   fprintf(stderr, "%d/(%d, %d, %d)\n",
			   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg, stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg,
			   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg, stpLogorg->nTotal_ckg_zones);
	}

}

// This function is for decluster-RAID5, only
void logorg_rebuild_one_node_by_ckg_fsm(struct logorg *stpLogorg, int logorgnum)
{
	int dd;

	org_node_rebuild_event_fsm *stpRebuild_one_node_fsm = &stpLogorg->stRebuild_event_fsm;
	org_rebuild_ckg_list_per_zone * stpOriginal_rebuild_zone_ckg_list_in_org;

	stpOriginal_rebuild_zone_ckg_list_in_org = stpLogorg->stpRebuid_ckg_list_per_zone;
	org_rebuild_ckg_list_per_zone *stpCurrend_rebuild_ckg_per_zone =
			stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

	int iRebuildNodeId = stpLogorg->iNode_id_org_rebuild;
	logorgdev *stpLogorg_dev = stpLogorg->devs;
	int nTotal_nodes_read = 0;
	int iDev_global_id, iDev_org_id;

	// Cond-1: initialization of a new rebuild
	if(stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg == 0)
	{
//		   iRebuildNodeId = stpLogorg->iNode_id_org_rebuild;
		   stpLogorg_dev = stpLogorg->devs;
		   nTotal_nodes_read = 0;

		   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg = stpLogorg->nTotal_stripes_zones_to_rebuild;
//				   * stpLogorg->nTotal_ckg_rebuild_per_zone;
				   //stpLogorg->nTotal_ckg_zones;
//				   stpLogorg->aiCkg_id_rebuild_per_zone[0];

		   stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				   stpOriginal_rebuild_zone_ckg_list_in_org->nCkg_rebuild_id;
		   stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				   stpLogorg->stpRebuid_ckg_list_per_zone;

		   for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		   {
			   iDev_org_id = stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			   if(iDev_org_id == iRebuildNodeId) // stpLogorg->iNode_id_org_rebuild)
			   {
				   stpRebuild_one_node_fsm->iDevno_rebuild =
						   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
			   }
			   else
			   {
				   stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
						   stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
				   nTotal_nodes_read ++;
			   }
		   }
//		   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg = 0;
		   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg =
				   (int)(stpLogorg->dStarting_stripe_rebuild_percentage * stpLogorg->nTotal_ckg_zones );
		   stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg = stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg;


		   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				   stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anStripe_id_per_ckg[0]+
					( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
							stpLogorg->nTotal_stripes_per_zone);

		   stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;

		   stpRebuild_one_node_fsm->nTotal_stripes =
				   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg *
				   stpLogorg->nTotal_ckg_rebuild_per_zone;

		   stpRebuild_one_node_fsm->nLBA_end = stpLogorg_dev->nLBA_end;
		   stpCurrend_rebuild_ckg_per_zone = stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;
           logorg_decluster_init_hot_spare_all_zones(stpLogorg); // @021
		   iFlag_org_is_rebuilding = 1;

	}
	else if(((stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg - stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg)== stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg &&
			stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone >= stpLogorg->nTotal_ckg_rebuild_per_zone)  ||
			(stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg - stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg) > stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg
			)
	{
		   stpRebuild_one_node_fsm->nTotal_stripes = 0;
		   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe = 0;
		   stpLogorg->iNode_id_org_rebuild = -1;

		   logorg_stop_rebuild();  // iFlag_org_is_rebuilding = 0;  // disksim_simstop();
	}

	else if(stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count < stpLogorg->nTotal_ckg_rebuild_per_zone)
	{ // build next ckg within current zone

		stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				stpCurrend_rebuild_ckg_per_zone->stpNext_list_item;
		stpCurrend_rebuild_ckg_per_zone =
				stpCurrend_rebuild_ckg_per_zone->stpNext_list_item;
		stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_id;

		for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		{
			iDev_org_id = stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			if(iDev_org_id == iRebuildNodeId) // stpLogorg->iNode_id_org_rebuild)
			{
				stpRebuild_one_node_fsm->iDevno_rebuild =
						stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
			}
			else
			{
				stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
						stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
				nTotal_nodes_read ++;
			}
		}

		stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anStripe_id_per_ckg[0] +
				( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
						stpLogorg->nTotal_stripes_per_zone);


	}
	else if(stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count == stpLogorg->nTotal_ckg_rebuild_per_zone)
	{ // build next zone,
		stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg ++;

		//
		stpRebuild_one_node_fsm->nCurrent_chunk_group_per_zone =
				stpOriginal_rebuild_zone_ckg_list_in_org->nCkg_rebuild_id;
		stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone =
				stpOriginal_rebuild_zone_ckg_list_in_org; // stpLogorg->stpRebuid_ckg_list_per_zone;
		stpCurrend_rebuild_ckg_per_zone =
					stpRebuild_one_node_fsm->stpCurrend_rebuild_ckg_per_zone;

		for(dd = 0; dd<stpLogorg->nNum_drives_per_ckg; dd++)
		{
			iDev_org_id = stpOriginal_rebuild_zone_ckg_list_in_org->stpCurrent_ckg->anDrive_id_per_ckg[dd];
			if(iDev_org_id == iRebuildNodeId) // stpLogorg->iNode_id_org_rebuild)
			{
				stpRebuild_one_node_fsm->iDevno_rebuild =
						stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
			}
			else
			{
				stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] =
						stpRebuild_one_node_fsm->anDev_id_per_org[iDev_org_id];
				nTotal_nodes_read ++;
			}
		}
		stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;
		stpRebuild_one_node_fsm->nCurrent_rebuild_stripe =
				stpCurrend_rebuild_ckg_per_zone->stpCurrent_ckg->anStripe_id_per_ckg[0] +
				( stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg *
						stpLogorg->nTotal_stripes_per_zone);

	}

	if(	stpCurrend_rebuild_ckg_per_zone->nCkg_rebuild_count == 1)
		// (stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg % 10) == 1 &&, prompt at the beginning of each zone
	{
	   fprintf(stderr, "%d/(%d, %d, %d)\n",
			   stpRebuild_one_node_fsm->nCurrent_rebuild_zone_ckg, stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg,
			   stpRebuild_one_node_fsm->nTotal_rebuild_zone_ckg, stpLogorg->nTotal_ckg_zones);
	}

}
// This function is for legacy-RAID5 and RAID6
static void logorg_rebuild_one_node_fsm(struct logorg *stpLogorg, int logorgnum)
{
	int dd;

	org_node_rebuild_event_fsm *stpRebuild_one_node_fsm = &stpLogorg->stRebuild_event_fsm;

	// Cond-1: initialization of a new rebuild
	if(stpRebuild_one_node_fsm->nTotal_stripes == 0)
	{
	   int iNodeId = stpLogorg->iNode_id_org_rebuild;
	   logorgdev *stpLogorg_dev = stpLogorg->devs;
	   int nTotal_nodes_read = 0;
	   for(dd=0; dd < stpLogorg->actualnumdisks; dd++)
	   {
		   if(dd == iNodeId )
		   {
			   stpRebuild_one_node_fsm->iDevno_rebuild = stpLogorg_dev->devno;
			   stpRebuild_one_node_fsm->nTotal_stripes =
					   (LBA_TYPE)((double)(stpLogorg_dev->nLBA_end - stpLogorg_dev->nLBA_start + 1)
					   /stpLogorg->stripeunit ) + 1;
			   if(stpLogorg->nTotal_stripes_zones_to_rebuild < 0) stpLogorg->nTotal_stripes_zones_to_rebuild = stpRebuild_one_node_fsm->nTotal_stripes;

			   stpRebuild_one_node_fsm->nLBA_end = stpLogorg_dev->nLBA_end;
		   }
		   else
		   {
			   stpRebuild_one_node_fsm->anRead_nodes_dev_no[nTotal_nodes_read] = stpLogorg_dev->devno;
			   nTotal_nodes_read ++;
		   }
		   stpLogorg_dev ++;
	   }
	   if(stpLogorg->reduntype == PARITY_ROTATED_TABLE_2)
	   {
		   nTotal_nodes_read = stpLogorg->actualnumdisks - 2;
	   }
	   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe = (LBA_TYPE)(stpLogorg->dStarting_stripe_rebuild_percentage
			   * stpRebuild_one_node_fsm->nTotal_stripes);
	   stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg = stpRebuild_one_node_fsm->nCurrent_rebuild_stripe;

	   iFlag_org_is_rebuilding = 1;
	   stpRebuild_one_node_fsm->nTotal_nodes_read = nTotal_nodes_read;


	}
	// Cond-2: Finite state machine to rebuild
	else if(stpRebuild_one_node_fsm->nCurrent_rebuild_stripe < stpRebuild_one_node_fsm->nTotal_stripes
			&&
			(stpRebuild_one_node_fsm->nCurrent_rebuild_stripe - stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg)< stpLogorg->nTotal_stripes_zones_to_rebuild
		   )
	{
	   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe ++;
	}
	// Cond-3: Just finished rebuilding one node
	else if(stpRebuild_one_node_fsm->nCurrent_rebuild_stripe == stpRebuild_one_node_fsm->nTotal_stripes ||
			(stpRebuild_one_node_fsm->nCurrent_rebuild_stripe - stpRebuild_one_node_fsm->nStarting_rebuild_stripe_zoneckg) >= stpLogorg->nTotal_stripes_zones_to_rebuild)
	{
	   stpRebuild_one_node_fsm->nTotal_stripes = 0;
	   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe = 0;
	   stpLogorg->iNode_id_org_rebuild = -1;
	   iFlag_org_is_rebuilding = 0;
	}

	if((stpRebuild_one_node_fsm->nCurrent_rebuild_stripe % 100) == 1)
	{
	   fprintf(stderr, "%d/(%d, %d)\n",
			   stpRebuild_one_node_fsm->nCurrent_rebuild_stripe,
			   stpRebuild_one_node_fsm->nTotal_stripes, stpLogorg->nTotal_stripes_zones_to_rebuild);
	}
}

// @016 periodically checking function for all orgs
void logorg_checking_drive_stripes_fsm(struct logorg *stpLogorg)
{
	int nTotalDrive = stpLogorg->actualnumdisks;
	ioreq_event *new_read_event, *ret;
	outstand * req;
	org_periodical_checking_fsm * stpPeriodic_checking_fsm = &(stpLogorg->stPeriodic_checking_fsm);
	int dd;
	logorgdev *stpLogorg_dev = stpLogorg->devs;

	for(dd = 0; dd< nTotalDrive; dd++)
	{
		new_read_event = (ioreq_event*) getfromextraq();
		new_read_event->blkno = stpPeriodic_checking_fsm->nCurrent_checking_stripe
					   * stpLogorg->stripeunit;
		new_read_event->devno = stpLogorg_dev->devno;
		new_read_event->flags = READ | MAPPED | BACKGROUND;
		new_read_event->time = simtime;

		stpLogorg_dev ++;

	   if(new_read_event->blkno + stpLogorg->stripeunit >= stpPeriodic_checking_fsm->nLBA_end)
	   {
		   new_read_event->bcount = stpPeriodic_checking_fsm->nLBA_end - new_read_event->blkno + 1;
	   }
	   else
	   {
		   new_read_event->bcount = stpLogorg->stripeunit;
	   }
	   new_read_event->type = IO_REQUEST_ARRIVE;
	   new_read_event->buf = 0;
	   new_read_event->opid = 0;
	   new_read_event->busno = 0;
	   new_read_event->cause = 0;

	   addtointq((event *)new_read_event);
	}

	req = (outstand *) getfromextraq();
	ASSERT (req != NULL);
	req->arrtime = new_read_event->time;
	req->bcount = new_read_event->bcount;
	req->blkno = new_read_event->blkno;
	req->devno = new_read_event->devno;
	req->flags = new_read_event->flags;
	req->busno = new_read_event->busno;
	req->buf = new_read_event->buf;
	req->reqopid = new_read_event->opid;
	req->depend = NULL;
	req->opid = 0;
	req->numreqs = nTotalDrive;
	logorg_addnewtooutstandq(stpLogorg, req);
	stpLogorg->opid ++;

	if(stpPeriodic_checking_fsm->nCurrent_checking_stripe >= stpLogorg->nTotal_stripes_zones_to_rebuild)
	{
		logorg_stop_rebuild();  // iFlag_org_is_rebuilding = 0;  // disksim_simstop();
	}
	if((stpPeriodic_checking_fsm->nCurrent_checking_stripe % 100) == 1)
	{
		   fprintf(stderr, "Checking: %d, total %d\n",
				   stpPeriodic_checking_fsm->nCurrent_checking_stripe,
				   stpLogorg->nTotal_stripes_zones_to_rebuild);
	}

}

// @016 idle work function
void logorg_idletime_detected (void *idleworkparam, int nIdle_logorg_num)
{
   struct logorg *stpLogorg = (struct logorg *)idleworkparam;
   int dd;
   int startit;

	if((stpLogorg->outstandqlen == 0 )
					  && stpLogorg->iFlag_rebuild_node_priority == ORG_REBUILD_PRIORITY_BACKGROUND )
	{
		stpLogorg->iFlag_check_idle_task_in_org = 1;
	}
	else if(stpLogorg->iFlag_rebuild_node_priority >= 1)
	{
		stpLogorg->iFlag_check_idle_task_in_org = 1;
	}
	else
	{
		stpLogorg->iFlag_check_idle_task_in_org = 0;
	}

	if(stpLogorg->iFlag_check_idle_task_in_org == 1)
	{
		   if(stpLogorg->iNode_id_org_rebuild >=0) // iFlag to rebuild disk
		   {
			   if(stpLogorg->reduntype == DECLUSTER_RAID)
			   {
//				   if(stpLogorg->iFlag_repair_node_stage == ORG_REPAIR_BY_FULL_DRIVE_REBUILD)
//				   {
//					   logorg_rebuild_one_node_by_ckg_fsm(stpLogorg, nIdle_logorg_num);
//				   }

			   }
			   else
			   {
				   logorg_rebuild_one_node_fsm(stpLogorg, nIdle_logorg_num);
			   }
		   }

		   if((stpLogorg->reduntype == DECLUSTER_RAID &&
				   (stpLogorg->stRebuild_event_fsm.nCurrent_rebuild_zone_ckg -
						   stpLogorg->stRebuild_event_fsm.nStarting_rebuild_stripe_zoneckg) >= stpLogorg->stRebuild_event_fsm.nTotal_rebuild_zone_ckg)
				||
				((stpLogorg->reduntype != DECLUSTER_RAID ) &&
				   stpLogorg->nTotal_stripes_zones_to_rebuild
				   == (stpLogorg->stRebuild_event_fsm.nCurrent_rebuild_stripe -
						   stpLogorg->stRebuild_event_fsm.nStarting_rebuild_stripe_zoneckg + 1)))
		   {
			   logorg_stop_rebuild();  // iFlag_org_is_rebuilding = 0;  // disksim_simstop();
			   return;
		   }

	}

   return;
}


org_rebuild_ckg_list_per_zone* logorg_create_new_item_in_rebuild_list(logorg *stpCurrorg)
{
	org_rebuild_ckg_list_per_zone* stpRebuild_ckg_list_per_zone =
			(org_rebuild_ckg_list_per_zone*)calloc(1, sizeof(org_rebuild_ckg_list_per_zone));

	stpRebuild_ckg_list_per_zone -> stpCurrent_ckg = stpCurrorg->stpInitial_rebuild_ckg_per_zone;
	stpRebuild_ckg_list_per_zone -> stpNext_ckg = stpCurrorg->stpInitial_rebuild_ckg_per_zone;
	stpRebuild_ckg_list_per_zone -> stpNext_list_item = stpRebuild_ckg_list_per_zone;
}

void logorg_build_parity_read_list_for_rebuild_local_reconstruct
			(logorg *stpLogorg, org_chunk_group_map *stpCurr_ckg,
					org_rebuild_ckg_list_per_zone *stpCurr_rebuild_ckg_in_fsm)
{
	int nTotal_parity_read, pp, dd, ll;
    int nTotal_data_nodes_in_failure = 0;
//    int nTotal_parity_nodes_in_failure = 0;
    int iFlag_dev_is_data_node;
    struct  _org_global_parity *stpCurr_global_parity;
    org_parity_pattern *stpCurr_parity_pattern;
    org_local_parity *stpCurr_local_parity;
    org_global_parity *stpGlobal_parity;

    stpCurr_parity_pattern = stpCurr_ckg->stpCurr_parity_pattern;

    // 1. check total number of data nodes in failure
    for(dd = 0; dd<stpLogorg->nTotal_drive_to_rebuild; dd++) // stpCurr_rebuild_ckg_in_fsm->nNum_drive_rebuild
    {
    	iFlag_dev_is_data_node = 0;
    	for(pp = 0; pp<stpCurr_parity_pattern->nNum_total_data_nodes; pp++)
    	{
    		if(stpCurr_ckg->anDrive_id_per_ckg[stpCurr_parity_pattern->aIdx_data_nodes[pp]] ==
    				stpLogorg->anNode_id_list_rebuild[dd])
    		{
    			iFlag_dev_is_data_node = 1;
    			pp = stpCurr_parity_pattern->nNum_total_data_nodes;
    		}
    	}
    	// length(find(anDrive_id_per_ckg(stParity_pattern.aIdx_data_nodes +1) == anDrive_idx_rebuild(dd))) >= 1
        if(iFlag_dev_is_data_node == 1)
            nTotal_data_nodes_in_failure ++;
//        else
//            nTotal_parity_nodes_in_failure ++;
    }
    //
    stpGlobal_parity = stpCurr_parity_pattern->stpGlobal_parity;
    for(pp=0; pp<stpCurr_parity_pattern->nNum_global_parity_nodes; pp++)
    {
    	if(logorg_check_id_in_rebuild_list(stpLogorg,
				stpCurr_ckg->anDrive_id_per_ckg[stpGlobal_parity->nIdx_node]
				                                ) == 1)
    	{
    		stpCurr_rebuild_ckg_in_fsm->cFlag_has_failure_in_global_parity = 1;
    		break;
    	}
    	stpGlobal_parity ++;
    }

    // if there is any failure in one parity group,
    //    all the data nodes and local parity in the corresponding parity group must be read

    nTotal_parity_read = 0;
    // 2.1. check local parity group,
    // the local parity node need reading,
    //   there is >= nodes failure, && the parity node is NOT failure.
    stpCurr_local_parity = stpCurr_parity_pattern->stpLocal_parity_group;
    for(ll = 0; ll<stpCurr_parity_pattern->nNum_local_parity_nodes; ll++)
    {
    	if(stpCurr_rebuild_ckg_in_fsm->anFailure_nodes_per_local_parity[ll] >= 1)
    	{
    		if(logorg_check_id_in_rebuild_list(stpLogorg,
    				stpCurr_ckg->anDrive_id_per_ckg[stpCurr_local_parity->nIdx_parity_node]
    				                                ) == 0)
    		{
                stpCurr_rebuild_ckg_in_fsm->anParity_node_read_list[nTotal_parity_read] =
                		stpCurr_ckg->anDrive_id_per_ckg[stpCurr_local_parity->nIdx_parity_node];

    			nTotal_parity_read ++;
    		}
    	}
    	stpCurr_local_parity ++;
    }

    // 2.2. check global parity group
    if(nTotal_parity_read < nTotal_data_nodes_in_failure)
    {
        stpCurr_global_parity = stpCurr_parity_pattern->stpGlobal_parity;
        for( pp = 0; pp < stpCurr_parity_pattern->nNum_global_parity_nodes; pp++)
        {
            if(logorg_check_id_in_rebuild_list(stpLogorg,
            		stpCurr_ckg->anDrive_id_per_ckg[stpCurr_global_parity->nIdx_node]) == 0)
            {
                // for a parity node, NOT in failure (s.t. can read)
                if( nTotal_parity_read < nTotal_data_nodes_in_failure)
                {
                    stpCurr_rebuild_ckg_in_fsm->anParity_node_read_list[nTotal_parity_read] =
                    		stpCurr_ckg->anDrive_id_per_ckg[stpCurr_global_parity->nIdx_node];
                    nTotal_parity_read ++;
                }
                else
                {
                    if( nTotal_parity_read >= nTotal_data_nodes_in_failure)
                        break;
                }
            }
            stpCurr_global_parity ++;
        }

    }
    stpCurr_rebuild_ckg_in_fsm->nTotal_parity_read = nTotal_parity_read;

}

// called during initialization,
void logorg_build_parity_read_list_for_rebuild_reed_solomon
			(logorg *stpLogorg, org_chunk_group_map *stpCurr_ckg,
					org_rebuild_ckg_list_per_zone *stpCurr_rebuild_ckg_in_fsm)
{
	int nTotal_parity_read, pp, dd;
    int nTotal_data_nodes_in_failure = 0;
//    int nTotal_parity_nodes_in_failure = 0;
    int iFlag_dev_is_data_node;
    struct  _org_global_parity *stpCurr_global_parity;
    org_parity_pattern *stpCurr_parity_pattern;

    stpCurr_parity_pattern = stpCurr_ckg->stpCurr_parity_pattern;
    for(dd = 0; dd<stpLogorg->nTotal_drive_to_rebuild; dd++) // stpCurr_rebuild_ckg_in_fsm->nNum_drive_rebuild
    {
    	iFlag_dev_is_data_node = 0;
    	for(pp = 0; pp<stpCurr_parity_pattern->nNum_total_data_nodes; pp++)
    	{
    		if(stpCurr_ckg->anDrive_id_per_ckg[stpCurr_parity_pattern->aIdx_data_nodes[pp]] ==
    				stpLogorg->anNode_id_list_rebuild[dd])
    		{
    			iFlag_dev_is_data_node = 1;
    			pp = stpCurr_parity_pattern->nNum_total_data_nodes;
    		}
    	}
    	// length(find(anDrive_id_per_ckg(stParity_pattern.aIdx_data_nodes +1) == anDrive_idx_rebuild(dd))) >= 1
        if(iFlag_dev_is_data_node == 1)
            nTotal_data_nodes_in_failure ++;
    }
    // nTotal_parity_read should be = nTotal_data_nodes_in_failure; %%
    nTotal_parity_read = 0;
    stpCurr_global_parity = stpCurr_parity_pattern->stpGlobal_parity;
    for( pp = 0; pp < stpCurr_parity_pattern->nNum_global_parity_nodes; pp++)
    {
    	// length(find(anDrive_idx_rebuild == anDrive_id_per_ckg(stParity_pattern.astGlobal_parity(pp).nIdx_node + 1))) <= 0
        if(logorg_check_id_in_rebuild_list(stpLogorg,
        		stpCurr_ckg->anDrive_id_per_ckg[stpCurr_global_parity->nIdx_node]) == 0)
        {
            // for a parity node, NOT in failure (s.t. can read)
            if( nTotal_parity_read < nTotal_data_nodes_in_failure)
            {
                stpCurr_rebuild_ckg_in_fsm->anParity_node_read_list[nTotal_parity_read] =
                		stpCurr_ckg->anDrive_id_per_ckg[stpCurr_global_parity->nIdx_node];
                nTotal_parity_read ++;
            }
            else
            {
                if( nTotal_parity_read >= nTotal_data_nodes_in_failure)
                    break;
            }
        }
        stpCurr_global_parity ++;
    }
    stpCurr_rebuild_ckg_in_fsm->nTotal_parity_read = nTotal_parity_read;
}

int  logorg_check_ckg_integrity(logorg *stpCurrorg)
{
	int iRet = 0, gg, jj, nDrvId, nChunkId;
	org_chunk_group_map * stpChunk_group_mapping;
	LBA_TYPE nTotal_active_ckgs_per_zone;
	int nNum_drives_per_ckg, nNum_drives_in_org;
	char *matCheckCKG;
	org_rebuild_ckg_list_per_zone* stpCurrent_rebuild_ckg;
	int iFlag_current_ckg_is_rebuild;

	stpChunk_group_mapping = stpCurrorg->stpChunk_group_mapping;
	nTotal_active_ckgs_per_zone = stpCurrorg->nTotal_active_ckgs_per_zone;
	nNum_drives_per_ckg = stpCurrorg->nNum_drives_per_ckg;

	stpCurrorg->aiCkg_id_rebuild_per_zone = (int *) calloc(nTotal_active_ckgs_per_zone, sizeof(char));
	stpCurrorg->nTotal_ckg_rebuild_per_zone = 0;

	nNum_drives_in_org = stpCurrorg->actualnumdisks;
	matCheckCKG = (char *) calloc(nTotal_active_ckgs_per_zone * nNum_drives_in_org, sizeof(char));

	for(gg = 0; gg<nTotal_active_ckgs_per_zone; gg ++)
	{
		iFlag_current_ckg_is_rebuild = 0;
		for(jj = 0; jj <nNum_drives_per_ckg; jj++)
		{
			nDrvId = stpChunk_group_mapping->anDrive_id_per_ckg[jj];
			nChunkId = stpChunk_group_mapping->anStripe_id_per_ckg[jj];
			matCheckCKG[nChunkId * nNum_drives_in_org + nDrvId] ++;
			if(matCheckCKG[nChunkId * nNum_drives_in_org + nDrvId] >= 2)
			{
				iRet = 1; // There is at least one chunk, used for multiple times.
			}

			// check for rebuild
			if(stpCurrorg->nTotal_drive_to_rebuild == 1)
			{
				if(nDrvId == stpCurrorg->iNode_id_org_rebuild)
				{
					iFlag_current_ckg_is_rebuild = 1;
					if(stpCurrorg->nTotal_ckg_rebuild_per_zone == 0)
					{
						stpCurrorg->stpInitial_rebuild_ckg_per_zone = stpChunk_group_mapping;
						stpCurrorg->stpRebuid_ckg_list_per_zone =
								logorg_create_new_item_in_rebuild_list(stpCurrorg);
						stpCurrent_rebuild_ckg = stpCurrorg->stpRebuid_ckg_list_per_zone;
					}
					else
					{
						// stpCurrorg->stpRebuid_ckg_list_per_zone
						stpCurrent_rebuild_ckg->stpNext_list_item =
								logorg_create_new_item_in_rebuild_list(stpCurrorg);
						// stpCurrorg->stpRebuid_ckg_list_per_zone
						stpCurrent_rebuild_ckg->stpNext_ckg =
								stpChunk_group_mapping;
						stpCurrent_rebuild_ckg =
								stpCurrent_rebuild_ckg->stpNext_list_item;
						//		stpCurrorg->stpRebuid_ckg_list_per_zone->stpNext_list_item;
						stpCurrent_rebuild_ckg->stpCurrent_ckg = stpChunk_group_mapping;
						stpCurrent_rebuild_ckg->nNum_drive_rebuild = 1;
					}
					stpCurrent_rebuild_ckg ->nCkg_rebuild_id = gg;

					stpCurrent_rebuild_ckg->nNum_drive_rebuild = 1;

					stpCurrorg->aiCkg_id_rebuild_per_zone[stpCurrorg->nTotal_ckg_rebuild_per_zone] = gg;
					stpCurrorg->nTotal_ckg_rebuild_per_zone ++;

					stpCurrent_rebuild_ckg ->nCkg_rebuild_count = stpCurrorg->nTotal_ckg_rebuild_per_zone;


				}
			}
			else if(stpCurrorg->nTotal_drive_to_rebuild >= 2)
			{
				if(logorg_check_id_in_rebuild_list(stpCurrorg, nDrvId) == 1 &&
						iFlag_current_ckg_is_rebuild == 0)
				{
					iFlag_current_ckg_is_rebuild = 1;

					if(stpCurrorg->nTotal_ckg_rebuild_per_zone == 0)
					{
						stpCurrorg->stpInitial_rebuild_ckg_per_zone = stpChunk_group_mapping;
						stpCurrorg->stpRebuid_ckg_list_per_zone =
								logorg_create_new_item_in_rebuild_list(stpCurrorg);
						stpCurrent_rebuild_ckg = stpCurrorg->stpRebuid_ckg_list_per_zone;

					}
					else
					{
						// stpCurrorg->stpRebuid_ckg_list_per_zone
						stpCurrent_rebuild_ckg->stpNext_list_item =
								logorg_create_new_item_in_rebuild_list(stpCurrorg);
						// stpCurrorg->stpRebuid_ckg_list_per_zone
						stpCurrent_rebuild_ckg->stpNext_ckg =
								stpChunk_group_mapping;
						stpCurrent_rebuild_ckg =
								stpCurrent_rebuild_ckg->stpNext_list_item;
						//		stpCurrorg->stpRebuid_ckg_list_per_zone->stpNext_list_item;
						stpCurrent_rebuild_ckg->stpCurrent_ckg = stpChunk_group_mapping;
					}
					stpCurrent_rebuild_ckg ->nCkg_rebuild_id = gg;

					stpCurrent_rebuild_ckg->nNum_drive_rebuild =
							logorg_check_num_drive_rebuild_by_ckg_list
							(stpCurrorg, stpChunk_group_mapping->anDrive_id_per_ckg);

					stpCurrorg->aiCkg_id_rebuild_per_zone[stpCurrorg->nTotal_ckg_rebuild_per_zone] = gg;
					stpCurrorg->nTotal_ckg_rebuild_per_zone ++;

					stpCurrent_rebuild_ckg ->nCkg_rebuild_count = stpCurrorg->nTotal_ckg_rebuild_per_zone;

				}
			}
		}

		// for rebuild-only
		if(iFlag_current_ckg_is_rebuild == 1)
		{
			// checking rebuild necessary condition
			int nNum_drive_rebuild = stpCurrent_rebuild_ckg->nNum_drive_rebuild;
			int nNum_parity_nodes = stpChunk_group_mapping->stpCurr_parity_pattern->nNum_total_parity_nodes;
			org_ddbg_assert((nNum_drive_rebuild <= nNum_parity_nodes),
					("Error CANNOT rebuild, Total failure drives: %d, total parity nodes: %d, parity pattern id: %d, CKG id: %d",
							nNum_drive_rebuild, nNum_parity_nodes,
							stpChunk_group_mapping->stpCurr_parity_pattern->nParity_pattern_id,
							stpChunk_group_mapping->nId_ckg));

			if(stpChunk_group_mapping->nType_raid == __ORG_DECLUSTER_LOCAL_RECONSTRUCTION__)
			{
				int nMax_num_failures_local_parity_group, nMin_num_failures_local_parity_group;

				int ll, dd, idxLocal_parity_with_max_failure, idxLocal_parity_with_min_failure;
				int anFailure_nodes_per_local_parity[MAX_NUM_LOCAL_PARITY_GROUP];
			    org_parity_pattern *stpCurr_parity_pattern;
			    org_local_parity *stpCurr_local_parity;

			    stpCurr_parity_pattern = stpCurrent_rebuild_ckg->stpCurrent_ckg->stpCurr_parity_pattern;
			    stpCurr_local_parity = stpCurr_parity_pattern->stpLocal_parity_group;

				for(ll = 0; ll < stpCurr_parity_pattern->nNum_local_parity_nodes; ll ++)
				{
					anFailure_nodes_per_local_parity[ll] = 0;
					if(logorg_check_id_in_rebuild_list(stpCurrorg,
							stpCurrent_rebuild_ckg->stpCurrent_ckg->anDrive_id_per_ckg[stpCurr_local_parity->nIdx_parity_node]) == 1)
					{
						anFailure_nodes_per_local_parity[ll] ++;
					}
					for(dd = 0; dd < stpCurr_local_parity->nNum_data_in_group; dd++)
					{
						if(logorg_check_id_in_rebuild_list(
								stpCurrorg,
								stpCurrent_rebuild_ckg->stpCurrent_ckg->anDrive_id_per_ckg[stpCurr_local_parity->aData_nodes[dd]]) == 1
								)
								{
									anFailure_nodes_per_local_parity[ll] ++;
								}

					}
					stpCurrent_rebuild_ckg->anFailure_nodes_per_local_parity[ll]
											           = anFailure_nodes_per_local_parity[ll];

					stpCurr_local_parity ++;
				}

				stpCurr_local_parity = stpCurr_parity_pattern->stpLocal_parity_group;
				if(nNum_drive_rebuild == nNum_parity_nodes)
				{
					// each local parity group must have
					for(ll = 0; ll < stpCurr_parity_pattern->nNum_local_parity_nodes; ll ++)
					{
						if(ll == 0)
						{
							nMin_num_failures_local_parity_group = anFailure_nodes_per_local_parity[0];
							nMax_num_failures_local_parity_group = anFailure_nodes_per_local_parity[0];
							idxLocal_parity_with_max_failure = 0;
							idxLocal_parity_with_min_failure = 0;
						}
						else
						{
							if(nMin_num_failures_local_parity_group > anFailure_nodes_per_local_parity[ll])
							{
								nMin_num_failures_local_parity_group = anFailure_nodes_per_local_parity[ll];
								idxLocal_parity_with_min_failure = ll;
							}
							if(nMax_num_failures_local_parity_group < anFailure_nodes_per_local_parity[ll])
							{
								nMax_num_failures_local_parity_group = anFailure_nodes_per_local_parity[ll];
								idxLocal_parity_with_max_failure = ll;
							}
						}
						stpCurr_local_parity ++;
					}

					org_ddbg_assert(( nMin_num_failures_local_parity_group <= 0),
							("CANNOT rebuild, Check CKG: %d, parity pattern: %d, idx local parity with (Max, Min) failures: %d, (Max, Min) local failures: (%d, %d), Total failure drives in CKG: %d, total parity nodes: %d",
									stpCurrent_rebuild_ckg->stpCurrent_ckg->nId_ckg,
									stpCurr_parity_pattern->nParity_pattern_id,
									idxLocal_parity_with_max_failure,
									nMax_num_failures_local_parity_group,
									nMin_num_failures_local_parity_group,
									nNum_drive_rebuild, nNum_parity_nodes));
				}
				// ... to add more complicated condition checking each individual local parity group


			}

			switch(stpChunk_group_mapping->nType_raid)
			{
			case 5:
				break;
			case 6:
				break;
			case __ORG_DECLUSTER_GENERAL_REED_SOLOMON__:
				logorg_build_parity_read_list_for_rebuild_reed_solomon
							(stpCurrorg, stpChunk_group_mapping,
									stpCurrent_rebuild_ckg);
				break;
			case __ORG_DECLUSTER_LOCAL_RECONSTRUCTION__:
				logorg_build_parity_read_list_for_rebuild_local_reconstruct
											(stpCurrorg, stpChunk_group_mapping,
													stpCurrent_rebuild_ckg);
				break;

			}

		}

		stpChunk_group_mapping ++;
	}
	if(iRet)
	{
		FILE *fptr;
		int nTotalAccessDriveStripe;
		fptr = fopen("CheckCKG.txt", "w");

		for(gg = 0; gg<nTotal_active_ckgs_per_zone; gg ++)
		{
			for(jj = 0; jj <nNum_drives_in_org; jj++)
			{
				nTotalAccessDriveStripe = matCheckCKG[gg * nNum_drives_in_org + jj];
				if(nTotalAccessDriveStripe >= 2)
				{
					fprintf(fptr, "Drive: %d, ChunkGroup:%d, AccessCount: %d\n", jj, gg, nTotalAccessDriveStripe);
				}
			}
		}
		fclose(fptr);

	}
	return iRet;
}

