/*
 * DiskSim Storage Subsystem Simulation Environment (Version 4.0)
 * Revision Authors: John Bucy, Greg Ganger
 * Contributors: John Griffin, Jiri Schindler, Steve Schlosser
 *
 * Copyright (c) of Carnegie Mellon University, 2001-2008.
 *
 * This software is being provided by the copyright holders under the
 * following license. By obtaining, using and/or copying this software,
 * you agree that you have read, understood, and will comply with the
 * following terms and conditions:
 *
 * Permission to reproduce, use, and prepare derivative works of this
 * software is granted provided the copyright and "No Warranty" statements
 * are included with all reproductions and derivative works and associated
 * documentation. This software may also be redistributed without charge
 * provided that the copyright and "No Warranty" statements are included
 * in all redistributions.
 *
 * NO WARRANTY. THIS SOFTWARE IS FURNISHED ON AN "AS IS" BASIS.
 * CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED AS TO THE MATTER INCLUDING, BUT NOT LIMITED
 * TO: WARRANTY OF FITNESS FOR PURPOSE OR MERCHANTABILITY, EXCLUSIVITY
 * OF RESULTS OR RESULTS OBTAINED FROM USE OF THIS SOFTWARE. CARNEGIE
 * MELLON UNIVERSITY DOES NOT MAKE ANY WARRANTY OF ANY KIND WITH RESPECT
 * TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.
 * COPYRIGHT HOLDERS WILL BEAR NO LIABILITY FOR ANY USE OF THIS SOFTWARE
 * OR DOCUMENTATION.
 *
 */


#include "config.h"
#include "disksim_global.h"
#include "disksim_iodriver.h"
#include "disksim_disk.h"

#include "modules/modules.h"

#include <libparam/libparam.h>

#include <diskmodel/modules/modules.h>
//#include <memsmodel/modules/modules.h>
/*SSD:*/

#if ZY_SSD_INCLUDED
#include <ssdmodel/modules/modules.h>
#endif

#include <stdio.h>



static void disksim_topoloader(struct lp_topospec *ts, int len) {
  int rv = load_iodriver_topo(ts, len);
  ddbg_assert2(rv != 0, "Topospec load failed!");
}

#include <disksim_cachemem.h>
#include <disksim_ctlr.h>
int disksim_loadparams(char *inputfile, int synthgen) {
  int rv;
  int c;
  struct lp_tlt **tlts = NULL;
  int tlts_len = 0;
  int ctlrno; // @8

  // register modules with libparam
  for(c = 0; c <= DISKSIM_MAX_MODULE; c++) {
    lp_register_module(disksim_mods[c]);
  }


  // diskmodel modules
  for(c = 0; c <= DM_MAX_MODULE; c++) {
    lp_register_module(dm_mods[c]);
  }

  // memsmodel modules
//  for(c = 0; c <= MEMSMODEL_MAX_MODULE; c++) {
//    lp_register_module(memsmodel_mods[c]);
//  }

  // ssdmodel modules  // @Hybrid_2
#if ZY_SSD_INCLUDED
  for(c = 0; c <= SSDMODEL_MAX_MODULE; c++) {
    lp_register_module(ssdmodel_mods[c]);
  }  // @Hybrid_2
#endif 
  lp_register_topoloader(disksim_topoloader);

  //  lp_init_typetbl();


  disksim->parfile = fopen(inputfile,"r");
  ddbg_assert2(disksim->parfile != NULL, 
	     ("Parameter file \"%s\" cannot be opened for read access\n", 
	      inputfile));

  lp_init_typetbl();

  rv = lp_loadfile(disksim->parfile, 
		   &tlts, 
		   &tlts_len, 
		   inputfile,
		   disksim->overrides,
		   disksim->overrides_len);

  lp_unparse_tlts(tlts, tlts_len, outputfile, inputfile);

  lp_instantiate("Global", "Global");
  lp_instantiate("Stats", "Stats");

  // instantiate any logorgs, syncsets we find
  for(c = 0; c < lp_typetbl_len; c++) {
    if(lp_typetbl[c] != 0 && (lp_typetbl[c]->spec != 0)) {
      if(!strcmp(lp_lookup_base_type(lp_typetbl[c]->sub, 0), "disksim_logorg")) {
	iodriver_load_logorg(lp_typetbl[c]->spec);
      }

      else if(!strcmp(lp_lookup_base_type(lp_typetbl[c]->sub, 0), "disksim_syncset")) {
	disk_load_syncsets(lp_typetbl[c]->spec);
      }
    }
  }

  // do this *after* logorgs get instantiated!
  if(synthgen) {
    lp_instantiate("Proc", "Proc");
    lp_instantiate("Synthio", "Synthio");
  }


  fclose(disksim->parfile);

// @10 register head related statistics,
//     For each head of the disk, assign the below variable statistics
//     anCountAccessPerHead, atXferTimePerHead, atLatencyTimePerHead
  int nNumHeadAtDisk;
  struct dm_disk_if stCurrDiskModel;
  DISK_POWER_PARAMETER *stpDiskPowerParameter;

  if( !disksim->diskinfo)
  {
	  return;
  }
  for(c=0; c< disksim->diskinfo->numdisks; c++)
  {
	  nNumHeadAtDisk = disksim->diskinfo->disks[c]->model->dm_surfaces;
	  disksim->diskinfo->disks[c]->stat.anCountAccessPerHead = calloc(nNumHeadAtDisk, sizeof(int));
	  disksim->diskinfo->disks[c]->stat.anCountReadPerHead =  calloc(nNumHeadAtDisk, sizeof(int));
	  disksim->diskinfo->disks[c]->stat.anCountWritePerHead =  calloc(nNumHeadAtDisk, sizeof(int));
	  disksim->diskinfo->disks[c]->stat.anRequestSizeAccessPerHead =  calloc(nNumHeadAtDisk, sizeof(int64_t));
	  disksim->diskinfo->disks[c]->stat.anRequestSizeReadPerHead =  calloc(nNumHeadAtDisk, sizeof(int64_t));
	  disksim->diskinfo->disks[c]->stat.anRequestSizeWritePerHead =  calloc(nNumHeadAtDisk, sizeof(int64_t));
	  disksim->diskinfo->disks[c]->stat.anCountCrossBoundaryPerHead = calloc(nNumHeadAtDisk, sizeof(int));
	  disksim->diskinfo->disks[c]->stat.anCountReadCrossBoundaryPerHead = calloc(nNumHeadAtDisk, sizeof(int));
	  disksim->diskinfo->disks[c]->stat.anCountWriteCrossBoundaryPerHead = calloc(nNumHeadAtDisk, sizeof(int));

	  disksim->diskinfo->disks[c]->stat.tAccessPerHead_ms = calloc(nNumHeadAtDisk, sizeof(double));
	  disksim->diskinfo->disks[c]->stat.tReadAccessPerHead_ms = calloc(nNumHeadAtDisk, sizeof(double));
	  disksim->diskinfo->disks[c]->stat.tWriteAccessPerHead_ms = calloc(nNumHeadAtDisk, sizeof(double));

	  disksim->diskinfo->disks[c]->tRegStartSeekTime = 0;
	  disksim->diskinfo->disks[c]->tRegEndSeekTime   = 0;
	  disksim->diskinfo->disks[c]->fRegSpindleEnergy = 0;
	  disksim->diskinfo->disks[c]->fRegVCM_BiasEnergy = 0;
	  disksim->diskinfo->disks[c]->nRegLastZone = 0;

	  stCurrDiskModel = *(disksim->diskinfo->disks[c]->model);
//	  dm_surfaces
  }
#define __DEF_MAX_CYLINDER_DIST__   500000
  // If some parameters & memory are NOT initialized,
  // the memory should be initialized and default parameter loaded
  int nNumZones;
  for(c=0; c< disksim->diskinfo->numdisks; c++)
  {
	  stCurrDiskModel = *(disksim->diskinfo->disks[c]->model);
	  stpDiskPowerParameter = (DISK_POWER_PARAMETER*) stCurrDiskModel.stpPowerHDD;
	  if(stpDiskPowerParameter->aidxZoneSpindlePower == 0 ||
		  stpDiskPowerParameter->afPowerSpindle == 0 ||
		  stpDiskPowerParameter->nTotalCntSpindlePowerAtZone <= 0)
	  {
		  nNumZones = stCurrDiskModel.layout->dm_get_numzones(&stCurrDiskModel);
		  stpDiskPowerParameter->aidxZoneSpindlePower =
				  calloc(nNumZones, sizeof(stpDiskPowerParameter->aidxZoneSpindlePower));
		  stpDiskPowerParameter->nTotalCntSpindlePowerAtZone = nNumZones;
		  for(int ii=0; ii<nNumZones; ii++)
		  {
			  //stpDiskPowerParametedevnor->aidxZoneSpindlePower[ii] = ii;
		  }
		  stpDiskPowerParameter->afPowerSpindle =
				  calloc(nNumZones, sizeof(stpDiskPowerParameter->afPowerSpindle));
	  }
	  if(stpDiskPowerParameter->aidxZoneVoiceCoilBiasPower == 0 ||
			  stpDiskPowerParameter->afPowerVCM_Bias == 0 ||
			  stpDiskPowerParameter->nTotalCntVoiceCoilBiasPowerAtZone <= 0  )
	  {
		  nNumZones = stCurrDiskModel.layout->dm_get_numzones(&stCurrDiskModel);
		  stpDiskPowerParameter->aidxZoneVoiceCoilBiasPower =
				  calloc(nNumZones, sizeof(stpDiskPowerParameter->aidxZoneVoiceCoilBiasPower));
		  stpDiskPowerParameter->nTotalCntVoiceCoilBiasPowerAtZone = nNumZones;
		  for(int ii=0; ii<nNumZones; ii++)
		  {
			  stpDiskPowerParameter->aidxZoneVoiceCoilBiasPower[ii] = ii;
		  }
		  stpDiskPowerParameter->afPowerVCM_Bias =
				  calloc(nNumZones, sizeof(stpDiskPowerParameter->afPowerVCM_Bias));

	  }
	  if(stpDiskPowerParameter->aidxSeekCylinderDist == 0 ||
			  stpDiskPowerParameter->afPowerVCM_RdSeekEnergy == 0 ||
			  stpDiskPowerParameter->afPowerVCM_WrSeekEnergy == 0 ||
			  stpDiskPowerParameter->nTotalCntVoiceCoilSeekTable <= 0 ||
			  stpDiskPowerParameter->nTotalCntVoiceCoilSeekTable > stCurrDiskModel.dm_cyls)
	  {
		  nNumZones = stCurrDiskModel.layout->dm_get_numzones(&stCurrDiskModel);
		  stpDiskPowerParameter->nTotalCntVoiceCoilSeekTable = stCurrDiskModel.dm_cyls;
		  stpDiskPowerParameter->aidxSeekCylinderDist =
				  calloc(stCurrDiskModel.dm_cyls, sizeof(stpDiskPowerParameter->aidxSeekCylinderDist));
		  for(int ii=0; ii<stCurrDiskModel.dm_cyls; ii++)
		  {
			  stpDiskPowerParameter->aidxSeekCylinderDist[ii] = ii;
		  }
		  stpDiskPowerParameter->afPowerVCM_RdSeekEnergy =
				  calloc(stCurrDiskModel.dm_cyls, sizeof(stpDiskPowerParameter->afPowerVCM_RdSeekEnergy));
		  stpDiskPowerParameter->afPowerVCM_WrSeekEnergy =
				  calloc(stCurrDiskModel.dm_cyls, sizeof(stpDiskPowerParameter->afPowerVCM_WrSeekEnergy));

	  }
  }
// @8 Zhengyi
  // The below section of code is originially working in the disksim_cachemem.c, function cachemem_setup_segs()
  // I tried to put at other places, but failed to find a better one,
  // The purpose to locate at here is to let the disksim be runnable for configuration, s.t. "Line size" is initialized even after "SLRU"
  //  so it can be backward compatible.
//#define __CACHE_LRU_SEGNUM__
#ifdef __CACHE_LRU_SEGNUM__
  ctlrinfo_t *ctlrinfo = disksim->ctlrinfo;
  controller *ctlr0_check = ctlrinfo->controllers[0]; // getctlr(0);
  struct cache_mem *cachemem = (struct cache_mem *)(ctlr0_check->cache); // (struct cache_mem *)(ctlr0_check->cache);
  struct cache_dev *cachedev = (struct cache_dev *)(ctlr0_check->cache); // type conversion.
  for(ctlrno=0; ctlrno< ctlrinfo->numcontrollers; ctlrno++)
  {
	  ctlr0_check = ctlrinfo->controllers[ctlrno];
	  cachemem = (struct cache_mem *)(ctlr0_check->cache);
//	  cachedev = (struct cache_dev *)(ctlr0_check->cache);
//	  if(cachedev->)
	  if(ctlr0_check->type == CTLR_SMART )
	  {
//		  if(cachemem->linezie)
		  if(cachemem->iFlagCacheMem == 1)  // @015
		  {
			  if(cachemem->linesize > 0
					  && cachemem->size >0
					  && cachemem->writefill_prefetch_type > 0 )    	// @8, Version 2.01.017.1, for the difference to cache_dev
			  {
				  for(c=0; c<cachemem->numsegs; c++)
				  {
					  cachemem->map[0].maxactive[c] = cachemem->map[0].maxactive[c]/cachemem->linesize;
				  }
			  }  // @8, Version 2.01.017.1
		  }
	  }
  }
#endif
  // @8
  return rv;
}

// End of file

