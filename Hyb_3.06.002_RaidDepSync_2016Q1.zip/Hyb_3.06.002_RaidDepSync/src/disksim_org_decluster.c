/*
 * disksim_org_decluster.c
 *
 *  Created on: Sep 3, 2015
 *      Author: zzytgx
 */

#include <string.h>
#include "disksim_logorg.h"
//#include "libddbg.h"


typedef struct _zone_ckg_sdripe_input
{
int nZone_id_next;
int nCkg_addr_next;
int nStripe_unit_addr_next;
int iFlag_first1_last2;
int nRemain_blks;
}zone_ckg_sdripe_input;
/////////////////////////////////////
/// Input
// stpLogorg: point to logorg struct
// stpZCS_input: pointer to Zone-CKG-stripe struct, i.e. zone_ckg_sdripe_input
/// Output
// stpData_parity_node: CKG address, pointer to logorg_ckg_addr_by_trace struct,
int org_calc_one_lba_by_zone_ckg_stripe_id(logorg * stpLogorg, zone_ckg_sdripe_input *stpZCS_input,
		logorg_ckg_addr_by_trace *stpData_parity_node)
{
int nNum_req = 0;

	////% abstract input
int	nZone_id = stpZCS_input->nZone_id_next ;
int	nCkg_id_in_zone = stpZCS_input->nCkg_addr_next;
int	nStrip_unit_id_in_ckg = stpZCS_input->nStripe_unit_addr_next;
int	iFlag_first1_last2 = stpZCS_input->iFlag_first1_last2;

	////% log organization config
//	stLogorgByCkg = stLogorg.stCkg_map.stLogorgByCkg;
int	nStripe_unit = stpLogorg->stripeunit;
//	stChunk_group_start = stLogorg.stCkg_map.astCurr_ckg_mapping(nCkg_id_in_zone+1);
//	nParity_pattern_id = stChunk_group_start.nParity_pattern_id;
//	stParity_pattern = stLogorg.stCkg_map.astParity_patterns(nParity_pattern_id);

org_chunk_group_map * stpChunk_group_start;
	stpChunk_group_start = stpLogorg->stpChunk_group_mapping; // stCkg_map.astCurr_ckg_mapping(nCkg_num_start+1);
	for(int cc = 0; cc< nCkg_id_in_zone; cc++)
	{
		stpChunk_group_start ++;
	}

int nParity_pattern_id = stpChunk_group_start->nParity_pattern_id; // .nParity_pattern_id;
org_parity_pattern * stpOrg_parity_pattern;

stpOrg_parity_pattern = stpLogorg->stpOrg_parity_pattern;  // stParity_pattern = stLogorg.stCkg_map.astParity_patterns(nParity_pattern_id);
    for(int pp=0; pp<nParity_pattern_id-1; pp++)
    {
    	stpOrg_parity_pattern ++;
    }

//	aIdx_data_drv_stripe = stLogorg.stCkg_map.astParity_patterns(nParity_pattern_id).aIdx_data_nodes;
int *aIdx_data_drv_stripe = stpOrg_parity_pattern->aIdx_data_nodes;

//
//	nIdx_curr_sdripe = aIdx_data_drv_stripe(nStrip_unit_id_in_ckg+ 1) ;
int nIdx_curr_sdripe = aIdx_data_drv_stripe[nStrip_unit_id_in_ckg] ;

//	nDrv_curr_id = stChunk_group_start.anDrive_id_per_ckg(nIdx_curr_sdripe+1);
int nDrv_curr_id = stpChunk_group_start->anDrive_id_per_ckg[nIdx_curr_sdripe];

//  nStripe_curr_id = stChunk_group_start.anStripe_id_per_ckg(nIdx_curr_sdripe+1);
int nStripe_curr_id = stpChunk_group_start->anStripe_id_per_ckg[nIdx_curr_sdripe];

LBA_TYPE    nLba_dev =
		(LBA_TYPE)(nZone_id * stpLogorg->nTotal_stripes_per_zone + nStripe_curr_id) * (LBA_TYPE)nStripe_unit;

    org_ddbg_assert((nLba_dev > 0),
    		("Error decoding LBA: %15.0f, Zone: %d, nTotal_stripes_per_zone: %d, nStripe_curr_id: %d, TotalZones: %d, File: %s, line: %d",
    		(double)nLba_dev, nZone_id, stpLogorg->nTotal_stripes_per_zone, nStripe_curr_id,
    		stpLogorg->nTotal_ckg_zones, __FILE__, __LINE__));

	stpData_parity_node->stData_node_trace.nLBA = nLba_dev;
	stpData_parity_node->stData_node_trace.iDev_id_in_org = nDrv_curr_id;
	stpData_parity_node->stData_node_trace.iDev_id_global =
			stpLogorg->stRebuild_event_fsm.anDev_id_per_org[nDrv_curr_id];
//			stLogorg.astDevice(nDrv_curr_id+1).nDev_id_global;

	if(iFlag_first1_last2 == 1)
	{
		// for integration with the 1st request
		// stpData_parity_node->stData_node_trace.nBlkCount = nStripe_unit - nLBA_offset_start;

	}
	else if( iFlag_first1_last2 == 2)
	{
		stpData_parity_node->stData_node_trace.nBlkCount = stpZCS_input->nRemain_blks;
	}
	else
	{
		stpData_parity_node->stData_node_trace.nBlkCount = nStripe_unit;
	}
	nNum_req ++;

	//% zone, ckg,
	stpData_parity_node->nZone_id = nZone_id;
	stpData_parity_node->nZone_addr_OBA = 0;
	stpData_parity_node->nCkg_id = nCkg_id_in_zone;
	stpData_parity_node->nCkg_addr_OBA = nStrip_unit_id_in_ckg;
	stpData_parity_node->nIdx_curr_sdripe = nIdx_curr_sdripe;
	stpData_parity_node->stpChunk_group = stpChunk_group_start;
	stpData_parity_node->stpOrg_parity_pattern = stpOrg_parity_pattern;
	stpData_parity_node->nLBA_offset_start = 0;

int nIdx_drv_ckg_parity, nDrv_id_ckg_parity, nStripe_id_ckg_parity, pp;
org_global_parity *stpCurr_global_parity = stpOrg_parity_pattern->stpGlobal_parity;

	for( pp = 0; pp< stpOrg_parity_pattern->nNum_global_parity_nodes; pp++)
	{
		nIdx_drv_ckg_parity = stpCurr_global_parity->nIdx_node;
		nDrv_id_ckg_parity = stpChunk_group_start->anDrive_id_per_ckg[nIdx_drv_ckg_parity];
		nStripe_id_ckg_parity = stpChunk_group_start->anStripe_id_per_ckg[nIdx_drv_ckg_parity];


		nLba_dev = (LBA_TYPE) (nZone_id * stpLogorg->nTotal_stripes_per_zone + nStripe_id_ckg_parity) * (LBA_TYPE)nStripe_unit;
	    org_ddbg_assert((nLba_dev > 0),
	    		("Error decoding LBA: %15.0f, Zone: %d, nTotal_stripes_per_zone: %d, nStripe_curr_id: %d, TotalZones: %d, File: %s, line: %d",
	    		(double)nLba_dev, nZone_id, stpLogorg->nTotal_stripes_per_zone, nStripe_curr_id,
	    		stpLogorg->nTotal_ckg_zones, __FILE__, __LINE__));
		stpData_parity_node->astParity_ckg_trace[pp].nLBA = nLba_dev;


		stpData_parity_node->astParity_ckg_trace[pp].iDev_id_in_org = nDrv_id_ckg_parity;
		stpData_parity_node->astParity_ckg_trace[pp].iDev_id_global = // stLogorg.astDevice(nDrv_id_ckg_parity+1).nDev_id_global;
				stpLogorg->stRebuild_event_fsm.anDev_id_per_org[nDrv_id_ckg_parity];
		stpData_parity_node->astParity_ckg_trace[pp].nOrder_ckg_parity =
				stpCurr_global_parity->nOrder;
		stpData_parity_node->astParity_ckg_trace[pp].nBlkCount =
				stpData_parity_node->stData_node_trace.nBlkCount;

		stpCurr_global_parity ++;
		nNum_req ++;
	}
	stpData_parity_node->nTotal_ckg_global_parity_trace = stpOrg_parity_pattern->nNum_global_parity_nodes;

//	    stpData_parity_node->stParity_loc_trace = [];
char cFlag_inside_local_parity_group = 0;
org_local_parity *stpCurr_local_parity_group;
int nIdx_drv_loc_parity, nDrv_id_loc_parity, nStripe_id_loc_parity, ll;

	if( stpOrg_parity_pattern->nNum_local_parity_nodes >= 1)
		// isfield(stParity_pattern, 'astLocal_parity_group')
	{
		stpCurr_local_parity_group = stpOrg_parity_pattern->stpLocal_parity_group;
		// consider only one-local parity
		for(pp = 0; pp < stpOrg_parity_pattern->nNum_local_parity_nodes; pp++)
		{
//			if( find(stpOrg_parity_pattern->astLocal_parity_group[pp].aData_nodes == nIdx_curr_sdripe))
//			{
//                nIdx_parity_stripe_unit = stpOrg_parity_pattern->astLocal_parity_group[pp].nIdx_parity_node;
			for(ll = 0; ll<stpCurr_local_parity_group->nNum_data_in_group; ll++)
			{
				if(nIdx_curr_sdripe == stpCurr_local_parity_group->aData_nodes[ll])
				{
					cFlag_inside_local_parity_group = 1;
					break;
				}

			}

			stpData_parity_node->cFlag_inside_local_parity_group = cFlag_inside_local_parity_group;
			if(cFlag_inside_local_parity_group == 1)
			{
				nIdx_drv_loc_parity = stpCurr_local_parity_group->nIdx_parity_node;
				nDrv_id_loc_parity = stpChunk_group_start->anDrive_id_per_ckg[nIdx_drv_loc_parity]; // +1);
				nStripe_id_loc_parity = stpChunk_group_start->anStripe_id_per_ckg[nIdx_drv_loc_parity]; // +1);

				nLba_dev = (LBA_TYPE)(nZone_id * stpLogorg->nTotal_stripes_per_zone + nStripe_id_loc_parity) * (LBA_TYPE)nStripe_unit;
			    org_ddbg_assert((nLba_dev > 0),
			    		("Error decoding LBA: %15.0f, Zone: %d, nTotal_stripes_per_zone: %d, nStripe_curr_id: %d, TotalZones: %d, File: %s, line: %d",
			    		(double)nLba_dev, nZone_id, stpLogorg->nTotal_stripes_per_zone, nStripe_curr_id,
			    		stpLogorg->nTotal_ckg_zones, __FILE__, __LINE__));
				stpData_parity_node->stParity_loc_trace.nLBA = nLba_dev;

				stpData_parity_node->stParity_loc_trace.iDev_id_in_org =
						nDrv_id_loc_parity;
				stpData_parity_node->stParity_loc_trace.iDev_id_global =
	//						stLogorg.astDevice(nDrv_id_loc_parity+1).nDev_id_global;
						stpLogorg->stRebuild_event_fsm.anDev_id_per_org[nDrv_id_loc_parity];
				stpData_parity_node->stParity_loc_trace.nOrder_ckg_parity = 1;  // one-local-parity, always 1st order

				stpData_parity_node->stParity_loc_trace.nBlkCount =
						stpData_parity_node->stData_node_trace.nBlkCount;

				nNum_req ++;
				break;
			}
			else
			{
				stpCurr_local_parity_group ++;
			}
//			}
		}
	}

	return nNum_req;

}
///////////////////////////////////////
/// Input
// stpLogorg: pointer to logorg struct
// curr: pointer to legacy disksim struct, i.e. ioreq_event
// numreqs: number of requests
/// Output
// stpOut_org_ckg_address: pointer to logorg_ckg_addr, if curr->bcount is >= stpLogorg->stripeunit, there will be multiple stripes affected.
//     For one stripe, there are data-nodes, and parity-nodes
//     an array, size of the array = num of Stripes

int logorg_decluster_ckg_with_parity_pattern(logorg *stpLogorg, ioreq_event *curr, int numreqs,
		logorg_ckg_addr *stpOut_org_ckg_address)
{
int nNum_request;

LBA_TYPE nLBA = curr->blkno;
int nBlkCount = curr->bcount;
LBA_TYPE nStripe_unit = stpLogorg->stripeunit;
LBA_TYPE nOBA_start = (LBA_TYPE)(nLBA / nStripe_unit);
LBA_TYPE nOBA_end = (LBA_TYPE)((nLBA + nBlkCount - 1) / nStripe_unit);
int nTotal_nodes = nOBA_end - nOBA_start + 1;
LBA_TYPE nLBA_offset_start = nLBA - nOBA_start * nStripe_unit;

int nZone_num_start = (int)(nOBA_start / stpLogorg->nTotal_active_OBAs_per_zone) ;
int nZone_addr_start = nOBA_start - (nZone_num_start ) * stpLogorg->nTotal_active_OBAs_per_zone ;

int nCkg_size = stpLogorg->nTotal_data_drives_per_ckg; // NOT stLogorgByCkg.nNumber_drives_per_ckg
int nCkg_num_start = (int)(nZone_addr_start / nCkg_size) ;
int nCkg_addr_start = nZone_addr_start - (nCkg_num_start )* nCkg_size ;

org_chunk_group_map * stpChunk_group_start;
	stpChunk_group_start = stpLogorg->stpChunk_group_mapping; // stCkg_map.astCurr_ckg_mapping(nCkg_num_start+1);
	for(int cc = 0; cc< nCkg_num_start; cc++)
	{
		stpChunk_group_start ++;
	}

int nParity_pattern_id = stpChunk_group_start->nParity_pattern_id; // .nParity_pattern_id;
org_parity_pattern * stpOrg_parity_pattern;

stpOrg_parity_pattern = stpLogorg->stpOrg_parity_pattern;  // stParity_pattern = stLogorg.stCkg_map.astParity_patterns(nParity_pattern_id);
    for(int pp=0; pp<nParity_pattern_id-1; pp++)
    {
    	stpOrg_parity_pattern ++;
    }

// stLogorg.stCkg_map.astParity_patterns(nParity_pattern_id).aIdx_data_nodes;
int *aIdx_data_drv_stripe = stpOrg_parity_pattern->aIdx_data_nodes;

int nIdx_curr_sdripe = aIdx_data_drv_stripe[nCkg_addr_start] ;
int nDrv_start_id = stpChunk_group_start->anDrive_id_per_ckg[nIdx_curr_sdripe];
int nStripe_start_id = stpChunk_group_start->anStripe_id_per_ckg[nIdx_curr_sdripe];

//////////////////////////////////////////////////////
// Calculate the nLba, for each {data, parity} - node

//logorg_ckg_addr stOrg_out_ckg_address;

	stpOut_org_ckg_address->nTotal_nodes = nTotal_nodes;
//	stpOut_org_ckg_address->stpCkg_data_parity_trace =
//			(logorg_ckg_addr_by_trace *) calloc(nTotal_nodes, sizeof(logorg_ckg_addr_by_trace));

// the below LBA includes the hotspare,
LBA_TYPE	nLba_dev =
			(LBA_TYPE)(nZone_num_start * stpLogorg->nTotal_stripes_per_zone + nStripe_start_id) * (LBA_TYPE)nStripe_unit
			+ (LBA_TYPE)nLBA_offset_start;
	stpOut_org_ckg_address->astCkg_data_parity_trace[0].stData_node_trace.nLBA = nLba_dev;
	stpOut_org_ckg_address->astCkg_data_parity_trace[0].stData_node_trace.iDev_id_in_org = nDrv_start_id;
	stpOut_org_ckg_address->astCkg_data_parity_trace[0].stData_node_trace.iDev_id_global =
			stpLogorg->stRebuild_event_fsm.anDev_id_per_org[nDrv_start_id];
	if( nTotal_nodes >= 2)
	{
		stpOut_org_ckg_address->astCkg_data_parity_trace[0].stData_node_trace.nBlkCount =
				nStripe_unit - nLBA_offset_start;
	}
	else
	{
		stpOut_org_ckg_address->astCkg_data_parity_trace[0].stData_node_trace.nBlkCount = nBlkCount;
	}

	//// zone, ckg,
	stpOut_org_ckg_address->astCkg_data_parity_trace[0].nZone_id = nZone_num_start;
	stpOut_org_ckg_address->astCkg_data_parity_trace[0].nZone_addr_OBA = nZone_addr_start;
	stpOut_org_ckg_address->astCkg_data_parity_trace[0].nCkg_id = nCkg_num_start;
	stpOut_org_ckg_address->astCkg_data_parity_trace[0].nCkg_addr_OBA = nCkg_addr_start;
	stpOut_org_ckg_address->astCkg_data_parity_trace[0].nIdx_curr_sdripe = nIdx_curr_sdripe;
	stpOut_org_ckg_address->astCkg_data_parity_trace[0].stpChunk_group = stpChunk_group_start;
	stpOut_org_ckg_address->astCkg_data_parity_trace[0].stpOrg_parity_pattern = stpOrg_parity_pattern;
	stpOut_org_ckg_address->astCkg_data_parity_trace[0].nLBA_offset_start = nLBA_offset_start;

	nNum_request = 1;
	int nIdx_drv_ckg_parity, nDrv_id_ckg_parity, nStripe_id_ckg_parity, pp;

	org_global_parity *stpCurr_global_parity = stpOrg_parity_pattern->stpGlobal_parity;
	for(pp = 0; pp < stpOrg_parity_pattern->nNum_global_parity_nodes; pp++)
	{
		nIdx_drv_ckg_parity = stpCurr_global_parity->nIdx_node; // stpOrg_parity_pattern->stpGlobal_parity[pp].nIdx_node;
		nDrv_id_ckg_parity = stpChunk_group_start->anDrive_id_per_ckg[nIdx_drv_ckg_parity];
		nStripe_id_ckg_parity = stpChunk_group_start->anStripe_id_per_ckg[nIdx_drv_ckg_parity];

		stpOut_org_ckg_address->astCkg_data_parity_trace[0].astParity_ckg_trace[pp].nLBA =
				nLBA_offset_start +
			(nZone_num_start * stpLogorg->nTotal_stripes_per_zone + nStripe_id_ckg_parity) * nStripe_unit;
		stpOut_org_ckg_address->astCkg_data_parity_trace[0].astParity_ckg_trace[pp].iDev_id_in_org =
				nDrv_id_ckg_parity;
		stpOut_org_ckg_address->astCkg_data_parity_trace[0].astParity_ckg_trace[pp].iDev_id_global =
				stpLogorg->stRebuild_event_fsm.anDev_id_per_org[nDrv_id_ckg_parity];
		stpOut_org_ckg_address->astCkg_data_parity_trace[0].astParity_ckg_trace[pp].nOrder_ckg_parity =
				stpCurr_global_parity->nOrder;
		stpOut_org_ckg_address->astCkg_data_parity_trace[0].astParity_ckg_trace[pp].nBlkCount =
				stpOut_org_ckg_address->astCkg_data_parity_trace[0].stData_node_trace.nBlkCount;

		stpCurr_global_parity ++;
		nNum_request ++;
	}
	stpOut_org_ckg_address->astCkg_data_parity_trace[0].nTotal_ckg_global_parity_trace = stpOrg_parity_pattern->nNum_global_parity_nodes;

//	stpOut_org_ckg_address->astCkg_data_parity_trace[0].stParity_loc_trace = [];
char cFlag_inside_local_parity_group = 0;
org_local_parity *stpCurr_local_parity_group;
int nIdx_drv_loc_parity, nDrv_id_loc_parity, nStripe_id_loc_parity, ll;
	if( stpOrg_parity_pattern->nNum_local_parity_nodes >= 1) // 'astLocal_parity_group')
	{
		// consider only one-local parity
		stpCurr_local_parity_group = stpOrg_parity_pattern->stpLocal_parity_group;
		cFlag_inside_local_parity_group = 0;
		for( pp = 0; pp< stpOrg_parity_pattern->nNum_local_parity_nodes; pp++)
		{
			for(ll = 0; ll<stpCurr_local_parity_group->nNum_data_in_group; ll++)
			{
				if(nIdx_curr_sdripe == stpCurr_local_parity_group->aData_nodes[ll])
				{
					cFlag_inside_local_parity_group = 1;
					break;
				}

			}

			stpOut_org_ckg_address->astCkg_data_parity_trace[0].cFlag_inside_local_parity_group = cFlag_inside_local_parity_group;

			if(cFlag_inside_local_parity_group == 1)
			{
				//// nIdx_parity_stripe_unit = stpOrg_parity_pattern->astLocal_parity_group[pp].nIdx_parity_node;
				nIdx_drv_loc_parity = stpCurr_local_parity_group->nIdx_parity_node;
				nDrv_id_loc_parity = stpChunk_group_start->anDrive_id_per_ckg[nIdx_drv_loc_parity];
				nStripe_id_loc_parity = stpChunk_group_start->anStripe_id_per_ckg[nIdx_drv_loc_parity];

				stpOut_org_ckg_address->astCkg_data_parity_trace[0].stParity_loc_trace.nLBA =
						nLBA_offset_start +
					(nZone_num_start * stpLogorg->nTotal_stripes_per_zone + nStripe_id_loc_parity) * nStripe_unit;
				stpOut_org_ckg_address->astCkg_data_parity_trace[0].stParity_loc_trace.iDev_id_in_org =
						nDrv_id_loc_parity;
				stpOut_org_ckg_address->astCkg_data_parity_trace[0].stParity_loc_trace.iDev_id_global =
						stpLogorg->stRebuild_event_fsm.anDev_id_per_org[nDrv_id_loc_parity];
				stpOut_org_ckg_address->astCkg_data_parity_trace[0].stParity_loc_trace.nOrder_ckg_parity = 1;  //// one-local-parity, always 1st order
				stpOut_org_ckg_address->astCkg_data_parity_trace[0].stParity_loc_trace.nBlkCount =
						stpOut_org_ckg_address->astCkg_data_parity_trace[0].stData_node_trace.nBlkCount;

				nNum_request ++;
				break;
			}
			else
			{
				stpCurr_local_parity_group ++;
			}
		}
	}

    ////////////////////////////////////////////%
    //////% the remaining nodes
int    nStripe_unit_addr_next = nCkg_addr_start;
int    nCkg_addr_next = nCkg_num_start;
int    nZone_id_next = nZone_num_start;
zone_ckg_sdripe_input stZone_ckg_sdripe_input;

    for(int dd = 1; dd<nTotal_nodes; dd++)
    {
        nStripe_unit_addr_next = nStripe_unit_addr_next + 1;
        if( nStripe_unit_addr_next >= stpLogorg->nTotal_data_drives_per_ckg )
        {
            nStripe_unit_addr_next = 0;
            nCkg_addr_next = nCkg_addr_next + 1;

            if( nCkg_addr_next >= nCkg_size )
            {
                nCkg_addr_next = 0;
                nZone_id_next = nZone_id_next + 1;
                //% nZone_id_next
                if( nZone_id_next >= stpLogorg->nTotal_ckg_zones )
                {
                    printf("Error, too large LBA, [nZone_id, Ckg_addr, Stripe_unit_addr, nLBA] = [%d, %d, %d, %d]: ",
                        nZone_id_next, nCkg_addr_next, nStripe_unit_addr_next, nLBA);
                }
            }
        }
        else
        {
            nCkg_addr_next = nCkg_addr_next;
            nZone_id_next = nZone_id_next;
        }


        //////// sdripe: [drive, stripe] unit
        stZone_ckg_sdripe_input.nZone_id_next = nZone_id_next;
        stZone_ckg_sdripe_input.nCkg_addr_next = nCkg_addr_next;
        stZone_ckg_sdripe_input.nStripe_unit_addr_next = nStripe_unit_addr_next;
        if( dd == nTotal_nodes - 1)
        {
            stZone_ckg_sdripe_input.iFlag_first1_last2 = 2;
        }
        else
        {
            stZone_ckg_sdripe_input.iFlag_first1_last2 = 0;
        }

        if( dd == 1 )
        {
            stZone_ckg_sdripe_input.nRemain_blks =
            		nBlkCount
            		- stpOut_org_ckg_address->astCkg_data_parity_trace[0].stData_node_trace.nBlkCount;
        }
        else
        {
            stZone_ckg_sdripe_input.nRemain_blks =
            		stZone_ckg_sdripe_input.nRemain_blks - nStripe_unit;
        }
        if( stZone_ckg_sdripe_input.nRemain_blks < 0 )
        {
            printf("Error, remaining 0 blocks\n");
        }


        nNum_request += org_calc_one_lba_by_zone_ckg_stripe_id(stpLogorg, &stZone_ckg_sdripe_input,
        		&(stpOut_org_ckg_address->astCkg_data_parity_trace[dd]));
        // stOrg_CKG_addr.astData_parity_node(dd) = stData_parity_node;

    }

    if(curr->flags & READ)
    {
    	return nTotal_nodes;
    }
    else
    {
    	return nNum_request;
    }
}

extern int __check_id_appear_in_know_int_list(int *aiList, int nList_len,        int id);

int logorg_gen_ckg_request(logorg *currlogorg,	ioreq_event *curr, logorg_ckg_addr *stpOrg_ckg_address)
{
ioreq_event *new_read_event, *ret, *new_wr_event;
outstand * req = NULL;
int tt, gg, nActual_total_req, nActual_total_write_req;
int iFlag_has_read_event = 0;
	nActual_total_req = 0;

	for(tt = 0; tt<stpOrg_ckg_address->nTotal_nodes; tt++)
	{
		if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
				currlogorg->nTotal_drive_to_rebuild,
				stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_in_org )
			)
		{
			continue;
		}
		else
		{
			iFlag_has_read_event = 1;
			new_read_event = (ioreq_event*) getfromextraq();
			new_read_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nLBA;
			new_read_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_global;
			new_read_event->flags = READ | MAPPED;
			new_read_event->time = simtime;
			new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nBlkCount;
			new_read_event->type = IO_REQUEST_ARRIVE;
			new_read_event->buf = 0;
			new_read_event->opid = currlogorg->opid;
			new_read_event->busno = 0;
			new_read_event->cause = 0;

			addtointq((event *)new_read_event);

			nActual_total_req ++;
		}
	}

	if(iFlag_has_read_event == 1)
	{

		req = (outstand *) getfromextraq();
		ASSERT (req != NULL);
		req->arrtime = new_read_event->time;
		req->bcount = new_read_event->bcount;
		req->blkno = new_read_event->blkno;
		req->devno = new_read_event->devno;
		req->flags = new_read_event->flags;
		req->busno = new_read_event->busno;
		req->buf = new_read_event->buf;
		req->reqopid = new_read_event->opid;
		req->depend = NULL;
		req->opid = currlogorg->opid;
	}

	if(curr->flags & READ
			&& iFlag_has_read_event == 1)
	{
	    req->numreqs = nActual_total_req;
	    logorg_addnewtooutstandq(currlogorg, req);

		currlogorg->opid++;

	}
	else
	{
		// Write trace for org, will generate Read, (Modify), Write trace
		/// OrgWrite-1: additional parity nodes read
		for(tt = 0; tt<stpOrg_ckg_address->nTotal_nodes; tt++)
		{
			for(gg = 0; gg<stpOrg_ckg_address->astCkg_data_parity_trace[tt].nTotal_ckg_global_parity_trace; gg++)
			{
				if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
						currlogorg->nTotal_drive_to_rebuild,
						stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_in_org )
					)
				{
					//continue;
				}
				else
				{
					iFlag_has_read_event = 1;
					new_read_event = (ioreq_event*) getfromextraq();

					new_read_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nLBA;
					new_read_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_global;
					new_read_event->flags = READ | MAPPED;
					new_read_event->time = simtime;
					new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nBlkCount;
					new_read_event->type = IO_REQUEST_ARRIVE;
					new_read_event->buf = 0;
					new_read_event->opid = currlogorg->opid;
					new_read_event->busno = 0;
					new_read_event->cause = 0;

					addtointq((event *)new_read_event);

					nActual_total_req ++;
				}
			}
			if(stpOrg_ckg_address->astCkg_data_parity_trace[tt].cFlag_inside_local_parity_group == 1)
			{

				if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
						currlogorg->nTotal_drive_to_rebuild,
						stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.iDev_id_in_org )
					)
				{
					continue;
				}
				else
				{

					new_read_event = (ioreq_event*) getfromextraq();

					new_read_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nLBA;
					new_read_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.iDev_id_global;
					new_read_event->flags = READ | MAPPED;
					new_read_event->time = simtime;
					new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nBlkCount;
					new_read_event->type = IO_REQUEST_ARRIVE;
					new_read_event->buf = 0;
					new_read_event->opid = currlogorg->opid;
					new_read_event->busno = 0;
					new_read_event->cause = 0;

					addtointq((event *)new_read_event);

					nActual_total_req ++;
				}
			}

		}
		/// OrgWrite-2 summary to org_req
		if(iFlag_has_read_event == 1)
		{
			if(req == NULL)
			{
				req = (outstand *) getfromextraq();
				ASSERT (req != NULL);
				req->arrtime = new_read_event->time;
				req->bcount = new_read_event->bcount;
				req->blkno = new_read_event->blkno;
				req->devno = new_read_event->devno;
				req->flags = new_read_event->flags;
				req->busno = new_read_event->busno;
				req->buf = new_read_event->buf;
				req->reqopid = new_read_event->opid;
				req->depend = NULL;
				req->opid = currlogorg->opid;
			}
			req->numreqs = nActual_total_req;
			logorg_addnewtooutstandq(currlogorg, req);
			currlogorg->opid++;
		}
		// OrgWrite-3: write event for the same nodes, time delay
	    int iFlag_has_write_event = 0;
		nActual_total_write_req = 0;
		for(tt = 0; tt<stpOrg_ckg_address->nTotal_nodes; tt++)
		{

			if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
					currlogorg->nTotal_drive_to_rebuild,
					stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_in_org )
				)
			{
				continue;
			}
			else
			{

				iFlag_has_write_event = 1;
				new_wr_event = (ioreq_event*) getfromextraq();

				new_wr_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nLBA;
				new_wr_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_global;
				new_wr_event->flags = WRITE | MAPPED;
				new_wr_event->time = simtime + TIME_DELAY_READ_CALC_ms;
				new_wr_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nBlkCount;
				new_wr_event->type = IO_REQUEST_ARRIVE;
				new_wr_event->buf = 0;
				new_wr_event->opid = currlogorg->opid;
				new_wr_event->busno = 0;
				new_wr_event->cause = 0;

				addtointq((event *)new_wr_event);

				nActual_total_write_req ++;
				nActual_total_req ++;
			}
		}

		for(tt = 0; tt<stpOrg_ckg_address->nTotal_nodes; tt++)
		{
			for(gg = 0; gg<stpOrg_ckg_address->astCkg_data_parity_trace[tt].nTotal_ckg_global_parity_trace; gg++)
			{
				if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
						currlogorg->nTotal_drive_to_rebuild,
						stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_in_org )
					)
				{
					//continue;
				}
				else
				{
					iFlag_has_write_event = 1;
					new_wr_event = (ioreq_event*) getfromextraq();

					new_wr_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nLBA;
					new_wr_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_global;
					new_wr_event->flags = WRITE | MAPPED;
					new_wr_event->time = simtime + TIME_DELAY_READ_CALC_ms;
					new_wr_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nBlkCount;
					new_wr_event->type = IO_REQUEST_ARRIVE;
					new_wr_event->buf = 0;
					new_wr_event->opid = currlogorg->opid;
					new_wr_event->busno = 0;
					new_wr_event->cause = 0;

					addtointq((event *)new_wr_event);

					nActual_total_write_req ++;
					nActual_total_req ++;
				}
			}
			if(stpOrg_ckg_address->astCkg_data_parity_trace[tt].cFlag_inside_local_parity_group == 1)
			{
				if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
						currlogorg->nTotal_drive_to_rebuild,
						stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.iDev_id_in_org )
					)
				{
					continue;
				}
				else
				{
					iFlag_has_write_event = 1;
					new_wr_event = (ioreq_event*) getfromextraq();

					new_wr_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nLBA;
					new_wr_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.iDev_id_global;
					new_wr_event->flags = WRITE | MAPPED;
					new_wr_event->time = simtime + TIME_DELAY_READ_CALC_ms;
					new_wr_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nBlkCount;
					new_wr_event->type = IO_REQUEST_ARRIVE;
					new_wr_event->buf = 0;
					new_wr_event->opid = currlogorg->opid;
					new_wr_event->busno = 0;
					new_wr_event->cause = 0;

					addtointq((event *)new_wr_event);

					nActual_total_write_req ++;
					nActual_total_req ++;
				}
			}

		}

		/// OrgWrite-4 summary to org_req
		if(iFlag_has_write_event == 1)
		{
			req = (outstand *) getfromextraq();
			ASSERT (req != NULL);
			req->arrtime = new_wr_event->time;
			req->bcount = new_wr_event->bcount;
			req->blkno = new_wr_event->blkno;
			req->devno = new_wr_event->devno;
			req->flags = new_wr_event->flags;
			req->busno = new_wr_event->busno;
			req->buf = new_wr_event->buf;
			req->reqopid = new_wr_event->opid;
			req->depend = NULL;
			req->opid = currlogorg->opid;
			req->numreqs = nActual_total_write_req;
			logorg_addnewtooutstandq(currlogorg, req);
			currlogorg->opid++;
		}
	}

	return nActual_total_req;
}


int logorg_gen_ckg_request_with_fail_node(logorg *currlogorg,	ioreq_event *curr, logorg_ckg_addr *stpOrg_ckg_address)
{
ioreq_event *new_read_event, *ret, *new_wr_event;
outstand * req = NULL;
int tt, gg, nActual_total_req, nActual_total_write_req;
int iFlag_has_read_event = 0;
org_chunk_group_map * stpCurr_ckg;
org_parity_pattern * stpCurr_parity_pattern;
int nStrip_unit_id_in_ckg;

int *aIdx_data_drv_stripe; //  = stpCurr_parity_pattern->aIdx_data_nodes;
int nIdx_curr_sdripe;      // = aIdx_data_drv_stripe[nStrip_unit_id_in_ckg] ;
int nDrv_curr_id;    //  = stpCurr_ckg->anDrive_id_per_ckg[nIdx_curr_sdripe];
int nStripe_curr_id; //  = stpCurr_ckg->anStripe_id_per_ckg[nIdx_curr_sdripe];
LBA_TYPE	nLba_dev;
char cFlag_has_read_loc_parity = 0;
char cFlag_has_read_glb_parity = 0;

	nActual_total_req = 0;

	for(tt = 0; tt<stpOrg_ckg_address->nTotal_nodes; tt++)
	{
		if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
				currlogorg->nTotal_drive_to_rebuild,
				stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_in_org )
			)
		{
			// read other data-nodes in the ckg
			iFlag_has_read_event = 1;
			stpCurr_ckg = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stpChunk_group;
			stpCurr_parity_pattern = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stpOrg_parity_pattern;
			aIdx_data_drv_stripe = stpCurr_parity_pattern->aIdx_data_nodes;
			for(int dd = 0; dd < stpCurr_ckg->nNum_data_nodes; dd++)
			{
				nStrip_unit_id_in_ckg = dd; // stpOrg_ckg_address->astCkg_data_parity_trace[tt].nCkg_addr_OBA;
				aIdx_data_drv_stripe = stpCurr_parity_pattern->aIdx_data_nodes;
				nIdx_curr_sdripe = aIdx_data_drv_stripe[nStrip_unit_id_in_ckg] ;
				nDrv_curr_id = stpCurr_ckg->anDrive_id_per_ckg[nIdx_curr_sdripe];

				if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild , currlogorg->nTotal_drive_to_rebuild,
						nDrv_curr_id) == 0)
				{
					nStripe_curr_id = stpCurr_ckg->anStripe_id_per_ckg[nIdx_curr_sdripe];
					nLba_dev = (LBA_TYPE)(stpOrg_ckg_address->astCkg_data_parity_trace[tt].nZone_id * currlogorg->nTotal_stripes_per_zone + nStripe_curr_id)
							* currlogorg->stripeunit
								+ (LBA_TYPE)stpOrg_ckg_address->astCkg_data_parity_trace[tt].nLBA_offset_start;

					new_read_event = (ioreq_event*) getfromextraq();
					new_read_event->blkno = nLba_dev;
					// stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_global
					new_read_event->devno = currlogorg->stRebuild_event_fsm.anDev_id_per_org[nDrv_curr_id];
					new_read_event->flags = READ | MAPPED | TIME_CRITICAL;
					new_read_event->time = simtime;
					new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nBlkCount;
					new_read_event->type = IO_REQUEST_ARRIVE;
					new_read_event->buf = 0;
					new_read_event->opid = currlogorg->opid;
					new_read_event->busno = 0;
					new_read_event->cause = 0;

					addtointq((event *)new_read_event);
					if(new_read_event->blkno == 37693528)						{
						;						}

					nActual_total_req ++;
				}
			}
			// read local-parity if there exist, and it's NOT failed
			if(stpOrg_ckg_address->astCkg_data_parity_trace[tt].cFlag_inside_local_parity_group == 1
					&&
					(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
							currlogorg->nTotal_drive_to_rebuild,
							stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.iDev_id_in_org
						) == 0)
				)
			{
				new_read_event = (ioreq_event*) getfromextraq();

				new_read_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nLBA;
				new_read_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.iDev_id_global;
				new_read_event->flags = READ | MAPPED | TIME_CRITICAL;
				new_read_event->time = simtime;
				new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nBlkCount;
				new_read_event->type = IO_REQUEST_ARRIVE;
				new_read_event->buf = 0;
				new_read_event->opid = currlogorg->opid;
				new_read_event->busno = 0;
				new_read_event->cause = 0;

				addtointq((event *)new_read_event);
				if(new_read_event->blkno == 37693528)				{					;				}

				nActual_total_req ++;
				cFlag_has_read_loc_parity = 1;
				iFlag_has_read_event = 1;
			}
			else
			// read global-parity
			{
				for(gg = 0; gg<stpOrg_ckg_address->astCkg_data_parity_trace[tt].nTotal_ckg_global_parity_trace; gg++)
				{
					if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
							currlogorg->nTotal_drive_to_rebuild,
							stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_in_org )
						==0)
					{
						iFlag_has_read_event = 1;
						new_read_event = (ioreq_event*) getfromextraq();

						new_read_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nLBA;
						new_read_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_global;
						new_read_event->flags = READ | MAPPED | TIME_CRITICAL;
						new_read_event->time = simtime;
						new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nBlkCount;
						new_read_event->type = IO_REQUEST_ARRIVE;
						new_read_event->buf = 0;
						new_read_event->opid = currlogorg->opid;
						new_read_event->busno = 0;
						new_read_event->cause = 0;

						addtointq((event *)new_read_event);

						if(new_read_event->blkno == 37693528)						{
							;						}
						nActual_total_req ++;
					}
				}
				cFlag_has_read_glb_parity = 1;
			}
			break; // need to handle multiple nodes, crossing CKG, and/or crossing zone
		}
		else
		{
			iFlag_has_read_event = 1;
			new_read_event = (ioreq_event*) getfromextraq();
			new_read_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nLBA;
			new_read_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_global;
			new_read_event->flags = READ | MAPPED;
			new_read_event->time = simtime;
			new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nBlkCount;
			new_read_event->type = IO_REQUEST_ARRIVE;
			new_read_event->buf = 0;
			new_read_event->opid = currlogorg->opid;
			new_read_event->busno = 0;
			new_read_event->cause = 0;

			addtointq((event *)new_read_event);

			nActual_total_req ++;
		}
	}

	if(iFlag_has_read_event == 1)
	{

		req = (outstand *) getfromextraq();
		ASSERT (req != NULL);
		req->arrtime = new_read_event->time;
		req->bcount = new_read_event->bcount;
		req->blkno = new_read_event->blkno;
		req->devno = new_read_event->devno;
		req->flags = new_read_event->flags;
		req->busno = new_read_event->busno;
		req->buf = new_read_event->buf;
		req->reqopid = new_read_event->opid;
		req->depend = NULL;
		req->opid = currlogorg->opid;
	}

	if(curr->flags & READ
			&& iFlag_has_read_event == 1)
	{
	    req->numreqs = nActual_total_req;
	    logorg_addnewtooutstandq(currlogorg, req);

		currlogorg->opid++;

	}
	else
	{
		// Write trace for org, will generate Read, (Modify), Write trace
		/// OrgWrite-1: additional parity nodes read
		for(tt = 0; tt<stpOrg_ckg_address->nTotal_nodes; tt++)
		{
			if(cFlag_has_read_glb_parity == 0)
			{
				for(gg = 0; gg<stpOrg_ckg_address->astCkg_data_parity_trace[tt].nTotal_ckg_global_parity_trace; gg++)
				{
					// if it happens that the global-ckg-node is NOT accessible
					if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
							currlogorg->nTotal_drive_to_rebuild,
							stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_in_org )
						)
					{
						// read other data-nodes in the ckg
						iFlag_has_read_event = 1;
						stpCurr_ckg = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stpChunk_group;
						stpCurr_parity_pattern = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stpOrg_parity_pattern;
						aIdx_data_drv_stripe = stpCurr_parity_pattern->aIdx_data_nodes;
						for(int dd = 0; dd < stpCurr_ckg->nNum_data_nodes; dd++)
						{
							nStrip_unit_id_in_ckg = dd; // stpOrg_ckg_address->astCkg_data_parity_trace[tt].nCkg_addr_OBA;
							aIdx_data_drv_stripe = stpCurr_parity_pattern->aIdx_data_nodes;
							nIdx_curr_sdripe = aIdx_data_drv_stripe[nStrip_unit_id_in_ckg] ;
							nDrv_curr_id = stpCurr_ckg->anDrive_id_per_ckg[nIdx_curr_sdripe];

							if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild , currlogorg->nTotal_drive_to_rebuild,
									nDrv_curr_id) == 0)
							{
								nStripe_curr_id = stpCurr_ckg->anStripe_id_per_ckg[nIdx_curr_sdripe];
								nLba_dev = (LBA_TYPE)(stpOrg_ckg_address->astCkg_data_parity_trace[tt].nZone_id * currlogorg->nTotal_stripes_per_zone + nStripe_curr_id)
										* currlogorg->stripeunit
											+ (LBA_TYPE) stpOrg_ckg_address->astCkg_data_parity_trace[tt].nLBA_offset_start;

								new_read_event = (ioreq_event*) getfromextraq();
								new_read_event->blkno = nLba_dev;
								// stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_global
								new_read_event->devno = currlogorg->stRebuild_event_fsm.anDev_id_per_org[nDrv_curr_id];
								new_read_event->flags = READ | MAPPED | TIME_CRITICAL;
								new_read_event->time = simtime;
								new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nBlkCount;
								new_read_event->type = IO_REQUEST_ARRIVE;
								new_read_event->buf = 0;
								new_read_event->opid = currlogorg->opid;
								new_read_event->busno = 0;
								new_read_event->cause = 0;

								addtointq((event *)new_read_event);
								if(new_read_event->blkno == 37693528)						{
									;						}

								nActual_total_req ++;
							}
						}

					}
					else
					{
						iFlag_has_read_event = 1;
						new_read_event = (ioreq_event*) getfromextraq();

						new_read_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nLBA;
						new_read_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_global;
						new_read_event->flags = READ | MAPPED;
						new_read_event->time = simtime;
						new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nBlkCount;
						new_read_event->type = IO_REQUEST_ARRIVE;
						new_read_event->buf = 0;
						new_read_event->opid = currlogorg->opid;
						new_read_event->busno = 0;
						new_read_event->cause = 0;

						addtointq((event *)new_read_event);

						nActual_total_req ++;
					}
				}
			}

			if(stpOrg_ckg_address->astCkg_data_parity_trace[tt].cFlag_inside_local_parity_group == 1 &&
					cFlag_has_read_loc_parity == 0)
			{

				if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
						currlogorg->nTotal_drive_to_rebuild,
						stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.iDev_id_in_org )
					)
				{
					continue;
				}
				else
				{

					new_read_event = (ioreq_event*) getfromextraq();

					new_read_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nLBA;
					new_read_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.iDev_id_global;
					new_read_event->flags = READ | MAPPED;
					new_read_event->time = simtime;
					new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nBlkCount;
					new_read_event->type = IO_REQUEST_ARRIVE;
					new_read_event->buf = 0;
					new_read_event->opid = currlogorg->opid;
					new_read_event->busno = 0;
					new_read_event->cause = 0;

					addtointq((event *)new_read_event);

					nActual_total_req ++;
				}
			}

		}
		/// OrgWrite-2 summary to org_req
		if(iFlag_has_read_event == 1)
		{
			if(req == NULL)
			{
				req = (outstand *) getfromextraq();
				ASSERT (req != NULL);
				req->arrtime = new_read_event->time;
				req->bcount = new_read_event->bcount;
				req->blkno = new_read_event->blkno;
				req->devno = new_read_event->devno;
				req->flags = new_read_event->flags;
				req->busno = new_read_event->busno;
				req->buf = new_read_event->buf;
				req->reqopid = new_read_event->opid;
				req->depend = NULL;
				req->opid = currlogorg->opid;
			}
			req->numreqs = nActual_total_req;
			logorg_addnewtooutstandq(currlogorg, req);
			currlogorg->opid++;
		}
		// OrgWrite-3: write event for the same nodes, time delay
	    int iFlag_has_write_event = 0;
		nActual_total_write_req = 0;
		for(tt = 0; tt<stpOrg_ckg_address->nTotal_nodes; tt++)
		{
			iFlag_has_write_event = 1;
			new_wr_event = (ioreq_event*) getfromextraq();

			if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
					currlogorg->nTotal_drive_to_rebuild,
					stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_in_org )
					&&
					(currlogorg->iFlag_repair_node_stage == ORG_REPAIR_BY_HOT_SPARE_CKG)
				)
			{
				int iZone_id = stpOrg_ckg_address->astCkg_data_parity_trace[tt].nZone_id;
				int iCkg_id = stpOrg_ckg_address->astCkg_data_parity_trace[tt].nCkg_id;
				int iFail_drv_id_org = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_in_org;

				int iHot_spare_map_zone_id = iZone_id -
						((int)(iZone_id/currlogorg->nTotal_stripes_zones_to_rebuild) * currlogorg->nTotal_stripes_zones_to_rebuild);
				org_hot_spare_mapping_per_zone_ckg * astHot_spare_mapping_per_zone_ckg;
				astHot_spare_mapping_per_zone_ckg =
						currlogorg->astHot_spare_mapping_per_zone_ckg[iHot_spare_map_zone_id * currlogorg->nTotal_active_ckgs_per_zone + iCkg_id];
				int idx;
				nLba_dev = (LBA_TYPE)(iZone_id * currlogorg->nTotal_stripes_per_zone + iCkg_id)
						* currlogorg->stripeunit
							+ (LBA_TYPE)stpOrg_ckg_address->astCkg_data_parity_trace[tt].nLBA_offset_start;

				for(int dd = 0; dd<astHot_spare_mapping_per_zone_ckg->nTotal_drv_failure; dd++)
				{
					if(iFail_drv_id_org == astHot_spare_mapping_per_zone_ckg->aiFailure_drv_id_in_org[dd])
					{
						idx = dd;
						break;
					}
				}
				new_wr_event->blkno = nLba_dev;
				new_wr_event->devno = astHot_spare_mapping_per_zone_ckg->aiHot_spare_drv_id_global[idx];


			}
			else
			{


				new_wr_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nLBA;
				new_wr_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_global;
			}

			new_wr_event->flags = WRITE | MAPPED;
			new_wr_event->time = simtime + TIME_DELAY_READ_CALC_ms;
			new_wr_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nBlkCount;
			new_wr_event->type = IO_REQUEST_ARRIVE;
			new_wr_event->buf = 0;
			new_wr_event->opid = currlogorg->opid;
			new_wr_event->busno = 0;
			new_wr_event->cause = 0;

			addtointq((event *)new_wr_event);

			nActual_total_write_req ++;
			nActual_total_req ++;

		}

		for(tt = 0; tt<stpOrg_ckg_address->nTotal_nodes; tt++)
		{
			for(gg = 0; gg<stpOrg_ckg_address->astCkg_data_parity_trace[tt].nTotal_ckg_global_parity_trace; gg++)
			{
				iFlag_has_write_event = 1;
				new_wr_event = (ioreq_event*) getfromextraq();
				if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
						currlogorg->nTotal_drive_to_rebuild,
						stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_in_org )
						&&
						(currlogorg->iFlag_repair_node_stage == ORG_REPAIR_BY_HOT_SPARE_CKG)
					)
				{
					int iZone_id = stpOrg_ckg_address->astCkg_data_parity_trace[tt].nZone_id;
					int iCkg_id = stpOrg_ckg_address->astCkg_data_parity_trace[tt].nCkg_id;
					int iFail_drv_id_org = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_in_org;

					int iHot_spare_map_zone_id = iZone_id -
							((int)(iZone_id/currlogorg->nTotal_stripes_zones_to_rebuild) * currlogorg->nTotal_stripes_zones_to_rebuild);
					org_hot_spare_mapping_per_zone_ckg * astHot_spare_mapping_per_zone_ckg;
					astHot_spare_mapping_per_zone_ckg =
							currlogorg->astHot_spare_mapping_per_zone_ckg[iHot_spare_map_zone_id * currlogorg->nTotal_active_ckgs_per_zone + iCkg_id];
					int idx;
					nLba_dev = (LBA_TYPE)(iZone_id * currlogorg->nTotal_stripes_per_zone + iCkg_id)
							* currlogorg->stripeunit
								+ (LBA_TYPE)stpOrg_ckg_address->astCkg_data_parity_trace[tt].nLBA_offset_start;

					for(int dd = 0; dd<astHot_spare_mapping_per_zone_ckg->nTotal_drv_failure; dd++)
					{
						if(iFail_drv_id_org == astHot_spare_mapping_per_zone_ckg->aiFailure_drv_id_in_org[dd])
						{
							idx = dd;
							break;
						}
					}
					new_wr_event->blkno = nLba_dev;
					new_wr_event->devno = astHot_spare_mapping_per_zone_ckg->aiHot_spare_drv_id_global[idx];

				}
				else
				{
					new_wr_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nLBA;
					new_wr_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_global;
				}

				new_wr_event->flags = WRITE | MAPPED;
				new_wr_event->time = simtime + TIME_DELAY_READ_CALC_ms;
				new_wr_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nBlkCount;
				new_wr_event->type = IO_REQUEST_ARRIVE;
				new_wr_event->buf = 0;
				new_wr_event->opid = currlogorg->opid;
				new_wr_event->busno = 0;
				new_wr_event->cause = 0;

				addtointq((event *)new_wr_event);

				nActual_total_write_req ++;
				nActual_total_req ++;

			}

			// check if it is inside some local parity group
			if(stpOrg_ckg_address->astCkg_data_parity_trace[tt].cFlag_inside_local_parity_group == 1)
			{
				iFlag_has_write_event = 1;
				new_wr_event = (ioreq_event*) getfromextraq();

				if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
						currlogorg->nTotal_drive_to_rebuild,
						stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.iDev_id_in_org )
						&&
						(currlogorg->iFlag_repair_node_stage == ORG_REPAIR_BY_HOT_SPARE_CKG)
					)
				{
					int iZone_id = stpOrg_ckg_address->astCkg_data_parity_trace[tt].nZone_id;
					int iCkg_id = stpOrg_ckg_address->astCkg_data_parity_trace[tt].nCkg_id;
					int iFail_drv_id_org = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.iDev_id_in_org;

					int iHot_spare_map_zone_id = iZone_id -
							((int)(iZone_id/currlogorg->nTotal_stripes_zones_to_rebuild) * currlogorg->nTotal_stripes_zones_to_rebuild);
					org_hot_spare_mapping_per_zone_ckg * astHot_spare_mapping_per_zone_ckg;
					astHot_spare_mapping_per_zone_ckg =
							currlogorg->astHot_spare_mapping_per_zone_ckg[iHot_spare_map_zone_id * currlogorg->nTotal_active_ckgs_per_zone + iCkg_id];
					int idx;
					nLba_dev = (LBA_TYPE)(iZone_id * currlogorg->nTotal_stripes_per_zone + iCkg_id)
							* currlogorg->stripeunit
								+ (LBA_TYPE)stpOrg_ckg_address->astCkg_data_parity_trace[tt].nLBA_offset_start;

					for(int dd = 0; dd<astHot_spare_mapping_per_zone_ckg->nTotal_drv_failure; dd++)
					{
						if(iFail_drv_id_org == astHot_spare_mapping_per_zone_ckg->aiFailure_drv_id_in_org[dd])
						{
							idx = dd;
							break;
						}
					}
					new_wr_event->blkno = nLba_dev;
					new_wr_event->devno = astHot_spare_mapping_per_zone_ckg->aiHot_spare_drv_id_global[idx];
				}
				else
				{

					new_wr_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nLBA;
					new_wr_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.iDev_id_global;
				}

				new_wr_event->flags = WRITE | MAPPED;
				new_wr_event->time = simtime + TIME_DELAY_READ_CALC_ms;
				new_wr_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nBlkCount;
				new_wr_event->type = IO_REQUEST_ARRIVE;
				new_wr_event->buf = 0;
				new_wr_event->opid = currlogorg->opid;
				new_wr_event->busno = 0;
				new_wr_event->cause = 0;

				addtointq((event *)new_wr_event);

				nActual_total_write_req ++;
				nActual_total_req ++;

			}

		}

		/// OrgWrite-4 summary to org_req
		if(iFlag_has_write_event == 1)
		{
			req = (outstand *) getfromextraq();
			ASSERT (req != NULL);
			req->arrtime = new_wr_event->time;
			req->bcount = new_wr_event->bcount;
			req->blkno = new_wr_event->blkno;
			req->devno = new_wr_event->devno;
			req->flags = new_wr_event->flags;
			req->busno = new_wr_event->busno;
			req->buf = new_wr_event->buf;
			req->reqopid = new_wr_event->opid;
			req->depend = NULL;
			req->opid = currlogorg->opid;
			req->numreqs = nActual_total_write_req;
			logorg_addnewtooutstandq(currlogorg, req);
			currlogorg->opid++;
		}
	}

	return nActual_total_req;
}

int logorg_gen_ckg_request_with_rmw_setting(logorg *currlogorg,	ioreq_event *curr, logorg_ckg_addr *stpOrg_ckg_address)
{
ioreq_event *new_read_event, *ret, *new_wr_event;
outstand * req = NULL;
int tt, gg, nActual_total_req, nActual_total_write_req;
int iFlag_has_read_event = 0;
org_chunk_group_map * stpCurr_ckg;
org_parity_pattern * stpCurr_parity_pattern;
int nStrip_unit_id_in_ckg;

int *aIdx_data_drv_stripe; //  = stpCurr_parity_pattern->aIdx_data_nodes;
int nIdx_curr_sdripe;      // = aIdx_data_drv_stripe[nStrip_unit_id_in_ckg] ;
int nDrv_curr_id;    //  = stpCurr_ckg->anDrive_id_per_ckg[nIdx_curr_sdripe];
int nStripe_curr_id; //  = stpCurr_ckg->anStripe_id_per_ckg[nIdx_curr_sdripe];
LBA_TYPE	nLba_dev;
char cFlag_has_read_loc_parity = 0;
char cFlag_has_read_glb_parity = 0;
int nOrg_read_dev_id;
	nActual_total_req = 0;

	for(tt = 0; tt<stpOrg_ckg_address->nTotal_nodes; tt++)
	{
/*		if(__check_id_appear_in_know_int_list(currlogorg->anNode_id_list_rebuild,
				currlogorg->nTotal_drive_to_rebuild,
				stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_in_org )
			)*/
		if(stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_in_org >= currlogorg->rmwpoint)
		{
			nOrg_read_dev_id = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_in_org;
			// read other data-nodes in the ckg to reconstruct
			iFlag_has_read_event = 1;
			stpCurr_ckg = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stpChunk_group;
			stpCurr_parity_pattern = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stpOrg_parity_pattern;
			aIdx_data_drv_stripe = stpCurr_parity_pattern->aIdx_data_nodes;
			for(int dd = 0; dd < stpCurr_ckg->nNum_data_nodes; dd++)
			{
				nStrip_unit_id_in_ckg = dd; // stpOrg_ckg_address->astCkg_data_parity_trace[tt].nCkg_addr_OBA;
				aIdx_data_drv_stripe = stpCurr_parity_pattern->aIdx_data_nodes;
				nIdx_curr_sdripe = aIdx_data_drv_stripe[nStrip_unit_id_in_ckg] ;
				nDrv_curr_id = stpCurr_ckg->anDrive_id_per_ckg[nIdx_curr_sdripe];

				if(nOrg_read_dev_id != nDrv_curr_id)
				{
					nStripe_curr_id = stpCurr_ckg->anStripe_id_per_ckg[nIdx_curr_sdripe];
					nLba_dev = (LBA_TYPE)(stpOrg_ckg_address->astCkg_data_parity_trace[tt].nZone_id * currlogorg->nTotal_stripes_per_zone + nStripe_curr_id)
							* currlogorg->stripeunit
								+ (LBA_TYPE)stpOrg_ckg_address->astCkg_data_parity_trace[tt].nLBA_offset_start;

					new_read_event = (ioreq_event*) getfromextraq();
					new_read_event->blkno = nLba_dev;
					// stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_global
					new_read_event->devno = currlogorg->stRebuild_event_fsm.anDev_id_per_org[nDrv_curr_id];
					new_read_event->flags = READ | MAPPED | TIME_CRITICAL;
					new_read_event->time = simtime;
					new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nBlkCount;
					new_read_event->type = IO_REQUEST_ARRIVE;
					new_read_event->buf = 0;
					new_read_event->opid = currlogorg->opid;
					new_read_event->busno = 0;
					new_read_event->cause = 0;

					addtointq((event *)new_read_event);
					if(new_read_event->blkno == 37693528)						{
						;						}

					nActual_total_req ++;
				}
			}
			// read local-parity if there exist
			if(stpOrg_ckg_address->astCkg_data_parity_trace[tt].cFlag_inside_local_parity_group == 1)
			{
				new_read_event = (ioreq_event*) getfromextraq();

				new_read_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nLBA;
				new_read_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.iDev_id_global;
				new_read_event->flags = READ | MAPPED | TIME_CRITICAL;
				new_read_event->time = simtime;
				new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nBlkCount;
				new_read_event->type = IO_REQUEST_ARRIVE;
				new_read_event->buf = 0;
				new_read_event->opid = currlogorg->opid;
				new_read_event->busno = 0;
				new_read_event->cause = 0;

				addtointq((event *)new_read_event);
				if(new_read_event->blkno == 37693528)				{					;				}

				nActual_total_req ++;
				cFlag_has_read_loc_parity = 1;
				iFlag_has_read_event = 1;
			}
			else
			// read global-parity
			{
				for(gg = 0; gg<stpOrg_ckg_address->astCkg_data_parity_trace[tt].nTotal_ckg_global_parity_trace; gg++)
				{

					iFlag_has_read_event = 1;
					new_read_event = (ioreq_event*) getfromextraq();

					new_read_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nLBA;
					new_read_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_global;
					new_read_event->flags = READ | MAPPED | TIME_CRITICAL;
					new_read_event->time = simtime;
					new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nBlkCount;
					new_read_event->type = IO_REQUEST_ARRIVE;
					new_read_event->buf = 0;
					new_read_event->opid = currlogorg->opid;
					new_read_event->busno = 0;
					new_read_event->cause = 0;

					addtointq((event *)new_read_event);

					if(new_read_event->blkno == 37693528)						{
						;						}
					nActual_total_req ++;

				}
				cFlag_has_read_glb_parity = 1;
			}
		}
		else  // read original node
		{
			iFlag_has_read_event = 1;
			new_read_event = (ioreq_event*) getfromextraq();
			new_read_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nLBA;
			new_read_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_global;
			new_read_event->flags = READ | MAPPED;
			new_read_event->time = simtime;
			new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nBlkCount;
			new_read_event->type = IO_REQUEST_ARRIVE;
			new_read_event->buf = 0;
			new_read_event->opid = currlogorg->opid;
			new_read_event->busno = 0;
			new_read_event->cause = 0;

			addtointq((event *)new_read_event);

			nActual_total_req ++;
		}
	}

	if(iFlag_has_read_event == 1)
	{

		req = (outstand *) getfromextraq();
		ASSERT (req != NULL);
		req->arrtime = new_read_event->time;
		req->bcount = new_read_event->bcount;
		req->blkno = new_read_event->blkno;
		req->devno = new_read_event->devno;
		req->flags = new_read_event->flags;
		req->busno = new_read_event->busno;
		req->buf = new_read_event->buf;
		req->reqopid = new_read_event->opid;
		req->depend = NULL;
		req->opid = currlogorg->opid;
	}

	if(curr->flags & READ
			&& iFlag_has_read_event == 1)
	{
	    req->numreqs = nActual_total_req;
	    logorg_addnewtooutstandq(currlogorg, req);

		currlogorg->opid++;

	}
	else
	{
		// Write trace for org, will generate Read, (Modify), Write trace
		/// OrgWrite-1: additional parity nodes read
		for(tt = 0; tt<stpOrg_ckg_address->nTotal_nodes; tt++)
		{
			if(cFlag_has_read_glb_parity == 0)
			{
				for(gg = 0; gg<stpOrg_ckg_address->astCkg_data_parity_trace[tt].nTotal_ckg_global_parity_trace; gg++)
				{
#ifdef __RECONSTRUCT_FOR_GLOBAL_PARITY__
					// if it happens that the global-ckg-node is NOT accessible
					if(stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_in_org >= currlogorg->rmwpoint)
					{
						nOrg_read_dev_id = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_in_org;

						// read other data-nodes in the ckg
						iFlag_has_read_event = 1;
						stpCurr_ckg = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stpChunk_group;
						stpCurr_parity_pattern = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stpOrg_parity_pattern;
						aIdx_data_drv_stripe = stpCurr_parity_pattern->aIdx_data_nodes;
						for(int dd = 0; dd < stpCurr_ckg->nNum_data_nodes; dd++)
						{
							nStrip_unit_id_in_ckg = dd; // stpOrg_ckg_address->astCkg_data_parity_trace[tt].nCkg_addr_OBA;
							aIdx_data_drv_stripe = stpCurr_parity_pattern->aIdx_data_nodes;
							nIdx_curr_sdripe = aIdx_data_drv_stripe[nStrip_unit_id_in_ckg] ;
							nDrv_curr_id = stpCurr_ckg->anDrive_id_per_ckg[nIdx_curr_sdripe];

							if(nOrg_read_dev_id != nDrv_curr_id)
							{
								nStripe_curr_id = stpCurr_ckg->anStripe_id_per_ckg[nIdx_curr_sdripe];
								nLba_dev = (LBA_TYPE)(stpOrg_ckg_address->astCkg_data_parity_trace[tt].nZone_id * currlogorg->nTotal_stripes_per_zone + nStripe_curr_id)
										* currlogorg->stripeunit
											+ (LBA_TYPE)stpOrg_ckg_address->astCkg_data_parity_trace[tt].nLBA_offset_start;

								new_read_event = (ioreq_event*) getfromextraq();
								new_read_event->blkno = nLba_dev;
								// stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_global
								new_read_event->devno = currlogorg->stRebuild_event_fsm.anDev_id_per_org[nDrv_curr_id];
								new_read_event->flags = READ | MAPPED | TIME_CRITICAL;
								new_read_event->time = simtime;
								new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nBlkCount;
								new_read_event->type = IO_REQUEST_ARRIVE;
								new_read_event->buf = 0;
								new_read_event->opid = currlogorg->opid;
								new_read_event->busno = 0;
								new_read_event->cause = 0;

								addtointq((event *)new_read_event);
								if(new_read_event->blkno == 37693528)						{
									;						}

								nActual_total_req ++;
							}
						}

					}
					else
#endif // __RECONSTRUCT_FOR_GLOBAL_PARITY__
					{
						iFlag_has_read_event = 1;
						new_read_event = (ioreq_event*) getfromextraq();

						new_read_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nLBA;
						new_read_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_global;
						new_read_event->flags = READ | MAPPED;
						new_read_event->time = simtime;
						new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nBlkCount;
						new_read_event->type = IO_REQUEST_ARRIVE;
						new_read_event->buf = 0;
						new_read_event->opid = currlogorg->opid;
						new_read_event->busno = 0;
						new_read_event->cause = 0;

						addtointq((event *)new_read_event);

						nActual_total_req ++;
					}
				}
			}

			if(stpOrg_ckg_address->astCkg_data_parity_trace[tt].cFlag_inside_local_parity_group == 1 &&
					cFlag_has_read_loc_parity == 0)
			{

					new_read_event = (ioreq_event*) getfromextraq();

					new_read_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nLBA;
					new_read_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.iDev_id_global;
					new_read_event->flags = READ | MAPPED;
					new_read_event->time = simtime;
					new_read_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nBlkCount;
					new_read_event->type = IO_REQUEST_ARRIVE;
					new_read_event->buf = 0;
					new_read_event->opid = currlogorg->opid;
					new_read_event->busno = 0;
					new_read_event->cause = 0;

					addtointq((event *)new_read_event);

					nActual_total_req ++;
			}

		}
		/// OrgWrite-2 summary to org_req
		if(iFlag_has_read_event == 1)
		{
			if(req == NULL)
			{
				req = (outstand *) getfromextraq();
				ASSERT (req != NULL);
				req->arrtime = new_read_event->time;
				req->bcount = new_read_event->bcount;
				req->blkno = new_read_event->blkno;
				req->devno = new_read_event->devno;
				req->flags = new_read_event->flags;
				req->busno = new_read_event->busno;
				req->buf = new_read_event->buf;
				req->reqopid = new_read_event->opid;
				req->depend = NULL;
				req->opid = currlogorg->opid;
			}
			req->numreqs = nActual_total_req;
			logorg_addnewtooutstandq(currlogorg, req);
			currlogorg->opid++;
		}
		// OrgWrite-3: write event for the same nodes, time delay
	    int iFlag_has_write_event = 0;
		nActual_total_write_req = 0;
		for(tt = 0; tt<stpOrg_ckg_address->nTotal_nodes; tt++)
		{
			iFlag_has_write_event = 1;
			new_wr_event = (ioreq_event*) getfromextraq();
			new_wr_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nLBA;
			new_wr_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.iDev_id_global;
			new_wr_event->flags = WRITE | MAPPED;
			new_wr_event->time = simtime + TIME_DELAY_READ_CALC_ms;
			new_wr_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stData_node_trace.nBlkCount;
			new_wr_event->type = IO_REQUEST_ARRIVE;
			new_wr_event->buf = 0;
			new_wr_event->opid = currlogorg->opid;
			new_wr_event->busno = 0;
			new_wr_event->cause = 0;

			addtointq((event *)new_wr_event);

			nActual_total_write_req ++;
			nActual_total_req ++;

		}

		for(tt = 0; tt<stpOrg_ckg_address->nTotal_nodes; tt++)
		{
			for(gg = 0; gg<stpOrg_ckg_address->astCkg_data_parity_trace[tt].nTotal_ckg_global_parity_trace; gg++)
			{
				iFlag_has_write_event = 1;
				new_wr_event = (ioreq_event*) getfromextraq();

				new_wr_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nLBA;
				new_wr_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].iDev_id_global;
				new_wr_event->flags = WRITE | MAPPED;
				new_wr_event->time = simtime + TIME_DELAY_READ_CALC_ms;
				new_wr_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].astParity_ckg_trace[gg].nBlkCount;
				new_wr_event->type = IO_REQUEST_ARRIVE;
				new_wr_event->buf = 0;
				new_wr_event->opid = currlogorg->opid;
				new_wr_event->busno = 0;
				new_wr_event->cause = 0;

				addtointq((event *)new_wr_event);

				nActual_total_write_req ++;
				nActual_total_req ++;

			}

			// check if it is inside some local parity group
			if(stpOrg_ckg_address->astCkg_data_parity_trace[tt].cFlag_inside_local_parity_group == 1)
			{
				iFlag_has_write_event = 1;
				new_wr_event = (ioreq_event*) getfromextraq();
				new_wr_event->blkno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nLBA;
				new_wr_event->devno = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.iDev_id_global;

				new_wr_event->flags = WRITE | MAPPED;
				new_wr_event->time = simtime + TIME_DELAY_READ_CALC_ms;
				new_wr_event->bcount = stpOrg_ckg_address->astCkg_data_parity_trace[tt].stParity_loc_trace.nBlkCount;
				new_wr_event->type = IO_REQUEST_ARRIVE;
				new_wr_event->buf = 0;
				new_wr_event->opid = currlogorg->opid;
				new_wr_event->busno = 0;
				new_wr_event->cause = 0;

				addtointq((event *)new_wr_event);

				nActual_total_write_req ++;
				nActual_total_req ++;

			}

		}

		/// OrgWrite-4 summary to org_req
		if(iFlag_has_write_event == 1)
		{
			req = (outstand *) getfromextraq();
			ASSERT (req != NULL);
			req->arrtime = new_wr_event->time;
			req->bcount = new_wr_event->bcount;
			req->blkno = new_wr_event->blkno;
			req->devno = new_wr_event->devno;
			req->flags = new_wr_event->flags;
			req->busno = new_wr_event->busno;
			req->buf = new_wr_event->buf;
			req->reqopid = new_wr_event->opid;
			req->depend = NULL;
			req->opid = currlogorg->opid;
			req->numreqs = nActual_total_write_req;
			logorg_addnewtooutstandq(currlogorg, req);
			currlogorg->opid++;
		}
	}

	return nActual_total_req;
}
