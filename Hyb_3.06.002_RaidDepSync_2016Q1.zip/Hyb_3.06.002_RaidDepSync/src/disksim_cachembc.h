/*
 * DiskSim Storage Subsystem Simulation Environment (Version 4.0)
 * Revision Authors: John Bucy, Greg Ganger
 * Contributors: John Griffin, Jiri Schindler, Steve Schlosser
 *
 * Copyright (c) of Carnegie Mellon University, 2001-2008.
 *
 * This software is being provided by the copyright holders under the
 * following license. By obtaining, using and/or copying this software,
 * you agree that you have read, understood, and will comply with the
 * following terms and conditions:
 *
 * Permission to reproduce, use, and prepare derivative works of this
 * software is granted provided the copyright and "No Warranty" statements
 * are included with all reproductions and derivative works and associated
 * documentation. This software may also be redistributed without charge
 * provided that the copyright and "No Warranty" statements are included
 * in all redistributions.
 *
 * NO WARRANTY. THIS SOFTWARE IS FURNISHED ON AN "AS IS" BASIS.
 * CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED AS TO THE MATTER INCLUDING, BUT NOT LIMITED
 * TO: WARRANTY OF FITNESS FOR PURPOSE OR MERCHANTABILITY, EXCLUSIVITY
 * OF RESULTS OR RESULTS OBTAINED FROM USE OF THIS SOFTWARE. CARNEGIE
 * MELLON UNIVERSITY DOES NOT MAKE ANY WARRANTY OF ANY KIND WITH RESPECT
 * TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.
 * COPYRIGHT HOLDERS WILL BEAR NO LIABILITY FOR ANY USE OF THIS SOFTWARE
 * OR DOCUMENTATION.
 *
 */



/*
 * DiskSim Storage Subsystem Simulation Environment (Version 2.0)
 * Revision Authors: Greg Ganger
 * Contributors: Ross Cohen, John Griffin, Steve Schlosser
 *
 * Copyright (c) of Carnegie Mellon University, 1999.
 *
 * Permission to reproduce, use, and prepare derivative works of
 * this software for internal use is granted provided the copyright
 * and "No Warranty" statements are included with all reproductions
 * and derivative works. This software may also be redistributed
 * without charge provided that the copyright and "No Warranty"
 * statements are included in all redistributions.
 *
 * NO WARRANTY. THIS SOFTWARE IS FURNISHED ON AN "AS IS" BASIS.
 * CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED AS TO THE MATTER INCLUDING, BUT NOT LIMITED
 * TO: WARRANTY OF FITNESS FOR PURPOSE OR MERCHANTABILITY, EXCLUSIVITY
 * OF RESULTS OR RESULTS OBTAINED FROM USE OF THIS SOFTWARE. CARNEGIE
 * MELLON UNIVERSITY DOES NOT MAKE ANY WARRANTY OF ANY KIND WITH RESPECT
 * TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.
 */

/*
 * DiskSim Storage Subsystem Simulation Environment
 * Authors: Greg Ganger, Bruce Worthington, Yale Patt
 *
 * Copyright (C) 1993, 1995, 1997 The Regents of the University of Michigan 
 *
 * This software is being provided by the copyright holders under the
 * following license. By obtaining, using and/or copying this software,
 * you agree that you have read, understood, and will comply with the
 * following terms and conditions:
 *
 * Permission to use, copy, modify, distribute, and sell this software
 * and its documentation for any purpose and without fee or royalty is
 * hereby granted, provided that the full text of this NOTICE appears on
 * ALL copies of the software and documentation or portions thereof,
 * including modifications, that you make.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS," AND COPYRIGHT HOLDERS MAKE NO
 * REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED. BY WAY OF EXAMPLE,
 * BUT NOT LIMITATION, COPYRIGHT HOLDERS MAKE NO REPRESENTATIONS OR
 * WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR
 * THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL NOT INFRINGE ANY
 * THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS. COPYRIGHT
 * HOLDERS WILL BEAR NO LIABILITY FOR ANY USE OF THIS SOFTWARE OR
 * DOCUMENTATION.
 *
 *  This software is provided AS IS, WITHOUT REPRESENTATION FROM THE
 * UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND
 * WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS
 * OF THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
 * INCLUDING SPECIAL , INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE
 * USE OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS
 * BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES
 *
 * The names and trademarks of copyright holders or authors may NOT be
 * used in advertising or publicity pertaining to the software without
 * specific, written prior permission. Title to copyright in this software
 * and any associated documentation will at all times remain with copyright
 * holders.
 */

// MBC = Media Based Cache
#ifndef DISKSIM_CACHEMBC_H
#define DISKSIM_CACHEMBC_H

#include "disksim_global.h"
#include "disksim_iosim.h"
#include "disksim_ioqueue.h"
#include "config.h"
#include "disksim_cache.h"
#include "red_black_tree.h"


#define MBC_SIZE_BLOCK  262144      // 128 MB MBC area


/* cache event types */

#define CACHE_EVENT_IOREQ               0
#define CACHE_EVENT_READ                1
#define CACHE_EVENT_POPULATE_ONLY       2
#define CACHE_EVENT_POPULATE_ALSO       3
#define CACHE_EVENT_WRITE               4
#define CACHE_EVENT_FLUSH               5
#define CACHE_EVENT_IDLEFLUSH_READ      6
#define CACHE_EVENT_IDLEFLUSH_FLUSH     7

/* cache write schemes */

#define CACHE_MBC_WRITE_MIN         1
#define CACHE_MBC_WRITE_BYPASS      0       // no cached writes, write directly to the backing store
#define CACHE_MBC_WRITE_SYNCONLY    1
#define CACHE_MBC_WRITE_THRU        2
#define CACHE_MBC_WRITE_MAX         3

/* cache background flush types */

#define CACHE_FLUSH_MIN         0
#define CACHE_FLUSH_DEMANDONLY  0
#define CACHE_FLUSH_PERIODIC    1
#define CACHE_FLUSH_MAX         1

// cache hit states
#define CACHE_HIT_MISS      0
#define CACHE_HIT_PARTIAL   1
#define CACHE_HIT_FULL      2

struct cache_mbc_event {
   double time;
   int type;
   struct cache_mbc_event *next;
   struct cache_mbc_event *prev;
   void (**donefunc)(void *,ioreq_event *);	/* Function to call when complete */
   void *doneparam;		/* parameter for donefunc */
   int flags;
   ioreq_event *req;
   struct cache_mbc_event *waitees;
   int validpoint;
};

struct cache_mbc_stats {
   int reads;
   int readblocks;
   int readhitsfull;
   int readhitspartial;
   int readmisses;
   int popwrites;
   int popwriteblocks;
   int writes;
   int writeblocks;
   int writehitsfull;
   int writemisses;
   int destagereads;
   int destagereadblocks;
   int destagewrites;
   int destagewriteblocks;
   int maxbufferspace;
};

// data structure to maintain the location of the MBC area
typedef struct cachembc_location
{
    //int devno;                      // device where MBC is located
    LBA_TYPE startLBA;                   // LBA where the MBC area begins, @9
    int bcount;                     // size of the MBC area in blocks
    int headBlockIndex;             // index to the head of the cache (next block write location)
    int tailBlockIndex;             // index to the tail of the cache (next block flush location)
    //struct cachembc_location *next; // pointer to the next MBC location data
    //struct cachembc_location *prev; // pointer to the previous MBC location data
} cachembc_location_t;

struct cache_mbc {
   struct cache_if hdr;
   void (**issuefunc)(void *,ioreq_event *);	        /* to issue a disk access    */
   void *issueparam;				                    /* first param for issuefunc */
   struct ioq * (**queuefind)(void *,int);	            /* to get ioqueue ptr for dev*/
   void *queuefindparam;			                    /* first param for queuefind */
   // void (**wakeupfunc)(void *,void *);	            /* to re-activate slept proc */
   void (**wakeupfunc)(void *, struct cacheevent *);	/* to re-activate slept proc */
   void *wakeupparam;				                    /* first param for wakeupfunc */
   int size;					                        /* in 512B blks  */
   // device info
   int devno;                                           // device used for both user and cache data, @9
   LBA_TYPE maxLBA;                                          // adjusted max LBA after all MBC areas are allocated
   //int cache_devno;				                    /* device used for cache */
   //int real_devno;				                    /* device for which cache is used */
   int maxreqsize;
   int writescheme;
   int flush_policy;
   double flush_period;
   double flush_idledelay;
   int bufferspace;
   struct cache_mbc_event *ongoing_requests;
//   bitstr_t *validmap;
//   bitstr_t *dirtymap;
   struct cache_mbc_stats stat;
   char *name;

   rb_red_blk_tree*  hostTree;              // red/black tree used for host read / write requests
   rb_red_blk_tree*  diskTree;	            // red/black tree used for destaging MBC
   cachembc_location_t *mbcLocations;       // pointer to an array of locations of the MBC cache reqions (ascending order)
   int numReadIoreqSegments;                // number of ioreq_event objects created for a read
   int read_hit_state;                      // one of CACHE_HIT_XXX
   int write_hit_state;                     // 1 = cache area write, 0 = user area write

   double mbc_percentage;                   // percentange of disk capacity to be used for mbc
   int mbcSizeBlocks;                       // size in blocks of an MBC area
   int numMbcRegions;                       // number of MBC regions on the disk

   // User settable parameters (parameter file)

};

void cachembc_setcallbacks(void);

LBA_TYPE cachembc_calc_num_available_blocks( struct cache_mbc *cache, int mbcIndex  );
LBA_TYPE cachembc_convert_host_blkno_to_user_blkno(  struct cache_mbc *cache, LBA_TYPE reqBlkno );
int cachembc_find_closest_mbc_area( struct cache_mbc *cache, LBA_TYPE userBlkno );
int load_mbc_locations(struct cache_mbc *result, struct lp_list *list );

#endif // DISKSIM_CACHEDEV_H



