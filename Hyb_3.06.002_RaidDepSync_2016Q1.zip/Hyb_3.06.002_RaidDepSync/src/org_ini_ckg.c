/*
 * org_ini_ckg.c
 *
 *  Created on: Aug 28, 2015
 *      Author: zhengyi.zhao@wdc.com
 */

#include <string.h>

#include "disksim_logorg.h"
#include "org_parity.h"

void _org_decode_ckg_with_local_reconstruction(int nNum_drives_per_ckg, // input
		char * linebuf,									// input string buffer
		org_chunk_group_map *stpCurr_ckg_mapping)       // output
{
char *pCh, *pCh_next;
int nNum_data_nodes, nNum_parity_nodes, nNum_global_parity, nNum_local_parity;

	pCh = linebuf;
	sscanf(pCh, "[%d, LRC_D%d_GP%d_LP%d_ptn_%d,", &stpCurr_ckg_mapping->nId_ckg,
			&nNum_data_nodes, &nNum_global_parity, &nNum_local_parity,
			&stpCurr_ckg_mapping->nParity_pattern_id);

	if(stpCurr_ckg_mapping->nNum_data_nodes != nNum_data_nodes
			|| stpCurr_ckg_mapping->nNum_global_parity_nodes != nNum_global_parity
			|| stpCurr_ckg_mapping->nNum_local_parity_nodes != nNum_local_parity)
	{
		printf("Error, pattern %d, NOT match, LRC_D%d_GP%d_LP%d, %s\n", stpCurr_ckg_mapping->nParity_pattern_id,
				stpCurr_ckg_mapping->nNum_data_nodes,
				stpCurr_ckg_mapping->nNum_global_parity_nodes,
				stpCurr_ckg_mapping->nNum_local_parity_nodes,
				linebuf);
	}

	stpCurr_ckg_mapping->nType_raid = __ORG_DECLUSTER_LOCAL_RECONSTRUCTION__;


	pCh_next = strstr(pCh, "<");
	if(pCh_next != NULL)
	{
		pCh = pCh_next;
	}
	switch(nNum_drives_per_ckg)
				{
				case 1:
					sscanf(pCh, "<%d, %d>]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0]
							);
					break;
				case 2:
					sscanf(pCh, "<%d, %d>, <%d, %d>]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1]
							);
					break;
				case 3:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2]
							);
					break;
				case 4:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3]
							);
					break;
				case 5:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4]
							);
					break;
				case 6:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5]
							);
					break;
				case 7:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6]
							);
					break;
				case 8:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7]
							);
					break;
				case 9:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8]
							);
					break;
				case 10:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9]
							);
					break;
				case 11:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10]
							);
					break;
				case 12:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11]
							);
					break;
				case 13:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12]
							);
					break;
				case 14:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13]
							);
					break;
				case 15:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14]
							);
					break;
				case 16:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15]
							);
					break;
				case 17:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16]
							);
					break;
				case 18:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17]
							);
					break;
				case 19:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18]
							);
					break;
				case 20:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19]
							);
					break;
				case 21:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20]
							);
					break;
				case 22:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21]
							);
					break;
				case 23:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22]
							);
					break;
				case 24:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23]
							);
					break;
				case 25:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24]
							);
					break;
				case 26:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25]
							);
					break;
				case 27:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26]
							);
					break;
				case 28:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27]
							);
					break;
				case 29:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[28], &stpCurr_ckg_mapping->anStripe_id_per_ckg[28]
							);
					break;

				case 30:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[28], &stpCurr_ckg_mapping->anStripe_id_per_ckg[28],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[29], &stpCurr_ckg_mapping->anStripe_id_per_ckg[29]
							);
					break;

				case 31:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[28], &stpCurr_ckg_mapping->anStripe_id_per_ckg[28],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[29], &stpCurr_ckg_mapping->anStripe_id_per_ckg[29],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[30], &stpCurr_ckg_mapping->anStripe_id_per_ckg[30]
							);
					break;

				case 32:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[28], &stpCurr_ckg_mapping->anStripe_id_per_ckg[28],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[29], &stpCurr_ckg_mapping->anStripe_id_per_ckg[29],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[30], &stpCurr_ckg_mapping->anStripe_id_per_ckg[30],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[31], &stpCurr_ckg_mapping->anStripe_id_per_ckg[31]
							);
					break;

				}

}


void _org_decode_ckg_with_reed_solomon(int nNum_drives_per_ckg, // input
		char * linebuf,									// input string buffer
		org_chunk_group_map *stpCurr_ckg_mapping)       // output
{
char *pCh, *pCh_next;
int nNum_data_nodes, nNum_parity_nodes;

	pCh = linebuf;
	sscanf(pCh, "[%d, RS_D%d_P%d_ptn_%d,", &stpCurr_ckg_mapping->nId_ckg,
			&nNum_data_nodes, &nNum_parity_nodes, &stpCurr_ckg_mapping->nParity_pattern_id);
	if(stpCurr_ckg_mapping->nNum_data_nodes != nNum_data_nodes
			|| stpCurr_ckg_mapping->nNum_global_parity_nodes != nNum_parity_nodes)
	{
		printf("Error, pattern %d, NOT match, RS_D%d_P%d, %s\n", stpCurr_ckg_mapping->nParity_pattern_id,
				stpCurr_ckg_mapping->nNum_data_nodes, stpCurr_ckg_mapping->nNum_global_parity_nodes,
				linebuf);
	}

	stpCurr_ckg_mapping->nType_raid = __ORG_DECLUSTER_GENERAL_REED_SOLOMON__;

	pCh_next = strstr(pCh, "<");
	if(pCh_next != NULL)
	{
		pCh = pCh_next;
	}
	switch(nNum_drives_per_ckg)
				{
				case 1:
					sscanf(pCh, "<%d, %d>]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0]
							);
					break;
				case 2:
					sscanf(pCh, "<%d, %d>, <%d, %d>]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1]
							);
					break;
				case 3:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2]
							);
					break;
				case 4:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3]
							);
					break;
				case 5:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4]
							);
					break;
				case 6:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5]
							);
					break;
				case 7:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6]
							);
					break;
				case 8:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7]
							);
					break;
				case 9:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8]
							);
					break;
				case 10:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9]
							);
					break;
				case 11:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10]
							);
					break;
				case 12:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11]
							);
					break;
				case 13:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12]
							);
					break;
				case 14:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13]
							);
					break;
				case 15:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14]
							);
					break;
				case 16:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15]
							);
					break;
				case 17:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16]
							);
					break;
				case 18:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17]
							);
					break;
				case 19:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18]
							);
					break;
				case 20:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19]
							);
					break;
				case 21:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20]
							);
					break;
				case 22:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21]
							);
					break;
				case 23:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22]
							);
					break;
				case 24:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23]
							);
					break;
				case 25:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24]
							);
					break;
				case 26:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25]
							);
					break;
				case 27:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26]
							);
					break;
				case 28:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27]
							);
					break;
				case 29:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[28], &stpCurr_ckg_mapping->anStripe_id_per_ckg[28]
							);
					break;

				case 30:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[28], &stpCurr_ckg_mapping->anStripe_id_per_ckg[28],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[29], &stpCurr_ckg_mapping->anStripe_id_per_ckg[29]
							);
					break;

				case 31:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[28], &stpCurr_ckg_mapping->anStripe_id_per_ckg[28],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[29], &stpCurr_ckg_mapping->anStripe_id_per_ckg[29],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[30], &stpCurr_ckg_mapping->anStripe_id_per_ckg[30]
							);
					break;

				case 32:
					sscanf(pCh, "<%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[28], &stpCurr_ckg_mapping->anStripe_id_per_ckg[28],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[29], &stpCurr_ckg_mapping->anStripe_id_per_ckg[29],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[30], &stpCurr_ckg_mapping->anStripe_id_per_ckg[30],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[31], &stpCurr_ckg_mapping->anStripe_id_per_ckg[31]
							);
					break;

				}

}


void _org_decode_ckg_with_raid(int nNum_drives_per_ckg, // input
		char * linebuf,									// input string buffer
		org_chunk_group_map *stpCurr_ckg_mapping)       // output
{
	switch(nNum_drives_per_ckg)
				{
				case 1:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0]
							);
					break;
				case 2:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1]
							);
					break;
				case 3:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2]
							);
					break;
				case 4:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3]
							);
					break;
				case 5:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4]
							);
					break;
				case 6:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5]
							);
					break;
				case 7:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6]
							);
					break;
				case 8:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7]
							);
					break;
				case 9:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8]
							);
					break;
				case 10:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9]
							);
					break;
				case 11:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10]
							);
					break;
				case 12:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11]
							);
					break;
				case 13:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12]
							);
					break;
				case 14:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13]
							);
					break;
				case 15:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14]
							);
					break;
				case 16:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15]
							);
					break;
				case 17:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16]
							);
					break;
				case 18:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17]
							);
					break;
				case 19:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18]
							);
					break;
				case 20:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19]
							);
					break;
				case 21:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20]
							);
					break;
				case 22:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21]
							);
					break;
				case 23:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22]
							);
					break;
				case 24:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23]
							);
					break;
				case 25:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24]
							);
					break;
				case 26:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25]
							);
					break;
				case 27:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26]
							);
					break;
				case 28:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27]
							);
					break;
				case 29:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[28], &stpCurr_ckg_mapping->anStripe_id_per_ckg[28]
							);
					break;

				case 30:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[28], &stpCurr_ckg_mapping->anStripe_id_per_ckg[28],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[29], &stpCurr_ckg_mapping->anStripe_id_per_ckg[29]
							);
					break;

				case 31:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[28], &stpCurr_ckg_mapping->anStripe_id_per_ckg[28],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[29], &stpCurr_ckg_mapping->anStripe_id_per_ckg[29],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[30], &stpCurr_ckg_mapping->anStripe_id_per_ckg[30]
							);
					break;

				case 32:
					sscanf(linebuf, "[%d, RAID%d, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d>, <%d, %d> ]",
							&stpCurr_ckg_mapping->nId_ckg, &stpCurr_ckg_mapping->nType_raid,
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[0], &stpCurr_ckg_mapping->anStripe_id_per_ckg[0],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[1], &stpCurr_ckg_mapping->anStripe_id_per_ckg[1],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[2], &stpCurr_ckg_mapping->anStripe_id_per_ckg[2],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[3], &stpCurr_ckg_mapping->anStripe_id_per_ckg[3],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[4], &stpCurr_ckg_mapping->anStripe_id_per_ckg[4],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[5], &stpCurr_ckg_mapping->anStripe_id_per_ckg[5],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[6], &stpCurr_ckg_mapping->anStripe_id_per_ckg[6],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[7], &stpCurr_ckg_mapping->anStripe_id_per_ckg[7],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[8], &stpCurr_ckg_mapping->anStripe_id_per_ckg[8],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[9], &stpCurr_ckg_mapping->anStripe_id_per_ckg[9],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[10], &stpCurr_ckg_mapping->anStripe_id_per_ckg[10],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[11], &stpCurr_ckg_mapping->anStripe_id_per_ckg[11],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[12], &stpCurr_ckg_mapping->anStripe_id_per_ckg[12],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[13], &stpCurr_ckg_mapping->anStripe_id_per_ckg[13],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[14], &stpCurr_ckg_mapping->anStripe_id_per_ckg[14],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[15], &stpCurr_ckg_mapping->anStripe_id_per_ckg[15],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[16], &stpCurr_ckg_mapping->anStripe_id_per_ckg[16],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[17], &stpCurr_ckg_mapping->anStripe_id_per_ckg[17],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[18], &stpCurr_ckg_mapping->anStripe_id_per_ckg[18],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[19], &stpCurr_ckg_mapping->anStripe_id_per_ckg[19],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[20], &stpCurr_ckg_mapping->anStripe_id_per_ckg[20],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[21], &stpCurr_ckg_mapping->anStripe_id_per_ckg[21],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[22], &stpCurr_ckg_mapping->anStripe_id_per_ckg[22],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[23], &stpCurr_ckg_mapping->anStripe_id_per_ckg[23],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[24], &stpCurr_ckg_mapping->anStripe_id_per_ckg[24],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[25], &stpCurr_ckg_mapping->anStripe_id_per_ckg[25],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[26], &stpCurr_ckg_mapping->anStripe_id_per_ckg[26],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[27], &stpCurr_ckg_mapping->anStripe_id_per_ckg[27],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[28], &stpCurr_ckg_mapping->anStripe_id_per_ckg[28],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[29], &stpCurr_ckg_mapping->anStripe_id_per_ckg[29],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[30], &stpCurr_ckg_mapping->anStripe_id_per_ckg[30],
							&stpCurr_ckg_mapping->anDrive_id_per_ckg[31], &stpCurr_ckg_mapping->anStripe_id_per_ckg[31]
							);
					break;

				}

}
