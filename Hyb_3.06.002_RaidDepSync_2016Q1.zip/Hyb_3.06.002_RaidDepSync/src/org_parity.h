

#ifndef __ORG_PARITY__
#define __ORG_PARITY__

typedef struct _org_global_parity
{
char nIdx_node;
char nOrder;
int nParity_pattern_id;
}org_global_parity;

typedef struct _org_local_parity
{
char nIdx_parity_node;
char aData_nodes[32];
char nIdx_local_group;
int nParity_pattern_id;
char nNum_data_in_group;
}org_local_parity;

typedef struct _org_parity_pattern
{
struct  _org_global_parity *stpGlobal_parity;
int nNum_global_parity_nodes;

struct _org_local_parity *stpLocal_parity_group;
int nNum_local_parity_nodes;

int nNum_total_parity_nodes;
int nParity_pattern_id;

int nNum_total_data_nodes;
int aIdx_data_nodes[32];
}org_parity_pattern;

typedef union _org_parity
{
	org_local_parity stLocal_parity;
	org_global_parity stCkg_parity;
};

#define org_ddbg_assert(cond,msg) do { int _ltassert_cond = (int)(cond);\
if(!_ltassert_cond) { \
 ddbg_assert_msg(__FILE__, __LINE__, #cond, __func__, ""); \
 ddbg_assert_printmsg msg; \
 ddbg_assert_fail(__FILE__, __LINE__, #cond, __func__, ""); \
} } while(0)

#endif
