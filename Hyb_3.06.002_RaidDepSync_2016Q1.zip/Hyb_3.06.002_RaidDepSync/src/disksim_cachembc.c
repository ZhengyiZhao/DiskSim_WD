//          Copyright 2002-2011 Western Digital Corporation
//
//                  RESTRICTED RIGHTS LEGEND
//                  ------------------------
//  Use, duplication or disclosure by any commercial industry (public or
//  private), private individual or by any Government Agency without an
//  expressed written consent of release from Western Digital Corporation
//  is subject to restriction set forth in paragraph (b)(3)(B) of the Rights
//  in Technical Data and Computer Software clause in DAR 7-104.9(a).
//
//  Manufacturer is:
//  Western Digital Corporation
//  3353 Michelson drive
//  Irvine, CA 92612
//  (949) 672-7000
//=============================================================================


#include "modules/modules.h"
#include "disksim_cachembc.h"

/*  this file has functions to test a red-black tree of integers */

void IntDestroy(void* a) {
  free((int*)a);
}

int IntCompare(const void* a,const void* b) {
  if( *(int*)a > *(int*)b) return(1);
  if( *(int*)a < *(int*)b) return(-1);
  return(0);
}

void IntPrint(const void* a) {
  printf("%i",*(int*)a);
}

void InfoPrint(void* a) {
  printf("%i",*(int*)a);
}

void InfoDestroy(void *a){
  free((int*)a);
}


//*****************************************************************************
// Function: cachembc_get_maxreqsize (hurst_r done)
//    Retruns the the maximum request size to be served by the cache.
//
// Parameters:
//   struct cache_if *c     pointer to a cache_mbc object
//
// Returns: int
//*****************************************************************************

int 
cachembc_get_maxreqsize (struct cache_if *c)
{
  struct cache_mbc *cache = (struct cache_mbc *)c;

#ifdef DEBUG_CACHEMBC
  fprintf(outputfile, "*** %f: Entered cachembc_get_maxreqsize  cache->maxreqsize=%d\n", simtime, cache->maxreqsize );
  fflush(outputfile);
#endif

  return(cache->maxreqsize);
}


//*****************************************************************************
// Function: cachembc_empty_donefunc (hurst_r done)
//    Add the ioreq_event to the extraq
//
// Parameters:
//   void *doneparam    pointer to a void object (not used)
//   ioreq_event *req   pointer to a ioreq_event
//
// Returns: void
//*****************************************************************************

void cachembc_empty_donefunc (void *doneparam, ioreq_event *req)
{
   addtoextraq((event *) req);
}


//*****************************************************************************
// Function: cachembc_add_ongoing_request (hurst_r done)
//   Adds a cache_mbc_event to the cache request queue
//
// Parameters:
//   struct cache_mbc *cache    pointer to a cache_mbc
//   void *crq                  pointer to a cache_mbc_event
//
// Returns: void
//*****************************************************************************

void 
cachembc_add_ongoing_request (struct cache_mbc *cache, void *crq)
{
  struct cache_mbc_event *cachereq = (struct cache_mbc_event *)crq;
   cachereq->next = cache->ongoing_requests;
   cachereq->prev = NULL;
   if (cachereq->next) {
      cachereq->next->prev = cachereq;
   }
   cache->ongoing_requests = cachereq;
}


//*****************************************************************************
// Function: cachembc_remove_ongoing_request (hurst_r done)
//   Removes a cache_mbc_event to the cache request queue
//
// Parameters:
//   struct cache_mbc *cache    pointer to a cache_mbc
//   void *crq                  pointer to a cache_mbc_event
//
// Returns: void
//*****************************************************************************

void 
cachembc_remove_ongoing_request (struct cache_mbc *cache, struct cache_mbc_event *cachereq)
{
   if (cachereq->next) {
      cachereq->next->prev = cachereq->prev;
   }
   if (cachereq->prev) {
      cachereq->prev->next = cachereq->next;
   }
   if (cache->ongoing_requests == cachereq) {
      cache->ongoing_requests = cachereq->next;
   }
}


//*****************************************************************************
// Function: cachembc_find_ongoing_request (hurst_r done)
//   Returns a cache_mbc_event that contains the given ioreq_event
//
// Parameters:
//   struct cache_mbc *cache    pointer to a cache_mbc
//   ioreq_event *crq           pointer to a cache_mbc_event
//
// Returns: struct cache_mbc_event *
//*****************************************************************************

struct cache_mbc_event *
cachembc_find_ongoing_request (struct cache_mbc *cache, ioreq_event *req)
{
   struct cache_mbc_event *tmp = cache->ongoing_requests;

#ifdef DEBUG_CACHEMBC
   fprintf(outputfile, "*** %f: Entered cachembc_find_ongoing_request: devno %d blkno %d, bcount %d, flags 0x%x\n", simtime, req->devno, req->blkno, req->bcount, req->flags );
   fflush(outputfile);
#endif

   /* Is this enough to ensure equivalence?? */
   while ((tmp != NULL) && ((req->opid != tmp->req->opid) || (req->blkno != tmp->req->blkno) || (req->bcount != tmp->req->bcount) || (req->buf != tmp->req->buf))) {
      tmp = tmp->next;
   }

   return (tmp);
}


//*****************************************************************************
// Function: cachembc_find_dirty_cache_blocks
//   Returns the first consectutive range of dirty blocks in the cache in flushreq
//
// Parameters:
//   struct cache_mbc *cache            pointer to a cache_mbc
//   struct cache_mbc_event *flushdesc  data structure that will be populated with real device write data info
//   ioreq_event * flushreq             data structure will be populated with cache read data info
//
// Returns: int
//   0  if no dirty blocks
//   1  if dirty blocks found
//*****************************************************************************

int
cachembc_find_dirty_cache_blocks (struct cache_mbc *cache, struct cache_mbc_event *flushdesc, ioreq_event * flushreq )
{
    rb_red_blk_node* newNode;

    int firstBlock     = 0;
    int blockIndex     = 0;
    int maxDeviceBlocks = device_get_number_of_blocks( cache->devno );

    // get all the entries in the cache sorted
    stk_stack *enumResult = RBEnumerate( cache->diskTree, (void *)&firstBlock, (void *)&maxDeviceBlocks );
    newNode = (rb_red_blk_node *)StackPop(enumResult);
    if( NULL == newNode )
    {
        // here, the cache is empty
        return (0);
    }

    flushdesc->req->blkno = *(int *)newNode->info;    // user area  start block
    flushreq->blkno       = *(int *)newNode->key;     // cache area start block

    int blockCount = 1;
    for( blockIndex = *(int *)newNode->info + 1; NULL != (newNode = (rb_red_blk_node *)StackPop(enumResult)); blockIndex++ )
    {
        int hostLBA = *(int *)newNode->info;
        if( blockIndex != *(int *)newNode->info )
        {
            break;
        }
        blockCount++;
    }

    flushdesc->req->bcount = flushreq->bcount = blockCount;

#ifdef DEBUG_CACHEMBC
   fprintf(outputfile, "*** %f: cachembc_find_dirty_cache_blocks  CACHE: blkno %d, bcount %d, REAL: blkno %d, bcount %d\n", simtime, flushreq->blkno, flushreq->bcount, flushdesc->req->blkno, flushdesc->req->bcount );
   fflush(outputfile);
#endif

   return (1);
}


//*****************************************************************************
// Function: cachembc_count_dirty_blocks (hurst_r done)
//   Return a count of how many dirty blocks are on the cache_mbc
//
// Parameters:
//   struct cache_mbc *cache    pointer to a cache_mbc
//
// Returns: int
//*****************************************************************************

int
cachembc_count_dirty_blocks (struct cache_mbc *cache)
{
    int dirtyblocks = 0;
    rb_red_blk_node* newNode;

    // how many blocks on the device we are caching?
    int startBlock = 0;
    int maxDeviceBlocks   = device_get_number_of_blocks( cache->devno ) - 1;
    stk_stack *enumResult = RBEnumerate( cache->hostTree, &startBlock, &maxDeviceBlocks );

    while ( (newNode = (rb_red_blk_node *)StackPop(enumResult)) ) {
        dirtyblocks++;
    }
    free(enumResult);

#ifdef DEBUG_CACHEMBC
    fprintf(outputfile, "*** %f: cachembc_count_dirty_blocks  dirtyblocks %d\n", simtime, dirtyblocks );
    fflush(outputfile);
#endif

    return (dirtyblocks);
}


//*****************************************************************************
// Function: cachembc_setbits (hurst_r done)
//   Adds the blocks flagged in the ioreq_event to the given bit map
//
// Parameters:
//   struct cache_mbc *cache    pointer to a cache_mbc
//   ioreq_event *req           pointer to a ioreq_event
//
// Returns: ioreq_event *
//*****************************************************************************

//static void cachembc_setbits (bitstr_t *bitmap, ioreq_event *req)
//{
//#ifdef DEBUG_CACHEMBC
//   fprintf(outputfile, "*** %f: Entered cachembc_setbits  devno %d, blkno %d, bcount %d\n", simtime, req->devno, req->blkno, req->bcount );
//   fflush(outputfile);
//#endif
//
//   bit_nset (bitmap, req->blkno, (req->blkno+req->bcount-1));
//}


//*****************************************************************************
// Function: cachembc_clearbits (hurst_r done)
//   Removes the blocks flagged in the ioreq_event from the given bit map
//
// Parameters:
//   struct cache_mbc *cache    pointer to a cache_mbc
//   ioreq_event *req           pointer to a ioreq_event
//
// Returns: ioreq_event *
//*****************************************************************************

//static void cachembc_clearbits (bitstr_t *bitmap, ioreq_event *req)
//{
//#ifdef DEBUG_CACHEMBC
//   fprintf(outputfile, "*** %f: Entered cachembc_clearbits  devno %d, blkno %d, bcount %d\n", simtime, req->devno, req->blkno, req->bcount );
//   fflush(outputfile);
//#endif
//
//   bit_nclear (bitmap, req->blkno, (req->blkno+req->bcount-1));
//}


//*****************************************************************************
// Function: cachembc_build_read_request (hurst_r done)
//   builds an ioreq_event chain to process the read
//   It needs to determine if the read is within the cache, in the user area, or both
//
// Parameters:
//   struct cache_mbc *cache    pointer to a cache_mbc
//   ioreq_event *req           pointer to a ioreq_event
//
// Returns: ioreq_event *
//*****************************************************************************

ioreq_event *
cachembc_build_read_request (struct cache_mbc *cache, ioreq_event *req, struct cache_mbc_event *rwdesc )
{
    int blockIndex;
    int inCache, lastBlockProcessedInCache;
    int userBlkno, lastUserBlkno;
    rb_red_blk_node* newNode;

#ifdef DEBUG_CACHEMBC
    fprintf(outputfile, "*** %f: cachembc_build_read_request  Entering  numRequests %d, devno %d, blkno %d, bcount %d\n", simtime, cache->numReadIoreqSegments, cache->devno, req->blkno, req->bcount );
    dump_ioreq_event( req, "cachembc_build_read_request" );
    fflush(outputfile);
#endif

    cache->numReadIoreqSegments = 1;
    // need to keep track of block request crossing into next User area
    userBlkno = lastUserBlkno = cachembc_convert_host_blkno_to_user_blkno( cache, req->blkno );

    // need to keep track if last block was a cache hit
    inCache = lastBlockProcessedInCache = ( NULL == (newNode = RBExactQuery( cache->hostTree, &userBlkno)) ) ? 0 : 1;

    // build an ioreq_event chain
    ioreq_event *fill_req = ioreq_copy (req);
    ioreq_event *new_req  = fill_req;

    new_req->devno = cache->devno;
    new_req->bcount = 1;

    if( inCache )
	{
        // here, data is in the cache
        new_req->blkno = *(int*)newNode->info;
	}
    else
    {
        // here, data is not in the cache
        new_req->blkno = userBlkno;
    }
    new_req->buf  = rwdesc;
    new_req->type = IO_ACCESS_ARRIVE;

    for( blockIndex = 1; blockIndex < req->bcount; blockIndex++ )
    {
        lastUserBlkno++;
        userBlkno = cachembc_convert_host_blkno_to_user_blkno( cache, req->blkno + blockIndex );
        inCache   = ( NULL == (newNode = RBExactQuery( cache->hostTree, &userBlkno)) ) ? 0 : 1;
        if( (inCache != lastBlockProcessedInCache) || (lastUserBlkno != userBlkno) )
        {
            // here, we crossed into the next User area or cache hit status changed
            lastBlockProcessedInCache = inCache;
            lastUserBlkno = userBlkno;
            // create a new link
            cache->numReadIoreqSegments++;
            new_req->batch_next = ioreq_copy( req );

            new_req         = new_req->batch_next;
            new_req->devno  = cache->devno;
            new_req->buf    = rwdesc;
            new_req->type   = IO_ACCESS_ARRIVE;
            new_req->bcount = 0;

            if( inCache )
	        {
                // here, data is in the cache
                new_req->blkno = *(int*)newNode->info;
	        }
            else
            {
                // here, data is not in the cache
                new_req->blkno = userBlkno;
            }
        }
        new_req->bcount++;
    }

#ifdef DEBUG_CACHEMBC
    fprintf(outputfile, "*** %f: cachembc_build_read_request  numRequests %d, devno %d, blkno %d, bcount %d\n", simtime, cache->numReadIoreqSegments, cache->devno, new_req->blkno, new_req->bcount );
    dump_ioreq_event( fill_req, "cachembc_build_read_request" );
    fflush(outputfile);
#endif

   return fill_req;
}


//*****************************************************************************
// Function: cachembc_isreadhit
//   Determine if the ioreq_event block range is in the cache
//
// Parameters:
//   struct cache_mbc *cache    pointer to a cache_mbc
//   ioreq_event *req           pointer to a ioreq_event
//
// Returns: ioreq_event *
//   NULL           if no blocks are in the cache
//   ioreq_event    contains the number of consecutive blocks in the cache for the given range
//*****************************************************************************

ioreq_event *
cachembc_isreadhit (struct cache_mbc *cache, ioreq_event *req)
{
    int userBlkno;
    rb_red_blk_node* newNode;

    int lastblk = req->blkno + req->bcount;

    // make a copy of the I/O request and set the blkno and bcount to zero
    ioreq_event *new_req = NULL;

    // find the first block that matches
    int blockIndex = 0;
    for( ; blockIndex < req->bcount; blockIndex++)
    {
        userBlkno = cachembc_convert_host_blkno_to_user_blkno( cache, req->blkno + blockIndex );
        if( 0 != (newNode = RBExactQuery( cache->hostTree, &userBlkno)) )
	    {
            // here, we have a match
            new_req = ioreq_copy (req);
            new_req->devno = cache->devno;
            new_req->blkno = *(int*)newNode->info;
            new_req->bcount = 1;
            break;
	    }
    }
    if( NULL != new_req )
    {
        // count consecutive matching blocks
        for( blockIndex++; blockIndex < req->bcount; blockIndex++)
        {
            userBlkno = cachembc_convert_host_blkno_to_user_blkno( cache, req->blkno + blockIndex );
            if( 0 != (newNode = RBExactQuery( cache->hostTree, &userBlkno)) )
	        {
                new_req->bcount++;
	        }
            else
            {
                // exit on the first non-match
                break;
            }
        }
    }

#ifdef DEBUG_CACHEMBC
   fprintf(outputfile, "*** %f: cachembc_isreadhit (%s)  devno %d, blkno %d, bcount %d\n", simtime, (NULL != new_req) ? "yes" : "no", cache->devno, req->blkno, req->bcount );
   for( int index = 0; index < cache->numMbcRegions; index ++ )
   {
       fprintf(outputfile, "***   index %d, headBlockIndex %d, tailBlockIndex %d, startLba %d, bcount %d\n", index, cache->mbcLocations[index].headBlockIndex, cache->mbcLocations[index].tailBlockIndex, cache->mbcLocations[index].startLBA, cache->mbcLocations[index].bcount );
   }
   fflush(outputfile);
#endif

   return new_req;
}


//*****************************************************************************
// Function: cachembc_iswritehit (hurst_r done)
//   Determine if the given ioreq_event block range can be written to the the cache device
//
// Parameters:
//   struct cache_mbc *cache    pointer to a cache_mbc
//   ioreq_event *req           pointer to a ioreq_event
//
// Returns: int
//*****************************************************************************

int cachembc_iswritehit (struct cache_mbc *cache, ioreq_event *req)
{

   // find the closest mbc cache area
   int userBlkno = cachembc_convert_host_blkno_to_user_blkno( cache, req->blkno );
   int mbcIndex = cachembc_find_closest_mbc_area( cache, userBlkno );
   int numAvailableBlocks = cachembc_calc_num_available_blocks( cache, mbcIndex );

   cache->write_hit_state = 0;
   if( numAvailableBlocks >= req->bcount )
   {
       cache->write_hit_state = 1;  // enable writing to the MBC area
   }

#ifdef DEBUG_CACHEMBC
   fprintf(outputfile, "*** %f: cachembc_iswritehit (%s), Request blkno %d, bcount %d, mbcIndex %d, numAvailableBlocks %d\n", simtime, cache->write_hit_state ? "yes" : "no", req->blkno, req->bcount, mbcIndex, numAvailableBlocks );
   for( int index = 0; index < cache->numMbcRegions; index ++ )
   {
       fprintf(outputfile, "***   index %d, headBlockIndex %d, tailBlockIndex %d, startLba %d, bcount %d\n", index, cache->mbcLocations[index].headBlockIndex, cache->mbcLocations[index].tailBlockIndex, cache->mbcLocations[index].startLBA, cache->mbcLocations[index].bcount );
   }
   fflush(outputfile);
#endif

   return cache->write_hit_state;
}


//*****************************************************************************
// Function: cachembc_periodic_callback  (hurst_r - not supported)
//   Called when the periodic timer expires
//
// Parameters:
//   timer_event *timereq
//
// Returns: void
//*****************************************************************************

void
cachembc_periodic_callback (timer_event *timereq)
{
   fprintf (stderr, "cachembc_periodic_callback not supported\n");
   ASSERT (0);
   exit (0);
}


//*****************************************************************************
// Function: cachembc_idlework_callback
//   Called when the given device becomes idle after a set period of time set by cache_mbc::flush_idledelay
//   It flushes the first cache block (consecutive blocks) to the user area
//
// Parameters:
//   void *idleworkparam    pointer to a struct cache_mbc
//   int idledevno          idle device number
//
// Returns: int
//   0  if no dirty blocks
//   1  if dirty blocks found
//*****************************************************************************

void cachembc_idlework_callback (void *idleworkparam, int idledevno)
{
   struct cache_mbc *cache = (struct cache_mbc *)idleworkparam;
   struct cache_mbc_event *flushdesc;
   ioreq_event *flushreq, *writereq;
   struct ioq *queue;

   ASSERT (idledevno == cache->devno);

#ifdef DEBUG_CACHEMBC
   fprintf(outputfile, "*** %f: Entered cachembc_idlework_callback\n", simtime );
   fflush(outputfile);
#endif

   // get the queue of this device
   queue = (*cache->queuefind)(cache->queuefindparam, cache->devno);
   if (0 != ioqueue_get_number_in_queue (queue)) {
      return;
   }

   // we need to flush the cache data to the user area
   writereq  = (ioreq_event *) getfromextraq();
   flushdesc = (struct cache_mbc_event *) getfromextraq();
   flushdesc->req = writereq;
   flushreq = (ioreq_event *) getfromextraq();
   if (0 == cachembc_find_dirty_cache_blocks (cache, flushdesc, flushreq)) {
      return;
   }
    
   flushdesc->type = CACHE_EVENT_IDLEFLUSH_READ;
   flushreq->buf   = flushdesc;
   flushreq->devno = cache->devno;
   flushreq->type  = IO_ACCESS_ARRIVE;
   flushreq->flags = READ;

   /* Just assume that bufferspace is available */
   cache->bufferspace += flushreq->bcount;
   if (cache->bufferspace > cache->stat.maxbufferspace) {
      cache->stat.maxbufferspace = cache->bufferspace;
   }

   (*cache->issuefunc)(cache->issueparam, flushreq);
   cache->stat.destagereads++;
   cache->stat.destagereadblocks += flushreq->bcount;
}


//*****************************************************************************
// Function: cachembc_get_block
//   Gets the appropriate block, locked and ready to be accessed for read or write
//
// Parameters:
//   struct cache_if *c                         pointer to a struct cache_mbc
//   ioreq_event *req                           pointer to a ioreq_event (contains operation (r/w) and block range)
//   void (**donefunc)(void *, ioreq_event *)   callback function to be called when the ioreq_event is processed
//   void *doneparam)                           parameter from the callee to be passed to the callback function
//
// Returns: int
//   0  if operation is a write
//   1  if operation is a read
//*****************************************************************************

int 
cachembc_get_block (struct cache_if *c, 
		    ioreq_event *req, 
		    void (**donefunc)(void *, ioreq_event *), 
		    void *doneparam)
{
   ioreq_event *fillreq, *matched_req;

   struct cache_mbc *cache = (struct cache_mbc *)c;
   struct cache_mbc_event *rwdesc = (struct cache_mbc_event *) getfromextraq();

#ifdef DEBUG_CACHEMBC
   fprintf (outputfile, "*** totalreqs = %d\n", disksim->totalreqs);
   fprintf (outputfile, "*** %f: cachembc_get_block: I/O Request  rw %d, devno %d, blkno %d, size %d\n", simtime, (req->flags & READ), req->devno, req->blkno, req->bcount);
#endif

   if( (req->blkno + req->bcount) >= cache->maxLBA )
   {
      printf ( "%f: cachembc_get_block: Illegal I/O Request  rw %d, devno %d, blkno %d, size %d, maxLBA %d\n", simtime, (req->flags & READ), req->devno, req->blkno, req->bcount, cache->maxLBA);
      exit(0);
   }

   /* Ignore request overlap and locking issues for now.  */
   /* Also ignore buffer space limitation issues for now. */
   cache->bufferspace += req->bcount;
   if (cache->bufferspace > cache->stat.maxbufferspace) {
      cache->stat.maxbufferspace = cache->bufferspace;
   }

   // create a cache_mbc_event and add it to the cache request queue
   rwdesc->type = (req->flags & READ) ? CACHE_EVENT_READ : CACHE_EVENT_WRITE;
   rwdesc->donefunc = donefunc;
   rwdesc->doneparam = doneparam;
   rwdesc->req = req;
   req->next = NULL;
   req->prev = NULL;
   rwdesc->flags = 0;
   cachembc_add_ongoing_request (cache, rwdesc);

    if (req->flags & READ) {
        // here, we are doing a read operation
        // we prefer reading from the cache device but this is not always the case
        // The data can be all on one device or split up between the cache and real device
        // We need to create the appropiate operations to get the data to the host

        // take care of the stats
        cache->stat.reads++;
        cache->stat.readblocks += req->bcount;

        cache->read_hit_state = CACHE_HIT_MISS;
        // note: can only use matched_req to determine cache hit state
        if( NULL != (matched_req = cachembc_isreadhit( cache, req )) )
        {
            if( matched_req->bcount == req->bcount )
            {
                cache->read_hit_state = CACHE_HIT_FULL;
            }
            else
            {
                cache->read_hit_state = CACHE_HIT_PARTIAL;
            }
        }

        switch( cache->read_hit_state )
        {
          case CACHE_HIT_MISS:
              cache->stat.readmisses++;
              break;

          case CACHE_HIT_FULL:
              cache->stat.readhitsfull++;
              break;

          case CACHE_HIT_PARTIAL:
              cache->stat.readhitspartial++;
              break;
        }

        // build an ioreq_event chain
        fillreq = cachembc_build_read_request( cache, req, rwdesc );

#ifdef DEBUG_CACHEMBC
        fprintf (outputfile, "*** %f: cachembc_get_block fillreq - miss: devno %d, blkno %d, buf %p\n", simtime, fillreq->devno, fillreq->blkno, fillreq->buf);
#endif

        (*cache->issuefunc)(cache->issueparam, fillreq);
        return (1);
    }
    else {
       // here, we are doing a write operation
      /* Grab buffer space and let the controller fill in data to be written. */
      /* (for now, just assume that there is buffer space available)          */
      // controller_smart_host_data_transfer

      (*donefunc)(doneparam, req);
      return (0);
   }
}


//*****************************************************************************
// Function: cachembc_free_block_clean (hurst_r done)
//   frees the block from the cache request queue after access complete
//   block is clean so remove locks and update lru
//
// Parameters:
//   struct cache_if *c                         pointer to a struct cache_mbc
//   ioreq_event *req                           pointer to a ioreq_event (contains operation (r/w) and block range)
//
// Returns: void
//*****************************************************************************

void 
cachembc_free_block_clean (struct cache_if *c, 
			   ioreq_event *req)
{
   struct cache_mbc *cache = (struct cache_mbc *)c;
   struct cache_mbc_event *rwdesc;

#ifdef DEBUG_CACHEMBC
   fprintf (outputfile, "*** %f: Entered cache_free_block_clean: blkno %d, bcount %d, devno %d\n", simtime, req->blkno, req->bcount, req->devno);
#endif

   /* For now, just find relevant rwdesc and free it.                       */
   /* Later, write it to the cache device (and update the cache map thusly. */

   rwdesc = cachembc_find_ongoing_request (cache, req);
   ASSERT (rwdesc != NULL);

   if (rwdesc->type == CACHE_EVENT_READ) {
      cache->bufferspace -= req->bcount;
      cachembc_remove_ongoing_request (cache, rwdesc);
      addtoextraq ((event *) rwdesc);
   } else {
      ASSERT (rwdesc->type == CACHE_EVENT_POPULATE_ALSO);
      rwdesc->type = CACHE_EVENT_POPULATE_ONLY;
   }
}


//*****************************************************************************
// Function: cachembc_free_block_dirty (hurst_r done)
//   a delayed write - set dirty bits, remove locks and update lru.
//   If cache doesn't allow delayed writes, forward this to async
//   Also will set a TIMER_EVENT for cachembc_idlework_callback
//
// Parameters:
//   struct cache_if *c                         pointer to a struct cache_mbc
//   ioreq_event *req                           pointer to a ioreq_event (contains operation (r/w) and block range)
//   void (**donefunc)(void *, ioreq_event *)   callback function to be called when the ioreq_event is processed
//   void *doneparam)                           parameter from the callee to be passed to the callback function
//
// Returns: void
//*****************************************************************************

int 
cachembc_free_block_dirty (struct cache_if *c, 
			   ioreq_event *req, 
			   void (**donefunc)(void *, ioreq_event *), 
			   void *doneparam)
{
   ioreq_event *flushreq;
   struct cache_mbc_event *writedesc;

   struct cache_mbc *cache = (struct cache_mbc *)c;

#ifdef DEBUG_CACHEMBC
   fprintf (outputfile, "*** %f, Entered cachembc::cache_free_block_dirty: devno %d blkno %d, bcount %d, flags 0x%x\n", simtime, req->devno, req->blkno, req->bcount, req->flags );
#endif

   cache->stat.writes++;
   cache->stat.writeblocks += req->bcount;

   writedesc = cachembc_find_ongoing_request (cache, req);
   ASSERT (writedesc != NULL);
   ASSERT (writedesc->type == CACHE_EVENT_WRITE);

   writedesc->donefunc = donefunc;
   writedesc->doneparam = doneparam;
   writedesc->req = req;
   req->type = IO_REQUEST_ARRIVE;
   req->next = NULL;
   req->prev = NULL;

   int userBlkNo = cachembc_convert_host_blkno_to_user_blkno( cache, req->blkno );
   int mbcIndex  = cachembc_find_closest_mbc_area( cache, userBlkNo );

   flushreq = ioreq_copy(req);
   flushreq->type  = IO_ACCESS_ARRIVE;
   flushreq->buf   = writedesc;
   flushreq->devno = cache->devno;
   if (cachembc_iswritehit (cache, req)) {
       flushreq->blkno = cache->mbcLocations[mbcIndex].startLBA + cache->mbcLocations[mbcIndex].headBlockIndex;
        cache->mbcLocations[mbcIndex].headBlockIndex += flushreq->bcount;
        cache->stat.writehitsfull++;
   } else {
      cache->stat.writemisses++;
   }

#ifdef DEBUG_CACHEMBC
   fprintf (outputfile, "*** %f: cachembc::cachembc_free_block_dirty flushreq: devno %d, blkno %d, bcount %d, buf %p\n", simtime, flushreq->devno, flushreq->blkno, flushreq->bcount, flushreq->buf);
#endif

   (*cache->issuefunc)(cache->issueparam, flushreq);

   if (cache->flush_idledelay >= 0.0) {
       // set a timer event for cachembc_idlework_callback
      ioqueue_reset_idledetecter((*cache->queuefind)(cache->queuefindparam, req->devno), 0);
   }

   return(1);
}


//*****************************************************************************
// Function: cachembc_sync (hurst_r not used)
//
// Parameters:
//   struct cache_mbc *cache                    pointer to a struct cache_mbc
//
// Returns: int
//*****************************************************************************

int cachembc_sync (struct cache_if *c)
{
  return(0);
}



//*****************************************************************************
// Function: cachembc_convert_host_blkno_to_user_blkno
//   Adjusts the host request blkno to be in the user area
//
// Parameters:
//   struct cache_mbc *cache                pointer to a struct cache_mbc
//   int reqBlkno                           convert given Host LBA into a User Area LBA
//
// Returns: int
//   Returns the starting blkno of a valud user area LBA
//*****************************************************************************
// @9
LBA_TYPE
cachembc_convert_host_blkno_to_user_blkno(  struct cache_mbc *cache, LBA_TYPE reqBlkno )
{
	int index;
    // find the closest MBC area
    int mbcIndex = cachembc_find_closest_mbc_area( cache, reqBlkno );

    LBA_TYPE newReqBlkno = reqBlkno + cache->mbcLocations[0].bcount;
    for( index = 0; index < mbcIndex; index ++ )
    {
        newReqBlkno += cache->mbcLocations[index].bcount;
    }
    return newReqBlkno;
}


//*****************************************************************************
// Function: cachembc_calc_num_available_blocks
//   Determines how many blocks are avalable at the given MBC
//
// Parameters:
//   struct cache_mbc *cache                    pointer to a struct cache_mbc
//   int mbcIndex                               index value of the MBC area
//
// Returns: int
//   Returns the number of available blocks left in the given MBC area
//*****************************************************************************

LBA_TYPE
cachembc_calc_num_available_blocks( struct cache_mbc *cache, int mbcIndex  )
{
    LBA_TYPE numAvailableBlocks = 0; // @9

    if(  cache->mbcLocations[mbcIndex].headBlockIndex >= cache->mbcLocations[mbcIndex].tailBlockIndex )
    {
//       int lastLBA = cache->mbcLocations[mbcIndex].startLBA + cache->mbcLocations[mbcIndex].bcount;
       numAvailableBlocks = cache->mbcLocations[mbcIndex].bcount - (cache->mbcLocations[mbcIndex].headBlockIndex - cache->mbcLocations[mbcIndex].tailBlockIndex);
    }
    else
    {
        numAvailableBlocks = cache->mbcLocations[mbcIndex].tailBlockIndex - cache->mbcLocations[mbcIndex].headBlockIndex;
    }

#ifdef DEBUG_CACHEMBC
    fprintf(  outputfile, "*** %f: cachembc_calc_num_available_blocks  mbcIndex %d, numAvailableBlocks %d\n", simtime, mbcIndex, numAvailableBlocks );
#endif
    return numAvailableBlocks; // @9
}


//*****************************************************************************
// Function: cachembc_find_closest_mbc_area
//   Determines which MBC area belongs to this request
//
// Parameters:
//   struct cache_mbc *cache                    pointer to a struct cache_mbc
//   int userBlkno                              User LBA
//
// Returns: int
//   Returns the index number of the MBC area that covers the given User LBA
//*****************************************************************************

int
cachembc_find_closest_mbc_area( struct cache_mbc *cache, LBA_TYPE userBlkno )
{
   // find the closest mbc cache area
   int mbcIndex = 0;
   for( ; mbcIndex < cache->numMbcRegions - 1; mbcIndex++ )
   {
       if( userBlkno < cache->mbcLocations[mbcIndex + 1].startLBA )
       {
           break;
       }
   }

#ifdef DEBUG_CACHEMBC
   fprintf(  outputfile, "*** %f: cachembc_find_closest_mbc_area  blkno %d, mbcIndex %d\n", simtime, userBlkno, mbcIndex );
#endif
   return mbcIndex;
}


//*****************************************************************************
// Function: cachembc_maps_add_request (hurst_r done)
//   Updates the host and MBC maps with the given information
//
// Parameters:
//   struct cache_mbc *cache                    pointer to a struct cache_mbc
//   struct cache_mbc_event *rwdesc             pointer to a cache_mbc_event
//   ioreq_event *req                           pointer to a ioreq_event (contains operation (r/w) and block range)
//
// Returns: void
//*****************************************************************************

void
cachembc_maps_add_request( struct cache_mbc *cache, struct cache_mbc_event *rwdesc, ioreq_event *req )
{
    int deletionFlag;
    int userBlkno;
    int blkIndex;

#ifdef DEBUG_CACHEMBC
    fprintf(  outputfile, "*** %f: cachembc_maps_add_request  Host Request: devno %d, blkno %d, bcount %d, flags 0x%x\n", simtime, rwdesc->req->devno, rwdesc->req->blkno, rwdesc->req->bcount, rwdesc->req->flags );
    fprintf(  outputfile, "*** %f: cachembc_maps_add_request  MBC  Request: devno %d, blkno %d, bcount %d, flags 0x%x\n", simtime, req->devno, req->blkno, req->bcount, req->flags );
#endif

    rb_red_blk_node *hostNode = NULL;
    rb_red_blk_node *diskNode = NULL;

#ifdef DEBUG_CACHEMBC_RBTREE
        RBTreePrint( cache->hostTree );
        RBTreePrint( cache->diskTree );
#endif

    // update hostTree and diskTree

    for( blkIndex = 0; blkIndex < req->bcount; blkIndex++ )
    {
        int *host_host_lba = (int*) malloc(sizeof(int));
        int *host_mbc_lba  = (int*) malloc(sizeof(int));
        int *disk_host_lba = (int*) malloc(sizeof(int));
        int *disk_mbc_lba  = (int*) malloc(sizeof(int));

        // write complete - update hostTree
        userBlkno = cachembc_convert_host_blkno_to_user_blkno( cache, rwdesc->req->blkno + blkIndex );
        *host_host_lba = *disk_host_lba = userBlkno;
        *host_mbc_lba  = req->blkno + blkIndex;

        // check if the entry is already in the host tree
        deletionFlag = 0;
        if( NULL != (hostNode = RBExactQuery( cache->hostTree, host_host_lba )) )
        {
            deletionFlag = 1;
#ifdef DEBUG_CACHEMBC_RBTREE
            fprintf(  outputfile, "*** %f: cachembc_maps_add_request  Host Tree Deletion: Key %d, Info %d\n", simtime, *(int *)hostNode->key, *(int *)hostNode->info );
#endif
            *disk_mbc_lba = *(int *)hostNode->info;  // save the old mbc lba
            RBDelete( cache->hostTree, hostNode );   // delete old node
        }
#ifdef DEBUG_CACHEMBC_RBTREE
        fprintf(  outputfile, "*** %f: cachembc_maps_add_request  Host Tree Insertion: Key %d, Info %d\n", simtime, *host_host_lba, *host_mbc_lba );
#endif
        RBTreeInsert( cache->hostTree, host_host_lba, host_mbc_lba );

        // did the entry pre-exist in the host tree?
        if( deletionFlag )
        {
            // here, the entry must be in the disk tree
            diskNode = RBExactQuery( cache->diskTree, disk_mbc_lba );
            if( NULL == diskNode )
            {
                printf( "Error: disk tree does not contain same entry hostKey %d, hostInfo %d, diskKey %d, diskInfo %d!!\n", *(int *)hostNode->key, *(int *)hostNode->info, *(int *)diskNode->key, *(int *)diskNode->info );
                exit(0);
            }
#ifdef DEBUG_CACHEMBC_RBTREE
            fprintf(  outputfile, "*** %f: cachembc_maps_add_request  Disk Tree Deletion: Key %d, Info %d\n", simtime, *(int *)diskNode->key, *(int *)diskNode->info );
#endif
            RBDelete( cache->diskTree, diskNode );	// delete old node
        }
        *disk_mbc_lba = req->blkno + blkIndex;

#ifdef DEBUG_CACHEMBC_RBTREE
        fprintf(  outputfile, "*** %f: cachembc_maps_add_request  Disk Tree Insertion: Key %d, Info %d\n", simtime, *disk_mbc_lba, *disk_host_lba );
#endif
        RBTreeInsert( cache->diskTree, disk_mbc_lba, disk_host_lba );

#ifdef DEBUG_CACHEMBC_RBTREE
        RBTreePrint( cache->hostTree );
        RBTreePrint( cache->diskTree );
#endif
    }
}


//*****************************************************************************
// Function: cachembc_maps_remove_request (hurst_r done)
//   Updates the host and disk cache maps by removing the given information
//
// Parameters:
//   struct cache_mbc *cache                    pointer to a struct cache_mbc
//   ioreq_event *req                           pointer to a ioreq_event
//                                                contains flush operation (r/w) and block range to real device
//
// Returns: void
//*****************************************************************************

void
cachembc_maps_remove_request( struct cache_mbc *cache, ioreq_event *req )
{
    rb_red_blk_node *hostNode = NULL;
    rb_red_blk_node *mbcNode  = NULL;
    LBA_TYPE host_lba, mbc_lba;
    int blockIndex;

    // update hostTree and diskTree

#ifdef DEBUG_CACHEMBC_RBTREE
    RBTreePrint( cache->hostTree );
    RBTreePrint( cache->diskTree );
#endif

    for( blockIndex = 0; blockIndex < req->bcount; blockIndex++ )
    {
        // query the disk tree for the given ioreq_event
        host_lba = req->blkno + blockIndex;

#ifdef DEBUG_CACHEMBC_RBTREE
        fprintf(  outputfile, "*** %f: cachembc_maps_remove_request  Querying Host Tree: Key %d\n", simtime, host_lba );
#endif
        hostNode = RBExactQuery( cache->hostTree, &host_lba );
        if( NULL == hostNode )
        {
            printf( "Error: MBC tree does not contain entry with Key %d!!\n", host_lba );
            exit(0);
        }

#ifdef DEBUG_CACHEMBC_RBTREE
        fprintf(  outputfile, "*** %f: cachembc_maps_remove_request  Found Host Tree Entry: Key %d, Info %d\n", simtime, *(int *)hostNode->key, *(int *)hostNode->info );
#endif

        // get the matching entry from the mbc tree
        mbc_lba = *(int *)hostNode->info;

#ifdef DEBUG_CACHEMBC_RBTREE
        fprintf(  outputfile, "*** %f: cachembc_maps_remove_request  Querying MBC Tree: Key %d\n", simtime, mbc_lba );
#endif
        mbcNode = RBExactQuery( cache->diskTree, &mbc_lba );
        if( NULL == mbcNode )
        {
            printf( "Error: MBC tree does not contain entry Key %d, Info %d!!\n", *(int *)hostNode->info, *(int *)hostNode->key );
            exit(0);
        }

#ifdef DEBUG_CACHEMBC_RBTREE
        fprintf(  outputfile, "*** %f: cachembc_maps_remove_request  Found MBC Tree Entry: Key %d, Info %d\n", simtime, *(int *)mbcNode->key, *(int *)mbcNode->info );
#endif
        // remove the entries from both trees
        RBDelete( cache->diskTree, mbcNode );
        RBDelete( cache->hostTree, hostNode );

#ifdef DEBUG_CACHEMBC_RBTREE
        RBTreePrint( cache->hostTree );
        RBTreePrint( cache->diskTree );
#endif
    }
}


//*****************************************************************************
// Function: cachembc_disk_access_complete
//   Called when the cache disk access is complete
//
// Parameters:
//   struct cache_mbc *cache                    pointer to a struct cache_mbc
//   ioreq_event *req                           pointer to a ioreq_event (contains operation (r/w) and block range)
//
// Returns: void
//*****************************************************************************

void *
cachembc_disk_access_complete (struct cache_if *c, ioreq_event *curr)
{
    ioreq_event *searchreq;

    struct cache_mbc *cache        = (struct cache_mbc *)c;
    struct cache_mbc_event *rwdesc = (struct cache_mbc_event *)curr->buf;
    struct cache_mbc_event *tmp    = NULL;
    ioreq_event *new_req           = curr;

#ifdef DEBUG_CACHEMBC
   fprintf (outputfile, "*** %f: cachembc_disk_access_complete: rwdesc %p, rwdesc_type %d, devno %d, blkno %d, bcount %d, buf %p\n", simtime, rwdesc, rwdesc->type, curr->devno, curr->blkno, curr->bcount, curr->buf);
#endif

   switch(rwdesc->type) {
     case CACHE_EVENT_READ:
      /* Consider writing same buffer to cache_devno, in order to populate it.*/
      /* Not clear whether it is more appropriate to do it from here or from  */
      /* "free_block_clean" -- do it here for now to get more overlap.        */
      //if (curr->devno == cache->real_devno) {
      //   ioreq_event *flushreq = ioreq_copy(rwdesc->req);
      //   flushreq->type = IO_ACCESS_ARRIVE;
      //   flushreq->buf = rwdesc;
      //   flushreq->flags = WRITE;
      //   flushreq->devno = cache->cache_devno;
      //   rwdesc->type = CACHE_EVENT_POPULATE_ALSO;
      //   (*cache->issuefunc)(cache->issueparam, flushreq);
      //   cache->stat.popwrites++;
      //   cache->stat.popwriteblocks += rwdesc->req->bcount;
      //}

        // following code processes a batch request
        // the ioreq_event can be multiple requests if it is a partial cache hit
        if( NULL != new_req->batch_next )
        {
            (*cache->issuefunc)( cache->issueparam, new_req->batch_next );
        }
        else
        {
            /* Ongoing read request can now proceed, so call donefunc from get_block*/
            (*rwdesc->donefunc)(rwdesc->doneparam,rwdesc->req);
        }
        break;

   case CACHE_EVENT_WRITE:
      /* finished writing to device */
      // check if it was the cache area
      if( cache->write_hit_state ) {
         cachembc_maps_add_request( cache, rwdesc, curr );
//         cachembc_setbits (cache->validmap, curr);
//         cachembc_setbits (cache->dirtymap, curr);
         if (cache->writescheme == CACHE_MBC_WRITE_THRU) {
            ioreq_event *flushreq = ioreq_copy(rwdesc->req);
            flushreq->type = IO_ACCESS_ARRIVE;
            flushreq->buf = rwdesc;
            flushreq->flags = WRITE;
            flushreq->devno = cache->devno;
            rwdesc->type = CACHE_EVENT_FLUSH;
            (*cache->issuefunc)(cache->issueparam, flushreq);
            cache->stat.destagewrites++;
            cache->stat.destagewriteblocks += rwdesc->req->bcount;
         }
      }
      (*rwdesc->donefunc)(rwdesc->doneparam,rwdesc->req);

      if (rwdesc->type != CACHE_EVENT_FLUSH) {
         cachembc_remove_ongoing_request (cache, rwdesc);
         addtoextraq ((event *) rwdesc);
         cache->bufferspace -= curr->bcount;
      }
      break;

   case CACHE_EVENT_POPULATE_ONLY:
//      cachembc_setbits (cache->validmap, curr);
      cachembc_remove_ongoing_request (cache, rwdesc);
      addtoextraq ((event *) rwdesc);
      cache->bufferspace -= curr->bcount;
      break;
      
   case CACHE_EVENT_POPULATE_ALSO:
//     cachembc_setbits (cache->validmap, curr);
     rwdesc->type = CACHE_EVENT_READ;
     break;

   case CACHE_EVENT_FLUSH:
//      cachembc_clearbits (cache->dirtymap, curr);
      cachembc_remove_ongoing_request (cache, rwdesc);
      addtoextraq ((event *) rwdesc);
      cache->bufferspace -= curr->bcount;
      break;

    // hurst_r event call sequence (appears recursive)
    //   cachembc_idlework_callback
    //       CACHE_EVENT_IDLEFLUSH_READ
    //           CACHE_EVENT_IDLEFLUSH_FLUSH
    //               cachembc_idlework_callback
    //   repeat sequence
   case CACHE_EVENT_IDLEFLUSH_READ:
     {
        // here, the cache data to flushed to the read device is in the buffer
        // we need to write it to the user area
        ioreq_event *flushreq = ioreq_copy (curr);
        flushreq->type = IO_ACCESS_ARRIVE;
        flushreq->flags = WRITE;
        flushreq->devno = cache->devno;
        flushreq->blkno = rwdesc->req->blkno;
        rwdesc->type = CACHE_EVENT_IDLEFLUSH_FLUSH;
        (*cache->issuefunc)(cache->issueparam, flushreq);
        cache->stat.destagewrites++;
        cache->stat.destagewriteblocks += curr->bcount;
     } break;

   case CACHE_EVENT_IDLEFLUSH_FLUSH:
     //here, the cache data in the buffer has been flushed to the real device
     cache->bufferspace -= curr->bcount;
     cachembc_maps_remove_request( cache, curr );

     // setup an ioreq_event to get the first block in the cache
     // and use it to set the MBC area tail index
     searchreq = (ioreq_event *)getfromextraq();
     //if( 0 == cachembc_find_dirty_cache_blocks( cache, rwdesc, searchreq ) )
     //{
     //    // here, the cache is empty
     //   cache->mbcLocations.headBlockIndex = cache->mbcLocations.tailBlockIndex = cache->mbcLocations.startLBA;
     //}
     //else
     //{
     //    // here, the cache is not empty
     //    cache->mbcLocations.tailBlockIndex = searchreq->blkno;
     //}

//     cachembc_clearbits (cache->dirtymap, curr);
     cachembc_remove_ongoing_request (cache, rwdesc);
     addtoextraq ((event *) rwdesc);
     cachembc_idlework_callback (cache, curr->devno);
     break;

   default:
     ddbg_assert2(0, "Unknown cachembc event type");
     break;
   }

   addtoextraq((event *) curr);

   /* returned cacheevent will get forwarded to cachembc_wakeup_complete... */
   return(tmp);
}


//*****************************************************************************
// Function: cachembc_wakeup_complete (hurst_r not used)
//   Called when the cache operation is complete
//
// Parameters:
//   struct cache_mbc *cache                    pointer to a struct cache_mbc
//   (struct cache_mbc_event *)d                pointer to a cache_mbc_event
//
// Returns: void
//*****************************************************************************

void 
cachembc_wakeup_complete (struct cache_if *c, 
			  void *d) // really struct cache_dev_event
{
  struct cache_mbc_event *desc = (struct cache_mbc_event *)d;
  struct cache_mbc *cache = (struct cache_mbc *)c;
  ASSERT (0);

  // ???

#if 0
   switch(desc->type) {
   case CACHE_EVENT_READ:
      cache_read_continue(cache, desc);
      break;
   case CACHE_EVENT_WRITE:
     cache_write_continue(cache, desc);
     break;
   case CACHE_EVENT_FLUSH:
      (*desc->donefunc)(desc->doneparam, desc->req);
      addtoextraq((event *) desc);
      break;

   default:
     ddbg_assert2(0, "Unknown cachedev event type");
     break;
   }
#endif
}


//*****************************************************************************
// Function: cachembc_resetstats (hurst_r done)
//   Clears all statistics recorded by the cache mbc device
//
// Parameters:
//   struct cache_mbc *cache                    pointer to a struct cache_mbc
//
// Returns: void
//*****************************************************************************

void 
cachembc_resetstats (struct cache_if *c)
{
  struct cache_mbc *cache = (struct cache_mbc *)c;
  cache->stat.reads = 0;
  cache->stat.readblocks = 0;
  cache->stat.readhitspartial = 0;
  cache->stat.readhitsfull = 0;
  cache->stat.readmisses = 0;
  cache->stat.popwrites = 0;
  cache->stat.popwriteblocks = 0;
  cache->stat.writes = 0;
  cache->stat.writeblocks = 0;
  cache->stat.writehitsfull = 0;
  cache->stat.writemisses = 0;
  cache->stat.destagereads = 0;
  cache->stat.destagereadblocks = 0;
  cache->stat.destagewrites = 0;
  cache->stat.destagewriteblocks = 0;
  cache->stat.maxbufferspace = 0;
}


//*****************************************************************************
// Function: cachembc_setcallbacks (hurst_r done)
//   Initializes the pointers to callback functions
//
// Parameters: void
//
// Returns: void
//*****************************************************************************

void 
cachembc_setcallbacks(void)
{
#ifdef DEBUG_CACHEMBC
   fprintf (outputfile, "*** %f: Entered cachedev::cachembc_setcallbacks\n", simtime );
#endif

  disksim->donefunc_cachembc_empty = cachembc_empty_donefunc;
  disksim->idlework_cachembc       = cachembc_idlework_callback;
  disksim->timerfunc_cachembc      = cachembc_periodic_callback;
}


//*****************************************************************************
// Function: cachembc_initialize (hurst_r done)
//   Initializes the cache_mbc data structure to default values
//
// Parameters:
//   struct cache_if *c, 
//   void (**issuefunc)(void *,ioreq_event *), 
//		     void *issueparam, 
//		     struct ioq * (**queuefind)(void *,int), 
//		     void *queuefindparam, 
//		     void (**wakeupfunc)(void *, struct cacheevent *), 
//		     void *wakeupparam, 
//		     int numdevs)
//
// Returns: void
//*****************************************************************************

void 
cachembc_initialize (struct cache_if *c, 
		     void (**issuefunc)(void *,ioreq_event *), 
		     void *issueparam, 
		     struct ioq * (**queuefind)(void *,int), 
		     void *queuefindparam, 
		     void (**wakeupfunc)(void *, struct cacheevent *), 
		     void *wakeupparam, 
		     int numdevs)
{
  int index;
  int dev_size;
  struct cache_mbc *cache = (struct cache_mbc *)c;
  StaticAssert (sizeof(struct cache_mbc_event) <= DISKSIM_EVENT_SIZE);

   cache->issuefunc = issuefunc;
   cache->issueparam = issueparam;
   cache->queuefind = queuefind;
   cache->queuefindparam = queuefindparam;
   cache->wakeupfunc = wakeupfunc;
   cache->wakeupparam = wakeupparam;
   cache->bufferspace = 0;
   cache->ongoing_requests = NULL;

   cache->hostTree    = RBTreeCreate( IntCompare, IntDestroy, InfoDestroy, IntPrint, InfoPrint );
   cache->diskTree    = RBTreeCreate( IntCompare, IntDestroy, InfoDestroy, IntPrint, InfoPrint );

   cachembc_resetstats(c);

   if (cache->flush_idledelay > 0.0) {
      struct ioq *queue = (*queuefind)(queuefindparam,cache->devno);
      ASSERT (queue != NULL);
      ioqueue_set_idlework_function (queue, 
				     &disksim->idlework_cachembc, 
				     cache, 
				     cache->flush_idledelay);
   }

   // count how many blocks are allocated to MBC partitions
   cache->size = 0;
   for( index = 0; index < cache->numMbcRegions; index++ )
   {
       cache->size += cache->mbcLocations[index].bcount;
   }

   dev_size = device_get_number_of_blocks(cache->devno);
   if (device_get_number_of_blocks(cache->devno) < cache->size) {
      fprintf (stderr, "Size of cachembc exceeds that of actual cache device (devno %d): %d > %d\n", cache->devno, cache->size, device_get_number_of_blocks(cache->devno));
      ddbg_assert(0);
   }
   cache->maxLBA = dev_size - cache->size;

#ifdef DEBUG_CACHEMBC
   fprintf( outputfile, "*** %f: cachembc_initialize devno %d, numMbcRegions %d, size %d, maxLBA %d\n", simtime, cache->devno, cache->numMbcRegions, cache->size, cache->maxLBA );
   for( int index = 0; index < cache->numMbcRegions; index++ )
   {
       fprintf( outputfile, "*** %f: cachembc_initialize startLBA %d, bcount %d, headIndex %d, tailIndex %d\n", simtime, cache->mbcLocations[index].startLBA, cache->mbcLocations[index].bcount, cache->mbcLocations[index].headBlockIndex, cache->mbcLocations[index].tailBlockIndex );
   }
#endif
}


//*****************************************************************************
// Function: cachembc_cleanstats (hurst_r not used)
//
// Parameters:
//   struct cache_mbc *cache                    pointer to a struct cache_mbc
//
// Returns: void
//*****************************************************************************

void 
cachembc_cleanstats (struct cache_if *cache)
{
    ddbg_assert2(0, "cachembc_cleanstats");
}


//*****************************************************************************
// Function: cachembc_printstats (hurst_r done)
//   Prints the contents of the statistics block to the given file with handle outputfile
//
// Parameters:
//   struct cache_if *c
//   char *prefix
//
// Returns: void
//*****************************************************************************

void 
cachembc_printstats (struct cache_if *c, char *prefix)
{
	int index;
    struct cache_mbc *cache = (struct cache_mbc *)c;
    int reqs = cache->stat.reads + cache->stat.writes;
    int blocks = cache->stat.readblocks + cache->stat.writeblocks;

    fprintf (outputfile, "%scache requests:                   %6d\n", prefix, reqs);
    if (reqs == 0) {
        return;
    }

    // read statistics
    fprintf (outputfile, "%scache read requests:              %6d  \t%6.4f\n", prefix, cache->stat.reads, ((double) cache->stat.reads / (double) reqs));

    fprintf(outputfile, "%scache blocks read:                %6d  \t%6.4f\n", prefix, cache->stat.readblocks, ((double) cache->stat.readblocks / (double) blocks));
    fprintf(outputfile, "%scache read misses:                %6d  \t%6.4f  \t%6.4f\n", prefix, cache->stat.readmisses, ((double) cache->stat.readmisses / (double) reqs), ((double) cache->stat.readmisses / (double) cache->stat.reads));

    fprintf(outputfile, "%scache read partial hits:          %6d  \t%6.4f  \t%6.4f\n", prefix, cache->stat.readhitspartial, ((double) cache->stat.readhitspartial / (double) reqs), ((double) cache->stat.readhitspartial / (double) cache->stat.reads));
    fprintf(outputfile, "%scache read full    hits:          %6d  \t%6.4f  \t%6.4f\n", prefix, cache->stat.readhitsfull, ((double) cache->stat.readhitsfull / (double) reqs), ((double) cache->stat.readhitsfull / (double) cache->stat.reads));

    fprintf(outputfile, "%scache population writes:          %6d  \t%6.4f  \t%6.4f\n", prefix, cache->stat.popwrites, ((double) cache->stat.popwrites / (double) reqs), ((double) cache->stat.popwrites / (double) cache->stat.reads));

    fprintf(outputfile, "%scache block population writes:    %6d  \t%6.4f  \t%6.4f\n", prefix, cache->stat.popwriteblocks, ((double) cache->stat.popwriteblocks / (double) blocks), ((double) cache->stat.popwriteblocks / (double) cache->stat.readblocks));

    // write statistics
    fprintf(outputfile, "%scache write requests:             %6d  \t%6.4f\n", prefix, cache->stat.writes, ((double) cache->stat.writes / (double) reqs));

    fprintf(outputfile, "%scache blocks written:             %6d  \t%6.4f\n", prefix, cache->stat.writeblocks, ((double) cache->stat.writeblocks / (double) blocks));
    fprintf(outputfile, "%scache write misses:               %6d  \t%6.4f  \t%6.4f\n", prefix, cache->stat.writemisses, ((double) cache->stat.writemisses / (double) reqs), ((double) cache->stat.writemisses / (double) cache->stat.writes));

    fprintf(outputfile, "%scache full write hits:            %6d  \t%6.4f  \t%6.4f\n", prefix, cache->stat.writehitsfull, ((double) cache->stat.writehitsfull / (double) reqs), ((double) cache->stat.writehitsfull / (double) cache->stat.writes));

    fprintf(outputfile, "%scache destage pre-reads:          %6d  \t%6.4f  \t%6.4f\n", prefix, cache->stat.destagereads, ((double) cache->stat.destagereads / (double) reqs), ((double) cache->stat.destagereads / (double) cache->stat.writes));
    fprintf(outputfile, "%scache block destage pre-reads:    %6d  \t%6.4f  \t%6.4f\n", prefix, cache->stat.destagereadblocks, ((double) cache->stat.destagereadblocks / (double) blocks), ((double) cache->stat.destagereadblocks / (double) cache->stat.writeblocks));

    fprintf(outputfile, "%scache destages (write):           %6d  \t%6.4f  \t%6.4f\n", prefix, cache->stat.destagewrites, ((double) cache->stat.destagewrites / (double) reqs), ((double) cache->stat.destagewrites / (double) cache->stat.writes));

    fprintf(outputfile, "%scache block destages (write):     %6d  \t%6.4f  \t%6.4f\n", prefix, cache->stat.destagewriteblocks, ((double) cache->stat.destagewriteblocks / (double) blocks), ((double) cache->stat.destagewriteblocks / (double) cache->stat.writeblocks));

    fprintf(outputfile, "%scache end dirty blocks:           %6d  \t%6.4f\n", prefix, cachembc_count_dirty_blocks(cache), ((double) cachembc_count_dirty_blocks(cache) / (double) cache->stat.writeblocks));

   fprintf (outputfile, "%scache bufferspace use end:        %6d\n", prefix, cache->bufferspace);

   fprintf (outputfile, "%scache bufferspace use max:        %6d\n", prefix, cache->stat.maxbufferspace);

   // print MBC data stats
   double deviceSizeBlocks = (double)device_get_number_of_blocks(cache->devno);
   double mbcSizeBlocks    = deviceSizeBlocks * cache->mbc_percentage;

   fprintf (outputfile, "%scache disk       max capacity (blocks):   %d\n", prefix, (int)deviceSizeBlocks);
   fprintf (outputfile, "%scache disk w/MBC max capacity (blocks):   %d\n", prefix, cache->maxLBA);
   fprintf (outputfile, "%scache MBC total capacity (blocks)     :   %d\n", prefix, cache->size);
   fprintf (outputfile, "%scache MBC number of partitions        :   %d\n", prefix, cache->numMbcRegions);

   for( index = 0; index < cache->numMbcRegions; index++ )
   {
       fprintf (outputfile, "%scache MBC area %d  start LBA           :   %d\n", prefix, index, cache->mbcLocations[index].startLBA );
       fprintf (outputfile, "%scache MBC area %d  size                :   %d\n", prefix, index, cache->mbcLocations[index].bcount );
       fprintf (outputfile, "%scache MBC area %d  headBlockIndex      :   %d\n", prefix, index, cache->mbcLocations[index].headBlockIndex );
       fprintf (outputfile, "%scache MBC area %d  tailBlockIndex      :   %d\n", prefix, index, cache->mbcLocations[index].tailBlockIndex );
   }
}


//*****************************************************************************
// Function: cachembc_copy (hurst_r done)
//   makes a copy of the given struct cache_mbc and returns a pointer to it
//
// Parameters:
//   struct cache_if *c
//
// Returns: struct cache_mbc *
//*****************************************************************************

struct cache_if * 
cachembc_copy (struct cache_if *c)
{
  struct cache_mbc *cache = (struct cache_mbc *)c;
  struct cache_mbc *newCache = (struct cache_mbc *) DISKSIM_malloc(sizeof(struct cache_mbc));

  ASSERT(newCache != NULL);
  bzero (newCache, sizeof(struct cache_mbc));
  
  newCache->issuefunc = cache->issuefunc;
  newCache->issueparam = cache->issueparam;
  newCache->queuefind = cache->queuefind;
  newCache->queuefindparam = cache->queuefindparam;
  newCache->wakeupfunc = cache->wakeupfunc;
  newCache->wakeupparam = cache->wakeupparam;
  newCache->size = cache->size;
  newCache->maxreqsize = cache->maxreqsize;
  
  return (struct cache_if *)newCache;
}

static struct cache_if disksim_cache_mbc = {
  cachembc_setcallbacks,
  cachembc_initialize,
  cachembc_resetstats,
  cachembc_printstats,
  cachembc_cleanstats,
  cachembc_copy,
  cachembc_get_block,
  cachembc_free_block_clean,
  cachembc_free_block_dirty,
  cachembc_disk_access_complete,
  cachembc_wakeup_complete,
  cachembc_sync,
  cachembc_get_maxreqsize
};


//*****************************************************************************
// Function: disksim_cachembc_loadparams
//   Initializes a struct cache_mbc from the contents for the given parameter file
//
// Parameters: void
//
// Returns: struct cache_mbc *
//*****************************************************************************

struct cache_if *disksim_cachembc_loadparams( struct lp_block *b )
{
  int c;
  struct cache_mbc *result;

  result = (struct cache_mbc *)calloc(1, sizeof(struct cache_mbc));
  result->hdr = disksim_cache_mbc;
  result->name = b->name ? strdup(b->name) : 0;

  lp_loadparams( result, b, &disksim_cachembc_mod );

  return (struct cache_if *)result;
}


int load_mbc_def(struct lp_block *b, cachembc_location_t *result) {

  //#include "modules/disksim_synthgen_param.c"
  lp_loadparams( result, b, &disksim_cachembc_location_mod);
  return 0;
}


//*****************************************************************************
// Function: load_mbc_locations
//   Parses the lp_list data structure and initializes the
//   array of cachembc_location_t *mbcLocations data structures.
//
// Parameters: void
//
// Returns: struct cache_mbc *
//*****************************************************************************

int 
load_mbc_locations(struct cache_mbc *result, struct lp_list *list )
{
  int c;
  int slot = 0;

  result->mbcLocations = (cachembc_location_t *)calloc( 1, list->values_len * sizeof(cachembc_location_t) );
  cachembc_location_t * mbc_location = result->mbcLocations;

  for(c = 0; c < list->values_len; c++) {
    if(!list->values[c]) continue;

    if(list->values[c]->t != BLOCK) {
      fprintf(stderr, "*** error: bad cache mbc spec -- must be a block.\n");
      return -1;
    }

    if( load_mbc_def( list->values[c]->v.b, &mbc_location[slot] ))
      return -1;

    slot++;
  }

  for(c = 0; c < slot; c++) {
      mbc_location[slot].headBlockIndex = mbc_location[slot].tailBlockIndex = 0;
  }

  result->numMbcRegions = slot;
  return 0;
}


/* this is a dummy that should never be called */
int disksim_cachembc_location_loadparams(struct lp_block *b) { 
  ddbg_assert2(0, "this is a dummy that isn't supposed to be called");
  return 0;
}

// End of file disksim_cachembc.c
