/*
 * disksim_org_decluster_load_init.c
 *
 *  Created on: May 22, 2015
 *      Author: zhengyi.zhao@wdc.com
 */

#include <string.h>

#include "disksim_logorg.h"
#include "org_parity.h"

#define _ORG_CONST_STRNG_CONVENTIONAL_RAID    "RAID"
#define _ORG_CONST_STRNG_GENERAL_REED_SOLOMON "RS"
#define _ORG_CONST_STRNG_LOCAL_RECONSTRUCT    "LRC"

void _org_decode_ckg_with_raid(int nNum_drives_per_ckg, // input
		char * linebuf,									// input string buffer
		org_chunk_group_map *stpCurr_ckg_mapping);
void _org_decode_ckg_with_reed_solomon(int nNum_drives_per_ckg, // input
		char * linebuf,									// input string buffer
		org_chunk_group_map *stpCurr_ckg_mapping);
void _org_decode_ckg_with_local_reconstruction(int nNum_drives_per_ckg, // input
		char * linebuf,									// input string buffer
		org_chunk_group_map *stpCurr_ckg_mapping);

int logorg_load_force_rebuild_drives(logorg *result, char *strFilename_rebuild_drives_list)
{

int iReduild_drv_id, rv;
FILE *fptr;
char linebuf[1024];

	fptr = fopen(strFilename_rebuild_drives_list, "r");
	if(fptr != NULL)
	{
		rv = (fgets(linebuf, sizeof(linebuf), fptr) != 0);

		switch(result->nTotal_drive_to_rebuild)
		{
		case 1:
			sscanf(linebuf, "%d", &result->anNode_id_list_rebuild[0]);
			result->iNode_id_org_rebuild = result->anNode_id_list_rebuild[0];
			break;
		case 2:
			sscanf(linebuf, "%d, %d",
					&result->anNode_id_list_rebuild[0],
					&result->anNode_id_list_rebuild[1]);
			break;
		case 3:
			sscanf(linebuf, "%d,%d,%d",
					&result->anNode_id_list_rebuild[0],
					&result->anNode_id_list_rebuild[1],
					&result->anNode_id_list_rebuild[2]);
			break;
		case 4:
			sscanf(linebuf, "%d,%d,%d,%d",
					&result->anNode_id_list_rebuild[0],
					&result->anNode_id_list_rebuild[1],
					&result->anNode_id_list_rebuild[2],
					&result->anNode_id_list_rebuild[3]);
			break;
		case 5:
			sscanf(linebuf, "%d,%d,%d,%d,%d",
					&result->anNode_id_list_rebuild[0],
					&result->anNode_id_list_rebuild[1],
					&result->anNode_id_list_rebuild[2],
					&result->anNode_id_list_rebuild[3],
					&result->anNode_id_list_rebuild[4]);
			break;
		case 6:
			sscanf(linebuf, "%d,%d,%d,%d,%d,%d",
					&result->anNode_id_list_rebuild[0],
					&result->anNode_id_list_rebuild[1],
					&result->anNode_id_list_rebuild[2],
					&result->anNode_id_list_rebuild[3],
					&result->anNode_id_list_rebuild[4],
					&result->anNode_id_list_rebuild[5]);
			break;
		case 7:
			sscanf(linebuf, "%d,%d,%d,%d,%d,%d,%d",
					&result->anNode_id_list_rebuild[0],
					&result->anNode_id_list_rebuild[1],
					&result->anNode_id_list_rebuild[2],
					&result->anNode_id_list_rebuild[3],
					&result->anNode_id_list_rebuild[4],
					&result->anNode_id_list_rebuild[5],
					&result->anNode_id_list_rebuild[6]);
			break;
		case 8:
			sscanf(linebuf, "%d,%d,%d,%d,%d,%d,%d,%d",
					&result->anNode_id_list_rebuild[0],
					&result->anNode_id_list_rebuild[1],
					&result->anNode_id_list_rebuild[2],
					&result->anNode_id_list_rebuild[3],
					&result->anNode_id_list_rebuild[4],
					&result->anNode_id_list_rebuild[5],
					&result->anNode_id_list_rebuild[6],
					&result->anNode_id_list_rebuild[7]);
			break;
		case 0:
			printf("Warning: no drives to rebuild");
			break;
		default:
			printf("Error: maximum support 8 drives to rebuild for simulation");
		}
		fclose(fptr);
	}


	return 0;
}

void lororg_load_ckg_erasure_scheme_pattern_reed_solomon(char * linebuf,
		org_parity_pattern* stpCurr_parity_pattern)
{
char *pCh, *pCh_next;
int nData_node, nParity_node, cOrder, cNode_id;
int nPattern_id;
org_global_parity* stpCurr_global_parity;

	    pCh = strstr(linebuf, ":");
	    sscanf(linebuf, "RS_D%d_P%d_ptn_%d:", &nData_node, &nParity_node, &nPattern_id);

	if(stpCurr_parity_pattern->nParity_pattern_id == nPattern_id)
	{
		stpCurr_parity_pattern->nNum_global_parity_nodes = nParity_node;
		stpCurr_parity_pattern->nNum_local_parity_nodes = 0;
		stpCurr_parity_pattern->nNum_total_parity_nodes = nParity_node;
		stpCurr_global_parity = stpCurr_parity_pattern->stpGlobal_parity;
		pCh = strstr(linebuf, "<");
		if(pCh != NULL)
		{
			pCh ++;
			for(int pp = 0; pp<nParity_node; pp++)
			{
				sscanf(pCh, "Gp ord-%d: %d,", &cOrder, &cNode_id);
				stpCurr_global_parity->nOrder = cOrder;
				stpCurr_global_parity->nIdx_node = cNode_id;
				stpCurr_global_parity ++;
				if(pp <= nParity_node -2)
				{
					pCh_next = strstr(pCh, ",");
					if(pCh_next != NULL)
					{
						pCh = pCh_next+1;
						while(*pCh == ' ')
						{
							pCh ++;
						}
					}
					else
					{
						break;
					}
				}
			}
		}
	}
	else
	{
		printf("Error, parity pattern id NOT match");
	}

char cFlag_is_parity_node = 0, idxCurr_data_node = 0;
	stpCurr_parity_pattern->nNum_total_data_nodes = nData_node;
	for(int dd = 0; dd<(nData_node +nParity_node); dd++ )
	{
		cFlag_is_parity_node = 0;
		stpCurr_global_parity = stpCurr_parity_pattern->stpGlobal_parity;
		for(int pp = 0; pp<nParity_node; pp++)
		{
			if(dd == stpCurr_global_parity->nIdx_node)
			{
				cFlag_is_parity_node = 1;
				break;
			}
			stpCurr_global_parity ++; // @021
		}

		if(cFlag_is_parity_node)
		{
			continue;
		}
		else
		{
			stpCurr_parity_pattern->aIdx_data_nodes[idxCurr_data_node] = dd;
			idxCurr_data_node ++;
		}
	}
}

void lororg_load_ckg_erasure_scheme_pattern_local_reconstruction(char * linebuf,
		org_parity_pattern* stpCurr_parity_pattern)
{
	char *pCh, *pCh_next, *pCh_next_group;
	int nData_node, nGlobal_parity_node, nLocal_parity_node, cOrder, cNode_id;
	int nPattern_id;
	org_global_parity* stpCurr_global_parity;
	org_local_parity* stpCurr_local_parity;
	int nLp_group_id;

	pCh = strstr(linebuf, ":");
	sscanf(linebuf, "LRC_D%d_GP%d_LP%d_ptn_%d:", &nData_node,
			&nGlobal_parity_node, &nLocal_parity_node, &nPattern_id);

	if(stpCurr_parity_pattern->nParity_pattern_id == nPattern_id)
	{
		stpCurr_global_parity = stpCurr_parity_pattern->stpGlobal_parity;
		stpCurr_parity_pattern->nNum_global_parity_nodes = nGlobal_parity_node;
		stpCurr_parity_pattern->nNum_local_parity_nodes = nLocal_parity_node;
		stpCurr_parity_pattern->nNum_total_parity_nodes = nLocal_parity_node + nGlobal_parity_node;

		pCh = strstr(linebuf, "<");
		if(pCh != NULL)
		{
			pCh ++;
			for(int pp = 0; pp<nGlobal_parity_node; pp++)
			{
				sscanf(pCh, "Gp ord-%d: %d,", &cOrder, &cNode_id);
				stpCurr_global_parity->nOrder = cOrder;
				stpCurr_global_parity->nIdx_node = cNode_id;
				stpCurr_global_parity ++;

					pCh_next = strstr(pCh, ",");
					if(pCh_next != NULL)
					{
						pCh = pCh_next+1;
						while(*pCh == ' ')
						{
							pCh ++;
						}
					}
					else
					{
						break;
					}

			}

			stpCurr_local_parity = stpCurr_parity_pattern->stpLocal_parity_group;
			for(int pp=0; pp<nLocal_parity_node -1; pp++)
			{
				sscanf(pCh, "Lp-group_%d, P#%d,", &nLp_group_id, &cNode_id);
				stpCurr_local_parity->nIdx_local_group = nLp_group_id;
				stpCurr_local_parity->nIdx_parity_node = cNode_id;
				pCh_next = strstr(pCh, "D<");
				if(pCh_next != NULL)
				{
					pCh = pCh_next + 2;
				}
				sscanf(pCh, "%d,",
						&stpCurr_local_parity->aData_nodes[stpCurr_local_parity->nNum_data_in_group]);
				stpCurr_local_parity->nNum_data_in_group ++;
				pCh_next_group = strstr(pCh, ">,");
				pCh_next = strstr(pCh, ",");
				while(! strstr(pCh_next_group, pCh_next))
				{
					pCh = pCh_next + 2;
					sscanf(pCh, "%d,",
							&stpCurr_local_parity->aData_nodes[stpCurr_local_parity->nNum_data_in_group]);
					stpCurr_local_parity->nNum_data_in_group ++;
					pCh_next = strstr(pCh, ",");
				}
				pCh_next = strstr(pCh, "Lp-group");
				pCh = pCh_next;
				stpCurr_local_parity++;
			}

			sscanf(pCh, "Lp-group_%d, P#%d,", &nLp_group_id, &cNode_id);
			stpCurr_local_parity->nIdx_local_group = nLp_group_id;
			stpCurr_local_parity->nIdx_parity_node = cNode_id;
			pCh_next = strstr(pCh, "D<");
			if(pCh_next != NULL)
			{
				pCh = pCh_next + 2;
			}
			sscanf(pCh, "%d,",
					&stpCurr_local_parity->aData_nodes[stpCurr_local_parity->nNum_data_in_group]);
			stpCurr_local_parity->nNum_data_in_group ++;
			pCh_next_group = strstr(pCh, ">");
			pCh_next = strstr(pCh, ",");
			while(pCh_next != NULL)
			{
				pCh = pCh_next+2;
				sscanf(pCh, "%d,",
						&stpCurr_local_parity->aData_nodes[stpCurr_local_parity->nNum_data_in_group]);
				stpCurr_local_parity->nNum_data_in_group ++;
				pCh_next = strstr(pCh, ",");
			}

		}
	}
	else
	{
		printf("Error, parity pattern id NOT match");
	}

char cFlag_is_parity_node = 0, idxCurr_data_node = 0;
	stpCurr_parity_pattern->nNum_total_data_nodes = nData_node;
	for(int dd = 0; dd<(nData_node + nGlobal_parity_node + nLocal_parity_node); dd++ )
	{
		cFlag_is_parity_node = 0;
		stpCurr_global_parity = stpCurr_parity_pattern->stpGlobal_parity;
		for(int pp = 0; pp<nGlobal_parity_node; pp++)
		{
			if(dd == stpCurr_global_parity->nIdx_node)
			{
				cFlag_is_parity_node = 1;
				break;
			}
			else
			{
				stpCurr_global_parity ++;
			}
		}

		if(cFlag_is_parity_node == 0)
		{
			stpCurr_local_parity = stpCurr_parity_pattern->stpLocal_parity_group;
			for(int pp = 0; pp<nLocal_parity_node; pp++)
			{
				if(dd == stpCurr_local_parity->nIdx_parity_node)
				{
					cFlag_is_parity_node = 1;
					break;
				}
				else
				{
					stpCurr_local_parity ++;
				}
			}
		}

		if(cFlag_is_parity_node)
		{
			continue;
		}
		else
		{
			stpCurr_parity_pattern->aIdx_data_nodes[idxCurr_data_node] = dd;
			idxCurr_data_node ++;
		}
	}
}

void logorg_load_chunk_group_mapping(char *strFilename_ckg_map,
		org_chunk_group_map * stpChunk_group_mapping,
		logorg *result)
{

	FILE *fptr;
	char linebuf[4096];
	int rv, cc, dd;
	int nTotal_active_ckgs_per_zone, nTotal_chunk_groups_per_zone;

	LBA_TYPE nTotal_chunk_groups = result ->nTotal_chunk_groups;
	int nNum_drives_per_ckg = result ->nNum_drives_per_ckg;
	org_chunk_group_map *stpCurr_ckg_mapping;
	int nMaxStripId = 0, nTotalStripesPerZone =0;

	char *pCh;
	int nNum_data_nodes, nNum_parity_nodes, nNum_global_parity, nNum_local_parity;

	org_global_parity* stpCurr_global_parity;
	org_local_parity* stpCurr_local_parity_pattern;
	org_parity_pattern* stpCurr_parity_pattern;

	nTotal_active_ckgs_per_zone = 0;
	if(stpChunk_group_mapping == NULL)
	{
		stpChunk_group_mapping = (org_chunk_group_map *) calloc(nTotal_chunk_groups, sizeof(org_chunk_group_map));
	}
	stpCurr_ckg_mapping = stpChunk_group_mapping;

	result->nTotal_LBAs_per_ckg_zone = nTotal_chunk_groups * nNum_drives_per_ckg * result->stripeunit;


	if(strstr(result->strErasure_code_scheme, _ORG_CONST_STRNG_GENERAL_REED_SOLOMON))
	{
		sscanf(result->strErasure_code_scheme, "RS_D%d_P%d", &nNum_data_nodes, &nNum_parity_nodes);

		result->stpOrg_parity_pattern =
				(org_parity_pattern*)calloc(result->nNum_parity_patterns, sizeof(org_parity_pattern));

		stpCurr_parity_pattern = result->stpOrg_parity_pattern;
		for(int pp=0; pp<result->nNum_parity_patterns; pp++)
		{
			stpCurr_parity_pattern->nParity_pattern_id = pp + 1;

			stpCurr_parity_pattern->stpGlobal_parity =
					(org_global_parity*)calloc(nNum_parity_nodes, sizeof(org_global_parity));
			result->astpOrg_parity_pattern_list[pp] = stpCurr_parity_pattern; // @021
			stpCurr_parity_pattern++;
		}

		stpCurr_ckg_mapping = stpChunk_group_mapping;
		for(int cc = 0; cc<nTotal_chunk_groups; cc++)
		{
			stpCurr_ckg_mapping->nNum_data_nodes = nNum_data_nodes;
			stpCurr_ckg_mapping->nNum_local_parity_nodes = 0;
			stpCurr_ckg_mapping->nNum_global_parity_nodes = nNum_parity_nodes;
			stpCurr_ckg_mapping->nNum_parity_nodes = nNum_parity_nodes;
			stpCurr_ckg_mapping++;
		}
		stpCurr_ckg_mapping = stpChunk_group_mapping;

	}
	else if(strstr(result->strErasure_code_scheme, _ORG_CONST_STRNG_LOCAL_RECONSTRUCT))
	{
		sscanf(result->strErasure_code_scheme, "LRC_D%d_GP%d_LP%d",
				&nNum_data_nodes, &nNum_global_parity, &nNum_local_parity);

		nNum_parity_nodes = nNum_global_parity + nNum_local_parity;
		result->stpOrg_parity_pattern =
				(org_parity_pattern*)calloc(result->nNum_parity_patterns, sizeof(org_parity_pattern));
		stpCurr_parity_pattern = result->stpOrg_parity_pattern;
		for(int pp=0; pp<result->nNum_parity_patterns; pp++)
		{
			stpCurr_parity_pattern->nParity_pattern_id = pp+1;
			stpCurr_parity_pattern->stpLocal_parity_group =
					(org_local_parity*)calloc(nNum_local_parity, sizeof(org_local_parity));
			stpCurr_parity_pattern->stpGlobal_parity =
					(org_global_parity*)calloc(nNum_global_parity, sizeof(org_global_parity));
			result->astpOrg_parity_pattern_list[pp] = stpCurr_parity_pattern; // @021
			stpCurr_parity_pattern++;

		}

		stpCurr_ckg_mapping = stpChunk_group_mapping;
		for(int cc = 0; cc<nTotal_chunk_groups; cc++)
		{
			stpCurr_ckg_mapping->nNum_data_nodes = nNum_data_nodes;
			stpCurr_ckg_mapping->nNum_local_parity_nodes = nNum_local_parity;
			stpCurr_ckg_mapping->nNum_global_parity_nodes = nNum_global_parity;
			stpCurr_ckg_mapping->nNum_parity_nodes = nNum_global_parity + nNum_local_parity;
			stpCurr_ckg_mapping++;
		}
		stpCurr_ckg_mapping = stpChunk_group_mapping;
	}
	else
	{
		// default is RAID5
		result->stpOrg_parity_pattern =
				(org_parity_pattern*)calloc(1, sizeof(org_parity_pattern));
		stpCurr_parity_pattern = result->stpOrg_parity_pattern;
		stpCurr_parity_pattern->stpGlobal_parity =
				(org_global_parity*)calloc(1, sizeof(org_global_parity));
		result->astpOrg_parity_pattern_list[0] = stpCurr_parity_pattern; // @021

		stpCurr_parity_pattern->stpGlobal_parity->nOrder = 0;
		stpCurr_parity_pattern->stpGlobal_parity->nParity_pattern_id = 0;
		stpCurr_parity_pattern->stpGlobal_parity->nIdx_node = 0;

		stpCurr_parity_pattern->nNum_global_parity_nodes = 1;
		stpCurr_parity_pattern->nNum_local_parity_nodes = 0;
		stpCurr_parity_pattern->nNum_total_parity_nodes = 1;

		nNum_data_nodes = result->nNum_drives_per_ckg - 1;
		stpCurr_parity_pattern->nNum_total_data_nodes = nNum_data_nodes;
		for(int dd=1; dd<=nNum_data_nodes; dd++)
		{
			stpCurr_parity_pattern->aIdx_data_nodes[dd-1] = dd;
		}

		stpCurr_ckg_mapping = stpChunk_group_mapping;
		for(int cc = 0; cc<nTotal_chunk_groups; cc++)
		{
			stpCurr_ckg_mapping->nNum_data_nodes = nNum_data_nodes;
			stpCurr_ckg_mapping->nNum_local_parity_nodes = 0;
			stpCurr_ckg_mapping->nNum_global_parity_nodes = 1;
			stpCurr_ckg_mapping->nNum_parity_nodes = 1;
			stpCurr_ckg_mapping++;
		}
		stpCurr_ckg_mapping = stpChunk_group_mapping;

	}
	stpCurr_global_parity = result->stpOrg_parity_pattern->stpGlobal_parity;
	stpCurr_local_parity_pattern = result->stpOrg_parity_pattern->stpLocal_parity_group;
	stpCurr_parity_pattern = result->stpOrg_parity_pattern;

	result->nTotal_data_drives_per_ckg = nNum_data_nodes;

	fptr = fopen(strFilename_ckg_map, "r");
	if(fptr != NULL)
	{
		do
		{
			rv = (fgets(linebuf, sizeof(linebuf), fptr) != 0);
			if(rv == 0) break;
			if(linebuf[0] != '[')
			{
				if(strstr(linebuf,_ORG_CONST_STRNG_GENERAL_REED_SOLOMON))
				{
					lororg_load_ckg_erasure_scheme_pattern_reed_solomon(linebuf,
							stpCurr_parity_pattern);
					stpCurr_parity_pattern ++;
				}
				else if(strstr(linebuf, _ORG_CONST_STRNG_LOCAL_RECONSTRUCT))
				{
					lororg_load_ckg_erasure_scheme_pattern_local_reconstruction(linebuf,
							stpCurr_parity_pattern);
					stpCurr_parity_pattern ++;
				}
			}
			else
			{
				if(strstr(linebuf, _ORG_CONST_STRNG_CONVENTIONAL_RAID))
				{
					_org_decode_ckg_with_raid( nNum_drives_per_ckg,
						linebuf,
						stpCurr_ckg_mapping);
					if(stpCurr_ckg_mapping->nType_raid == 5)
					{
						for(dd=1; dd<nNum_drives_per_ckg; dd++)
						{
							stpCurr_ckg_mapping->anData_list_node_id[dd-1] =
									stpCurr_ckg_mapping->anDrive_id_per_ckg[dd];
						}
						stpCurr_ckg_mapping->nNum_data_nodes = nNum_drives_per_ckg - 1;
						stpCurr_ckg_mapping->anParity_list_node_id[0] = stpCurr_ckg_mapping->anDrive_id_per_ckg[0];
						stpCurr_ckg_mapping->nNum_parity_nodes = 1;
						stpCurr_ckg_mapping->nNum_global_parity_nodes = 1;
						stpCurr_ckg_mapping->nNum_local_parity_nodes = 0;
					}
					else if(stpCurr_ckg_mapping->nType_raid == 6)
					{
						for(dd=2; dd<nNum_drives_per_ckg; dd++)
						{
							stpCurr_ckg_mapping->anData_list_node_id[dd-2] =
									stpCurr_ckg_mapping->anDrive_id_per_ckg[dd];
						}
						stpCurr_ckg_mapping->nNum_data_nodes = nNum_drives_per_ckg - 2;
						stpCurr_ckg_mapping->anParity_list_node_id[0] = stpCurr_ckg_mapping->anDrive_id_per_ckg[0];
						stpCurr_ckg_mapping->anParity_list_node_id[1] = stpCurr_ckg_mapping->anDrive_id_per_ckg[1];
						stpCurr_ckg_mapping->nNum_parity_nodes = 2;
						stpCurr_ckg_mapping->nNum_global_parity_nodes = 2;
						stpCurr_ckg_mapping->nNum_local_parity_nodes = 0;

					}
				}
				else if (strstr(linebuf, _ORG_CONST_STRNG_GENERAL_REED_SOLOMON))
				{
					_org_decode_ckg_with_reed_solomon(nNum_drives_per_ckg, // input
							linebuf,									// input string buffer
							stpCurr_ckg_mapping) ;
					stpCurr_ckg_mapping->stpCurr_parity_pattern =
							result->astpOrg_parity_pattern_list[stpCurr_ckg_mapping->nParity_pattern_id - 1];

					stpCurr_ckg_mapping->nNum_data_nodes = stpCurr_ckg_mapping->stpCurr_parity_pattern->nNum_total_data_nodes;
					for(dd=0; dd<stpCurr_ckg_mapping->nNum_data_nodes; dd++)
					{
						stpCurr_ckg_mapping->anData_list_node_id[dd] =
								stpCurr_ckg_mapping->anDrive_id_per_ckg[stpCurr_ckg_mapping->stpCurr_parity_pattern->aIdx_data_nodes[dd]];
					}
					stpCurr_ckg_mapping->nNum_parity_nodes = stpCurr_ckg_mapping->stpCurr_parity_pattern->nNum_total_parity_nodes;
					stpCurr_ckg_mapping->nNum_global_parity_nodes = stpCurr_ckg_mapping->stpCurr_parity_pattern->nNum_global_parity_nodes;
					stpCurr_ckg_mapping->nNum_local_parity_nodes = stpCurr_ckg_mapping->stpCurr_parity_pattern->nNum_local_parity_nodes;

				}
				else if(strstr(linebuf, _ORG_CONST_STRNG_LOCAL_RECONSTRUCT))
				{
					_org_decode_ckg_with_local_reconstruction(nNum_drives_per_ckg, // input
							linebuf,									// input string buffer
							stpCurr_ckg_mapping);
					stpCurr_ckg_mapping->stpCurr_parity_pattern =
							result->astpOrg_parity_pattern_list[stpCurr_ckg_mapping->nParity_pattern_id - 1];

					stpCurr_ckg_mapping->nNum_data_nodes = stpCurr_ckg_mapping->stpCurr_parity_pattern->nNum_total_data_nodes;
					for(dd=0; dd<stpCurr_ckg_mapping->nNum_data_nodes; dd++)
					{
						stpCurr_ckg_mapping->anData_list_node_id[dd] =
								stpCurr_ckg_mapping->anDrive_id_per_ckg[stpCurr_ckg_mapping->stpCurr_parity_pattern->aIdx_data_nodes[dd]];
					}
					stpCurr_ckg_mapping->nNum_parity_nodes = stpCurr_ckg_mapping->stpCurr_parity_pattern->nNum_total_parity_nodes;
					stpCurr_ckg_mapping->nNum_global_parity_nodes = stpCurr_ckg_mapping->stpCurr_parity_pattern->nNum_global_parity_nodes;
					stpCurr_ckg_mapping->nNum_local_parity_nodes = stpCurr_ckg_mapping->stpCurr_parity_pattern->nNum_local_parity_nodes;
				}
				else
				{

				}

				// update satistics
				if(nMaxStripId < stpCurr_ckg_mapping->anStripe_id_per_ckg[0])
				{
					nMaxStripId = stpCurr_ckg_mapping->anStripe_id_per_ckg[0];
				}

				for(cc = 1; cc < nNum_drives_per_ckg; cc++)
				{
					if(nMaxStripId < stpCurr_ckg_mapping->anStripe_id_per_ckg[cc])
					{
						nMaxStripId = stpCurr_ckg_mapping->anStripe_id_per_ckg[cc];
					}
				}


				stpCurr_ckg_mapping ++;
				nTotal_active_ckgs_per_zone ++;

			}

		}while(rv != 0);
		fclose(fptr);

		nTotalStripesPerZone = nMaxStripId + 1;
		result->nTotal_active_stripes_per_zone = nTotalStripesPerZone;
		result->nTotal_active_ckgs_per_zone = nTotal_active_ckgs_per_zone;
	}

}

