/*
 * DiskSim Storage Subsystem Simulation Environment (Version 4.0)
 * Revision Authors: John Bucy, Greg Ganger
 * Contributors: John Griffin, Jiri Schindler, Steve Schlosser
 *
 * Copyright (c) of Carnegie Mellon University, 2001-2008.
 *
 * This software is being provided by the copyright holders under the
 * following license. By obtaining, using and/or copying this software,
 * you agree that you have read, understood, and will comply with the
 * following terms and conditions:
 *
 * Permission to reproduce, use, and prepare derivative works of this
 * software is granted provided the copyright and "No Warranty" statements
 * are included with all reproductions and derivative works and associated
 * documentation. This software may also be redistributed without charge
 * provided that the copyright and "No Warranty" statements are included
 * in all redistributions.
 *
 * NO WARRANTY. THIS SOFTWARE IS FURNISHED ON AN "AS IS" BASIS.
 * CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED AS TO THE MATTER INCLUDING, BUT NOT LIMITED
 * TO: WARRANTY OF FITNESS FOR PURPOSE OR MERCHANTABILITY, EXCLUSIVITY
 * OF RESULTS OR RESULTS OBTAINED FROM USE OF THIS SOFTWARE. CARNEGIE
 * MELLON UNIVERSITY DOES NOT MAKE ANY WARRANTY OF ANY KIND WITH RESPECT
 * TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.
 * COPYRIGHT HOLDERS WILL BEAR NO LIABILITY FOR ANY USE OF THIS SOFTWARE
 * OR DOCUMENTATION.
 *
 */



/*
 * DiskSim Storage Subsystem Simulation Environment (Version 2.0)
 * Revision Authors: Greg Ganger
 * Contributors: Ross Cohen, John Griffin, Steve Schlosser
 *
 * Copyright (c) of Carnegie Mellon University, 1999.
 *
 * Permission to reproduce, use, and prepare derivative works of
 * this software for internal use is granted provided the copyright
 * and "No Warranty" statements are included with all reproductions
 * and derivative works. This software may also be redistributed
 * without charge provided that the copyright and "No Warranty"
 * statements are included in all redistributions.
 *
 * NO WARRANTY. THIS SOFTWARE IS FURNISHED ON AN "AS IS" BASIS.
 * CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED AS TO THE MATTER INCLUDING, BUT NOT LIMITED
 * TO: WARRANTY OF FITNESS FOR PURPOSE OR MERCHANTABILITY, EXCLUSIVITY
 * OF RESULTS OR RESULTS OBTAINED FROM USE OF THIS SOFTWARE. CARNEGIE
 * MELLON UNIVERSITY DOES NOT MAKE ANY WARRANTY OF ANY KIND WITH RESPECT
 * TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.
 */

/*
 * DiskSim Storage Subsystem Simulation Environment
 * Authors: Greg Ganger, Bruce Worthington, Yale Patt
 *
 * Copyright (C) 1993, 1995, 1997 The Regents of the University of Michigan 
 *
 * This software is being provided by the copyright holders under the
 * following license. By obtaining, using and/or copying this software,
 * you agree that you have read, understood, and will comply with the
 * following terms and conditions:
 *
 * Permission to use, copy, modify, distribute, and sell this software
 * and its documentation for any purpose and without fee or royalty is
 * hereby granted, provided that the full text of this NOTICE appears on
 * ALL copies of the software and documentation or portions thereof,
 * including modifications, that you make.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS," AND COPYRIGHT HOLDERS MAKE NO
 * REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED. BY WAY OF EXAMPLE,
 * BUT NOT LIMITATION, COPYRIGHT HOLDERS MAKE NO REPRESENTATIONS OR
 * WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR
 * THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL NOT INFRINGE ANY
 * THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS. COPYRIGHT
 * HOLDERS WILL BEAR NO LIABILITY FOR ANY USE OF THIS SOFTWARE OR
 * DOCUMENTATION.
 *
 *  This software is provided AS IS, WITHOUT REPRESENTATION FROM THE
 * UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND
 * WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS
 * OF THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
 * INCLUDING SPECIAL , INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE
 * USE OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS
 * BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES
 *
 * The names and trademarks of copyright holders or authors may NOT be
 * used in advertising or publicity pertaining to the software without
 * specific, written prior permission. Title to copyright in this software
 * and any associated documentation will at all times remain with copyright
 * holders.
 */

#ifndef DISKSIM_LOGORG_H
#define DISKSIM_LOGORG_H

#include "disksim_global.h"
#include "disksim_stat.h"
#include "disksim_iosim.h"
#include "disksim_orgface.h"
#include "disksim_ioqueue.h"
#include "config.h"


/* Mapping types */

#define ASIS            1
#define IDEAL           2
#define RANDOM          3
#define STRIPED         4

/* Redundancy types */

#define NO_REDUN		1
#define SHADOWED        	2
#define PARITY_DISK     	3
#define PARITY_ROTATED  	4
#define PARITY_TABLE		5
#define PARITY_ROTATED_TABLE_2      6  // @015 for RAID-6 with 2 parity disks
#define DECLUSTER_RAID      7          // @016

#define __ORG_DECLUSTER_GENERAL_REED_SOLOMON__  20
#define __ORG_DECLUSTER_LOCAL_RECONSTRUCTION__  21

// stage flag to repair org
#define ORG_REPAIR_BY_FULL_DRIVE_REBUILD  0
#define ORG_REPAIR_BY_HOT_SPARE_CKG       1

/* Shadow disk read choices */

#define SHADOW_PRIMARY		1
#define SHADOW_RANDOM		2
#define SHADOW_ROUNDROBIN	3
#define SHADOW_SHORTDIST	4
#define SHADOW_SHORTQUEUE	5
#define SHADOW_SHORTQUEUE2	6

/* Parity rotation types */

#define PARITY_LEFT_SYM		1
#define PARITY_LEFT_ASYM	2
#define PARITY_RIGHT_ASYM	3
#define PARITY_RIGHT_SYM	4

#define LOGORG_PARITY_SEQGIVE	32
#define MAXCOPIES	10
#define NUMGENS 50
#define HASH_OUTSTAND   20

#define BLOCKINGMAX	128
#define INTERFEREMAX	32
#define INTDISTMAX	8

#define ORG_CHECKING_DISABLE             0
#define ORG_CHECKING_INITIALIZE_STRIPES  1
#define ORG_CHECKING_STRIPES_FSM         2

typedef struct dep {
   int    devno;
   LBA_TYPE    blkno; // @9
   int    numdeps;
   struct dep *next;
   struct dep *cont;
   ioreq_event *deps[10];
} depends;

typedef struct os {
   double arrtime;
   int    type;
   struct os *next;
   struct os *prev;
   u_int  bcount;
   LBA_TYPE  blkno;   // @9
   u_int  flags;
   u_int  busno;
   int    numreqs;
   u_int  devno;
   int    opid;
   int    reqopid;
   void  *buf;
   depends *depend;
} outstand;

typedef struct {
   double	outtime;
   double	runouttime;
   int		outstanding;
   int		readoutstanding;
   int		maxoutstanding;
   double	nonzeroouttime;
   int		reads;
   int		gens[NUMGENS];
   int		seqdiskswitches;
   int		locdiskswitches;
   int		numlocal;
   int		critreads;
   int		critwrites;
   int		seqreads;
   int		seqwrites;
   int		distavgdiff[10];
   int		distmaxdiff[10];
   double       idlestart;
   double       lastarr;
   double       lastread;
   double       lastwrite;
   int          *blocked;
   int          *aligned;
   int		*lastreq;
   int		*intdist;
   statgen      resptimestats;
   statgen	idlestats;
   statgen      sizestats;
   statgen	readsizestats;
   statgen	writesizestats;
   statgen      intarrstats;
   statgen      readintarrstats;
   statgen      writeintarrstats;
} logorgstat;

typedef struct {
   int    devno;
   LBA_TYPE    startblkno;
   struct ioq * queue;
   LBA_TYPE    lastblkno;
   int    seqreads;
   int    seqwrites;
   LBA_TYPE    lastblkno2;
   int    intreads;
   int    intwrites;
   int    numout;
   int    distnumout[10];
   int    curstreak;
   statgen streakstats;
   statgen localitystats;
   LBA_TYPE    nLBA_start; // @016
   LBA_TYPE    nLBA_end;   // @016
   int    nDev_type;
} logorgdev;

typedef struct {
   int    devno;
   LBA_TYPE    blkno; // @9
} tableentry;

#define _MAX_NUM_DRIVE_FAILURE_IN_ONE_ORG       8
#define _MAX_PARITY_PATTERN_  1024
#define MAX_NUM_DRIVE_STRIPE_PER_HOT_SPARE   2048
typedef struct _org_ckg_hot_spare_map
{
    int nId_org;
    int nTotal_drive_stripes;
    int anDrive_id_per_hot_spare[MAX_NUM_DRIVE_STRIPE_PER_HOT_SPARE];
    LBA_TYPE anStripe_id_hot_spare[MAX_NUM_DRIVE_STRIPE_PER_HOT_SPARE];
}org_ckg_hot_spare_map;

typedef struct _org_hot_spare_mapping_per_zone_ckg
{
	int aiFailure_drv_id_in_org[_MAX_NUM_DRIVE_FAILURE_IN_ONE_ORG];
	int aiHot_spare_drv_id_in_org[_MAX_NUM_DRIVE_FAILURE_IN_ONE_ORG];
	int aiHot_spare_drv_id_global[_MAX_NUM_DRIVE_FAILURE_IN_ONE_ORG];
	int aiHot_spare_tripe_id[_MAX_NUM_DRIVE_FAILURE_IN_ONE_ORG];
	int nTotal_drv_failure;
}org_hot_spare_mapping_per_zone_ckg; // @021

#include "org_parity.h"  // @021

#define MAX_NUM_DRIVES_PER_CKG    256
#define MAX_NUM_LOCAL_PARITY_GROUP    (MAX_NUM_DRIVES_PER_CKG/2)
typedef struct _org_chunk_group_map
{
    int nId_ckg;
    int nType_raid;
    int anDrive_id_per_ckg[MAX_NUM_DRIVES_PER_CKG];
    LBA_TYPE anStripe_id_per_ckg[MAX_NUM_DRIVES_PER_CKG];
    int nParity_pattern_id;
    int nNum_data_nodes;
    int anData_list_node_id[MAX_NUM_DRIVES_PER_CKG];
    int nNum_parity_nodes;
    int anParity_list_node_id[MAX_NUM_DRIVES_PER_CKG];
    int nNum_local_parity_nodes;
    int nNum_global_parity_nodes;
    org_parity_pattern *stpCurr_parity_pattern;
}org_chunk_group_map;

typedef struct _org_rebuild_ckg_list_per_zone
{
	org_chunk_group_map * stpCurrent_ckg;
	org_chunk_group_map * stpNext_ckg;
	struct _org_rebuild_ckg_list_per_zone *stpNext_list_item;
	int nCkg_rebuild_id;
	int nCkg_rebuild_count;
	int nNum_drive_rebuild; // @021
	int nTotal_parity_read; // @021
	int anParity_node_read_list[MAX_NUM_DRIVES_PER_CKG]; // @021
	int anFailure_nodes_per_local_parity[MAX_NUM_LOCAL_PARITY_GROUP];
	char cFlag_has_failure_in_global_parity;
}org_rebuild_ckg_list_per_zone;

#define TIME_DELAY_READ_CALC_ms   (10.0)
#define ORG_DEF_MAX_REBUILD_STRIPE  5000
typedef struct _node_rebuild_event_fsm
{
	LBA_TYPE nTotal_stripes;
	LBA_TYPE nCurrent_rebuild_stripe;
	LBA_TYPE nLBA_end;
	LBA_TYPE nStarting_rebuild_stripe_zoneckg;
	int iDevno_rebuild;
	int nNum_drive_rebuild;
	int anDevno_rebuild[_MAX_NUM_DRIVE_FAILURE_IN_ONE_ORG];   // @021
	LBA_TYPE nStripe_id_repair_from_hot_spare;
	LBA_TYPE anStripe_id_repair_from_hot_spare[_MAX_NUM_DRIVE_FAILURE_IN_ONE_ORG];
	int anRead_nodes_dev_no[256];
	int nTotal_nodes_read;

	LBA_TYPE nTotal_rebuild_zone_ckg;
	LBA_TYPE nCurrent_rebuild_zone_ckg;
	LBA_TYPE nCurrent_chunk_group_per_zone;
	int anDev_id_per_org[256]; // mapping from local id to global dev_id, @016
	                           // nDev_global_id = anDev_id_per_org[nDev_org_id]
	org_rebuild_ckg_list_per_zone *stpCurrend_rebuild_ckg_per_zone;
	int nCurrent_id_hot_spare_drive_stripe;
	org_ckg_hot_spare_map stHot_spare_drive_stripes;

	FILE *fptrDebug;
}org_node_rebuild_event_fsm;

typedef struct _periodical_checking_fsm
{
	int iFlag_enable_checking;
	int iFlag_has_issue_cmd_to_iodriver; // 			logorg_checking_drive_stripes_fsm(stpLogorg);
	LBA_TYPE nLBA_end;
	LBA_TYPE nTotal_checking_stripes;
	LBA_TYPE nCurrent_checking_stripe;
}org_periodical_checking_fsm;

typedef struct logorg {
  char *name;  // nOrg_id, by name
   outstand * hashoutstand[HASH_OUTSTAND];
   int    outstandqlen;
   int    opid;
   int    addrbyparts;
   int    maptype;
   int    reduntype;
   int    numdisks;       // nTotal_dev_number
   int    actualnumdisks; // nTotal_dev_number
   int    arraydisk;
   int    writesync;
   int    copies;
   int    copychoice;
   double rmwpoint;
   int    parityunit;
   int    rottype;
   LBA_TYPE    blksperpart;  // @9
   LBA_TYPE    actualblksperpart;
   LBA_TYPE    stripeunit;   // @9
   int    sectionunit;
   int    tablestripes;
   tableentry *table;    // stOrg_table
   int    tablesize;
   int    partsperstripe;
   int    idealno;
   int    reduntoggle;
   int    lastdiskaccessed;
   LBA_TYPE    numfull;  // @9
   int   *sizes;
   int   *redunsizes;
   int    printlocalitystats;
   int    printblockingstats;
   int    printinterferestats;
   int    printidlestats;
   int    printintarrstats;
   int    printstreakstats;
   int    printstampstats;
   int    printsizestats;
   double stampinterval;
   double stampstart;
   double stampstop;
   FILE * stampfile;
   logorgdev *devs;
   logorgstat stat;
   /* rcohen's additions */
   int    startdev;
   int    enddev;

   /* for rebuild function in background task after idle-delay*/
   org_node_rebuild_event_fsm stRebuild_event_fsm;
   org_periodical_checking_fsm stPeriodic_checking_fsm; // @016
   double tIdle_delay_ms;  // @016
   int nTotal_drive_to_rebuild;  // @021
   int anNode_id_list_rebuild[8];     // @021
   int iNode_id_org_rebuild;
   double dStarting_stripe_rebuild_percentage;
   LBA_TYPE nTotal_stripes_zones_to_rebuild;
   int iFlag_check_idle_task_in_org; // set a flag after checking priority
   int iFlag_rebuild_node_priority;
   int iFlag_repair_node_stage;

   struct ioq   *stpLogorg_queue;
   double tChecking_interval_ms; // a time interval to checking stripe integrity
   int iLogorg_timer_tick;
   int anNode_parity_factor[256]; // Assume it is Reed-Solomon based coding
   int iFlag_repair_in_partial_failure;

   char strErasure_code_scheme[512]; // string to specify the scheme of erasure coding
    // Samples
    //   RS_D2_P3
    //   LRC_D12_GP2_LP2
    //   RS_D12_P3
   double dHot_spare_reserve_percentage;
   org_chunk_group_map * stpChunk_group_mapping;
   LBA_TYPE nTotal_chunk_groups;
   int nNum_drives_per_ckg;
   int nTotal_data_drives_per_ckg;
   int nNum_parity_patterns;
   org_parity_pattern * stpOrg_parity_pattern;
   org_parity_pattern * astpOrg_parity_pattern_list[_MAX_PARITY_PATTERN_];

   int nTotal_ckg_rebuild_per_zone;
   int *aiCkg_id_rebuild_per_zone;
   org_rebuild_ckg_list_per_zone *stpRebuid_ckg_list_per_zone;
   org_chunk_group_map *stpInitial_rebuild_ckg_per_zone;

   int nTotal_active_ckgs_per_zone;
   int nTotal_chunk_groups_per_zone;  // including Hot spare
   LBA_TYPE nTotal_ckg_zones;          // the total capacity of the organization
   	   	   	   	   	   	   	   	   	   // total number of ckg zones per org
   org_hot_spare_mapping_per_zone_ckg **astHot_spare_mapping_per_zone_ckg; // @021
   int nTotal_OBAs_per_zone;
   LBA_TYPE nTotal_LBAs_per_ckg_zone;
   int nTotal_active_OBAs_per_zone;
   LBA_TYPE nTotal_active_LBAs_per_ckg_zone;
   int nTotal_active_stripes_per_zone;
   int nTotal_stripes_per_zone; // including hotspare

   int nRebuild_max_que_length; // @021
} logorg;


typedef struct _logorg_trace
{
	LBA_TYPE nLBA;
	int iDev_id_in_org;
	int iDev_id_global;
	int nBlkCount;
	int nOrder_ckg_parity;
}logorg_trace;

typedef struct _logorg_ckg_addr_by_trace
{
	logorg_trace stData_node_trace;
	logorg_trace astParity_ckg_trace[16]; // ckg-parity, or global parity
	logorg_trace stParity_loc_trace;      // local parity node
	int nZone_id;
	int nZone_addr_OBA;
	int nCkg_id;
	int nCkg_addr_OBA;
	int nIdx_curr_sdripe;
	int nLBA_offset_start;
	int nTotal_ckg_global_parity_trace;
	char cFlag_inside_local_parity_group;
	org_chunk_group_map * stpChunk_group;
	org_parity_pattern * stpOrg_parity_pattern;
}logorg_ckg_addr_by_trace;

typedef struct _logorg_ckg_addr
{
	logorg_ckg_addr_by_trace astCkg_data_parity_trace[32];
	int nTotal_nodes;
} logorg_ckg_addr;
/* exported disksim_logorg.c functions */

/* exported disksim_redun.c functions */

int  logorg_shadowed (logorg *currlogorg, ioreq_event *curr, int numreqs);
int  logorg_parity_disk (logorg *currlogorg, ioreq_event *curr, int numreqs);
int  logorg_parity_rotate (logorg *currlogorg, ioreq_event *curr, int numreqs);
int  logorg_parity_table (logorg *currlogorg, ioreq_event *curr, int numreqs);
int logorg_parity_table_2(logorg *currlogorg, ioreq_event *curr, int numreqs); // @015, RAID-6
int __check_id_appear_in_know_int_list(int *aiList, int nList_len, int id);

int logorg_decluster_ckg_with_parity_pattern(logorg *currlogorg, ioreq_event *curr, int numreqs,
		logorg_ckg_addr *stpOrg_ckg_addresss); // @021
int logorg_gen_ckg_request(logorg *currlogorg, ioreq_event *curr, logorg_ckg_addr *stpOrg_ckg_addresss); // 0021
int logorg_gen_ckg_request_with_fail_node(logorg *currlogorg,	ioreq_event *curr, logorg_ckg_addr *stpOrg_ckg_address);
int logorg_gen_ckg_request_with_rmw_setting(logorg *currlogorg,	ioreq_event *curr, logorg_ckg_addr *stpOrg_ckg_address);

int logorg_check_id_in_rebuild_list(logorg *stpCurr_org, int iNode);
int logorg_check_num_drive_rebuild_by_ckg_list(logorg *stpCurrorg, int *aDrive_list_in_ckg);

void logorg_create_table (logorg *currlogorg);
int  logorg_tabular_rottype (int maptype, int reduntype, int rottype, LBA_TYPE stripeunit); // @9
int  logorg_check_dependencies (logorg *currlogorg, outstand *req, ioreq_event *curr);

// get the logorg (and number in *n) of the logorg called <name>
// or 0 if it doesn't exist
logorg *getlogorgbyname(logorg **, int, char *name, int *n);

INLINE void logorg_set_arraydisk(struct logorg *l, int n);

logorg *getlogorgbyname(logorg **logorgs, 
			int numlogorgs, 
			char *name, 
			int *n);

void logorg_cleanup(logorg *);
int logorg_addr(logorg *result, char *s);
int logorg_distn(logorg *result, char *s);
int logorg_redun(logorg *result, char *s);
int logorg_load_force_rebuild_drives(logorg *result, char *s);		// @021
int logorg_load_erasure_code_scheme(logorg *result, char *s); 		// @021
int getlogorgdevs(logorg *result, struct lp_list *l);
int logorg_load_hotspare_reserve_percent(logorg *result, char *s);  // @016

void logorg_addnewtooutstandq (logorg *currlogorg, outstand *temp); // @016
void logorg_rebuild_one_stripe(struct logorg *stpLogorg);
void logorg_general_parity_rebuild_one_stripe(struct logorg *stpLogorg); // @021
void logorg_decluster_init_hot_spare_all_zones(logorg *stpLogorg); // @021
void logorg_rebuild_ckg_one_stripe_with_sync(struct logorg *stpLogorg); // @020

void logorg_rebuild_ckg_stripe(struct logorg *stpLogorg);
void logorg_checking_drive_stripes_fsm(struct logorg *stpLogorg);
void logorg_load_chunk_group_mapping(char *strFilename_ckg_map,
		org_chunk_group_map * stpChunk_group_mapping,
		logorg *result);

org_rebuild_ckg_list_per_zone* logorg_create_new_item_in_rebuild_list(logorg *stpCurrorg);
void logorg_idletime_detected (void *idleworkparam, int nIdle_logorg_num);

int  logorg_check_ckg_integrity(logorg *stpCurrorg);
void logorg_init_hot_spare_drive_stripe(struct logorg *stpLogorg, int logorgnum);
int logorg_modulus_update (int inc, int val, int maxval);
void logorg_check_rebuild_at_io_driver(int iodriverno, struct logorg *stpLogorg, int nLogorgId);
void logorg_repair_ckg_one_node_by_hot_spare_fsm(struct logorg *stpLogorg, int logorgnum);
void logorg_repair_ckg_nodes_by_hot_spare_fsm(struct logorg *stpLogorg, int logorgnum);  // @021
void logorg_repair_ckg_reed_solomon_nodes_by_hot_spare_fsm(struct logorg *stpLogorg, int logorgnum); // @021
void logorg_repair_ckg_local_reconstruct_nodes_by_hot_spare_fsm(struct logorg *stpLogorg, int logorgnum);
void logorg_rebuild_nodes_reed_solomon_ckg_fsm(struct logorg *stpLogorg, int logorgnum);
void logorg_rebuild_nodes_local_reconstruct_ckg_fsm(struct logorg *stpLogorg, int logorgnum);
void logorg_rebuild_nodes_by_ckg_fsm(struct logorg *stpLogorg, int logorgnum);   // @021
void logorg_rebuild_one_node_by_ckg_fsm(struct logorg *stpLogorg, int logorgnum);
void logorg_build_parity_read_list_for_rebuild_local_reconstruct
			(logorg *stpLogorg, org_chunk_group_map *stpCurr_ckg,
					org_rebuild_ckg_list_per_zone *stpCurr_rebuild_ckg_in_fsm);

void logorg_build_parity_read_list_for_rebuild_reed_solomon(logorg *stpLogorg, org_chunk_group_map *stpCurr_ckg);

void logorg_decluster_ckg_init_setting(logorg *stpLogorg);

#endif  /* DISKSIM_LOGORG_H */

