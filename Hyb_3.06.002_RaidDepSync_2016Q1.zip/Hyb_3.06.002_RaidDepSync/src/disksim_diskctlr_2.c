/*
 * disksim_diskctlr_2.c
 *
 *  Created on: May 8, 2015
 *      Author: zhengyizhao
 */


/*
 * Possible improvements:
 *
 * As write sectors complete, appending writes may be able to put
 * more data into the cache.  However, need to find a way to keep
 * from having to check everything on the bus queue every time a
 * write sector completes.  Obviously can check for appending writes
 * in the same seg, but need to be conscious of watermarks for the
 * appending write as well.  (Don't reconnect just to xfer one more
 * sector after each sector completes -- unless watermark says so.)
 *
 * As read sectors complete, sneakyintermediatereads could become
 * available.  However, need to find a way to keep from having to
 * check everything on the bus queue every time a read sector
 * completes.
 */

/* I'm unhappy that this function does work looking at how it's
 * called, it should be made to only return a truth value, no side
 * effects -rcohen
 */

static int
disk_buffer_request_complete(disk *currdisk, diskreq *currdiskreq)
{
    int background;
    int reading;
    int reqdone = FALSE;
    int hold_type;
    double acctime;
    int watermark = FALSE;
    ioreq_event *tmpioreq = currdiskreq->ioreqlist;
    segment *seg = currdiskreq->seg;

#ifdef DEBUG_DISKCTLR
    fprintf (outputfile, "%f: disk_buffer_request_complete  Entering\n", simtime );
    fflush(outputfile);
#endif

    // get the last ioreq_event
    while (tmpioreq && tmpioreq->next) {
        tmpioreq = tmpioreq->next;
    }

    background = seg->access->flags & BUFFER_BACKGROUND;
    reading = (seg->state == BUFFER_READING);
    if(currdisk->outwait) {
        currdisk->outwait->time = simtime;
        currdisk->outwait->bcount = 0;
        addtointq((event *) currdisk->outwait);
        currdisk->outwait = NULL;
    }


    if(reading) {
        if(background) {
            if(seg->endblkno >= seg->maxreadaheadblkno) {
                reqdone = TRUE;
            }
        }
        else {
            if((seg->endblkno - currdiskreq->outblkno) >= currdiskreq->watermark) {
                watermark = TRUE;
            }

            if(seg->endblkno >= (tmpioreq->blkno + tmpioreq->bcount)) {
                // here, we have detected the end of the read command
                reqdone = TRUE;
            }
        }
    }
    else {                     /* (!reading) -> WRITE */
        if(background) {
            if(seg->endblkno == currdiskreq->inblkno) {
                reqdone = TRUE;
            }
        }
        else {
            if((seg->endblkno - currdiskreq->inblkno) <= currdiskreq->watermark) {
                if(seg->endblkno < (tmpioreq->blkno + tmpioreq->bcount)) {
                    watermark = TRUE;
                }
            }

            if(currdiskreq->inblkno >= (tmpioreq->blkno + tmpioreq->bcount)) {
                // here, we have detected the end of the write command
                reqdone = TRUE;
            }
        }
    }

    double rotatetime = // @10
            dm_time_itod(currdisk->model->mech->dm_period(currdisk->model));


    if((background && reqdone && reading) || (seg->outstate == BUFFER_PREEMPT))
    {
        seg->access->type = NULL_EVENT;
        disk_release_hda(currdisk, currdiskreq);
        return(TRUE);
    }

    if(!background && (seg->outstate == BUFFER_IDLE) && (reqdone | watermark) )
    {
        disk_check_bus(currdisk,currdiskreq);
    }

    if (background && reading && (seg->endblkno == seg->minreadaheadblkno)
            && ((currdisk->preseeking == PRESEEK_BEFORE_COMPLETION)
                    || (currdiskreq->flags & COMPLETION_RECEIVED)
                    || ((currdisk->preseeking == PRESEEK_DURING_COMPLETION)
                            && (currdiskreq->flags & COMPLETION_SENT))))
    {
        hold_type = seg->access->type;
        seg->access->type = NULL_EVENT;
        disk_check_prefetch_swap(currdisk);
        if ((seg->outstate == BUFFER_PREEMPT)
                || (currdisk->effectivehda != currdiskreq))
        {
            return (TRUE);
        }
        seg->access->type = hold_type;
    }
    else if ((!background || !reading) && reqdone)
    {
        // check if we are done
#ifdef DEBUG_DISKCTLR
        ioqueue_print_contents(currdisk->queue);
#endif
        if (!reading || (currdisk->contread == BUFFER_NO_READ_AHEAD)
                || (seg->endblkno >= seg->maxreadaheadblkno) || (currdisk->queue->base.listlen > 1) )
        {
            seg->access->type = NULL_EVENT;
        }
        else
        {
            seg->access->flags |= BUFFER_BACKGROUND;
            reqdone = FALSE;
        }

        if (currdisk->stat.seekdistance != -1)
        {
        	currdisk->stat.xfertime += rotatetime/(currdisk->track_high - currdisk->track_low + 1) ; // @012 simtime - seg->time; // Add one additional sector into the xfertime
            acctime = currdisk->stat.seektime + currdisk->stat.latency
                    + currdisk->stat.xfertime;

            simresult_update_diskInfo( currdiskreq->ioreqlist->tagID, currdisk->stat.seekdistance, currdisk->stat.seektime, currdisk->stat.latency, currdisk->stat.xfertime, acctime );

#ifdef DISKLOG_ON
            if( NULL !=  DISKSIM_DISK_LOG )
            {
                fprintf (DISKSIM_DISK_LOG, "\n********** %f: disk_buffer_request_complete  ACCTIMESTATS: distance %d, seektime %f, latency %f, xfertime %f, acctime %f\n",
                        simtime,
                        currdisk->stat.seekdistance,
                        currdisk->stat.seektime,
                        currdisk->stat.latency,
                        currdisk->stat.xfertime,
                        acctime);
                fflush(DISKSIM_DISK_LOG);
            }
#endif

            //  printf("ACCTIMESTATS(%d, %f, %f, %f, %f)\n",
            //	     currdisk->stat.seekdistance,
            ////	     currdisk->stat.seektime,
            //	     currdisk->stat.latency,
            //	     currdisk->stat.xfertime,
            //	     acctime);

    		if(currdisk->iFlag_smr_write_needs_update_wrro == 1) // @019
    		{
    			acctime = acctime + currdisk->tUpdate_smr_wrro_ms;
    		}
    		stat_update(&(currdisk->stat.stSMR_update_wrro), currdisk->tUpdate_smr_wrro_ms); // @019

            disk_acctimestats(currdisk, currdisk->stat.seekdistance,
                    currdisk->stat.seektime, currdisk->stat.latency,
                    currdisk->stat.xfertime, acctime);


            double fHeadEnergyRW = 0.0;
#ifdef __DISK_POWER__
            DISK_POWER_PARAMETER *stpPowerParameter = (DISK_POWER_PARAMETER *)(currdisk->model->stpPowerHDD);
            if(currdisk->stRegLastEvent.flags & READ)
            {
            	fHeadEnergyRW =
            			(stpPowerParameter->stPowerHeadRW_w.fHeadPowerRead *
            			currdisk->stat.xfertime * 0.001); //

            }
            else
            {
            	fHeadEnergyRW =  // stpPowerParameter->stPowerHeadRW_w.fHeadServoPower +
            			(stpPowerParameter->stPowerHeadRW_w.fHeadPowerWrite *
            			currdisk->stat.xfertime * 0.001); //
            }
#endif // POWER
            // The time's unit is 1ms, so it needs a factor of 0.001
            stat_update(&(currdisk->stat.stRW_HeadEnergyStats),
            		fHeadEnergyRW );

        }


        if((currdisk->stat.xfertime > rotatetime - 3.0) && (currdisk->stat.xfertime <= rotatetime)) // @10
        {
                fprintf (outputfile, "\n********** %f: disk_buffer_request_complete  ACCTIMESTATS: outwait:%d,distance %d, seektime %f, latency %f, xfertime %f, acctime %f, blk:%d, count:%d\n",
                        simtime,
                        currdisk->outwait,
                        currdisk->stat.seekdistance,
                        currdisk->stat.seektime,
                        currdisk->stat.latency,
                        currdisk->stat.xfertime,
                        acctime,
                        ((ioreq_event *)currdiskreq)->blkno,
                        ((ioreq_event *)currdiskreq)->bcount); // @10
        }

        tmpioreq = currdiskreq->ioreqlist;
        while (tmpioreq)
        {
            disk_interferestats(currdisk, tmpioreq);
            tmpioreq = tmpioreq->next;
        }

        currdisk->stat.seekdistance = -1;
        currdisk->stat.xfertime     = (double) 0.0;
        currdisk->stat.latency      = (double) 0.0;
        if (!reqdone
                && ((currdisk->preseeking == PRESEEK_BEFORE_COMPLETION)
                        || (currdiskreq->flags & COMPLETION_RECEIVED)
                        || ((currdisk->preseeking == PRESEEK_DURING_COMPLETION)
                                && (currdiskreq->flags & COMPLETION_SENT))))
        {
            hold_type = seg->access->type;
            seg->access->type = NULL_EVENT;
            disk_check_prefetch_swap(currdisk);
            if ((seg->outstate == BUFFER_PREEMPT)
                    || (currdisk->effectivehda != currdiskreq))
            {
                return (TRUE);
            }
            seg->access->type = hold_type;
        }
    }

    if (reqdone)
    {
        if (!reading)
        {
            // here, we are writing
            tmpioreq = currdiskreq->ioreqlist;
            while (tmpioreq)
            {
                ddbg_assert2(
                        ioqueue_physical_access_done(currdisk->queue,tmpioreq) != NULL,
                        "disk_buffer_request_complete:  ioreq_event "
                        "not found by ioqueue_physical_access_done call");

                tmpioreq = tmpioreq->next;
            }
            if (!(currdiskreq->flags & COMPLETION_SENT)
                    && (seg->outstate == BUFFER_IDLE))
            {
                disk_check_bus(currdisk, currdiskreq);
            }
        }
        seg->access->type = NULL_EVENT;
        disk_release_hda(currdisk, currdiskreq);

        // @10
        currdisk->stat.seekdistance = -1;
        currdisk->stat.xfertime     = (double) 0.0;
        currdisk->stat.latency      = (double) 0.0;

    }
#ifdef __IMMED_OPT__
    if((currdisk->nBlkAccessCnt >= (currdisk->stRegLastEvent.bcount -1))  // @10.1
    		&& currdisk->immed == 1)
    {
    	reqdone = TRUE;
    } // @10.1
#endif
    if (reqdone)
    {
        //    printf("disk_buffer_request_complete %f\n", simtime);
    }

    return (reqdone);
}

static void
disk_buffer_seekdone(disk *currdisk, ioreq_event *curr)
{
    int trackstart;
    int immed;
    diskreq *currdiskreq = currdisk->effectivehda;
    segment *seg;
    double mydiff;
    struct dm_pbn pbn;

#ifdef DEBUG_DISKCTLR
    fprintf (outputfile, "%f: [%s] - Entering type %d, cause %d, devno %d, blkno %ld, bcount %d\n", simtime, __func__, curr->type, curr->cause, curr->devno, curr->blkno, curr->bcount );
#endif

    // first and last blocks on current track
    LBA_TYPE first, last; // @9

    int remapsector = 0;

    seg = currdiskreq->seg;

    dbskdone_check_times();
    // state-update stolen from above
    currdisk->model->layout->dm_translate_ltop(currdisk->model,
            curr->blkno,
            MAP_FULL,
            &pbn,
            0);
    currdisk->mech_state.cyl = pbn.cyl;
    currdisk->mech_state.head = pbn.head;

    curr->time = simtime;

    if(seg->outstate == BUFFER_PREEMPT) {
        curr->type = NULL_EVENT;
        disk_release_hda(currdisk,currdiskreq);
        return;
    }

    if(currdisk->stat.xfertime == (double) -1) {
        currdisk->stat.latency = simtime;
    }

    immed = currdisk->immed;

    {
        struct dm_pbn pbn;
        dm_ptol_result_t rv;

        currdisk->model->layout->dm_translate_ltop(currdisk->model,
                curr->blkno,
                MAP_FULL,
                &pbn,
                NULL);

        rv = currdisk->model->layout->
                dm_get_track_boundaries(currdisk->model,
                        &pbn,
                        &first,
                        &last,
                        &remapsector);
        ddbg_assert(rv == DM_OK);

        currdisk->track_low = first;    // first LBN on track
        currdisk->track_high = last;    // last LBN on track

        curr->bcount = last - first + 1;
        last++;  // the controller code works in terms of 1-past-the-end

        ddbg_assert3(((first <= curr->blkno) && (curr->blkno <= last )),
                ("Mapping problem, block (%d) not within track (%d, %d)",
                        curr->blkno,
                        first,
                        last));
    }

#ifdef DEBUG_DISKCTLR
    //  fprintf (outputfile, "********** %f: [%s] - remapsector %d, endoftrack %d, firstontrack %d, bcount %d\n", simtime, __func__, remapsector, last, first, curr->bcount );
#endif

    /* If the head landed just start reading, even if the block we want
     * isn't under the head yet.  -rcohen */
    if((currdisk->readanyfreeblocks)
            && (curr->flags & READ)
            && (curr->blkno != first))
    {
        curr->blkno = first;
        immed = TRUE;
    }

    seg->time = simtime;
    {
        int sectors;
        uint64_t nsecs;
        double latency;
        struct dm_pbn tmp;

        // watch carefully: to match the screwy way we did this with
        // global_currangle/global_currtime/foo before, we're going to
        // set the angle of the state we pass in to be (simtime % period)

        dm_time_t isimtime = dm_time_dtoi(seg->time) - currdisk->currtime_i;
        dm_time_t residtime =
                isimtime % currdisk->model->mech->dm_period(currdisk->model);

        struct dm_mech_state startstate = currdisk->mech_state;
        startstate.theta += currdisk->model->mech->dm_rotate(currdisk->model, &residtime);
        nsecs = currdisk->model->mech->dm_latency(currdisk->model,
                &startstate,
                curr->cause,
                curr->bcount,
                immed,
                0);
        latency = dm_time_itod(nsecs);

        //    printf("%s(): latency %f\n", __func__, latency);

        trackstart =
                currdisk->model->mech->dm_access_block(currdisk->model,
                        &startstate,
                        curr->cause,
                        curr->bcount,
                        immed);

        tmp.cyl = startstate.cyl;
        tmp.head = startstate.head;
        tmp.sector = 0; // XXX g4 layout cares
        sectors = currdisk->model->layout->dm_get_sectors_pbn(currdisk->model, &tmp);

        //    printf("*** DEBUG disk_buffer_seekdone : simtime = %f, trackstart = %d\n",
        //	   simtime, trackstart);

        curr->time = seg->time + latency;   // latency added to the simtime here to generate next event
    }

    currdisk->immedstart = last;
    currdisk->immedend = currdisk->immedstart;

    // used to have curr->blkno = first + trackstart here
    // At the very minimum, slips will screw this up.
    {
        struct dm_pbn tmppbn =
        {
                currdisk->mech_state.cyl,
                currdisk->mech_state.head,
                trackstart
        };

        // hurst_r the following code is a type error
        curr->blkno = currdisk->model->layout->dm_translate_ptol(currdisk->model, &tmppbn, 0);
        ddbg_assert(curr->blkno >= 0);
    }

    ddbg_assert3((currdisk->track_low <= curr->blkno && curr->blkno <= currdisk->track_high),
           ("track_low %15.0f, curr->blkno:%15.0f, track_high:%15.0f",
            (double)currdisk->track_low, (double)curr->blkno, (double)currdisk->track_high)
           );


    /* NOTE: trackstart != current pbn in track, think of zero latency
     * and early-start reads
     */
    curr->cause = trackstart;
    curr->type = DEVICE_BUFFER_SECTOR_DONE;
    curr->bcount = 0;
    addtointq((event *) curr);

#ifdef DEBUG_DISKCTLR
    //  fprintf (outputfile, "********** %f: [%s] - startblkno %ld, endblkno %ld, outblkno %ld, reqstart %d, reqend %d\n",
    //       seg->startblkno,
    //       seg->endblkno,
    //       currdiskreq->outblkno,
    //       seg->diskreqlist->blkno,
    //       (seg->reqlist->blkno + seg->reqlist->bcount));

    //  fprintf (outputfile, "********** %f: [%s] - startblkno %ld, endblkno %ld, outblkno %ld\n",
    //       simtime,
    //       __func__,
    //       seg->startblkno,
    //       seg->endblkno,
    //       currdiskreq->outblkno );

    //  fprintf (outputfile, "********** %f: [%s] - leaving\n", simtime, __func__ );
    //  fflush( outputfile );
#endif
}

static int iFlag_init_zone_meta_data = 0;  // @019
int
disk_initiate_seek (
        disk *currdisk,
        segment *seg,
        ioreq_event *curr,
        int firstseek,
        double delay,
        double mintime)
{
    struct dm_pbn destpbn;
    double seektime;
    int seekdist;
    int remapsector = 0;


#ifdef DEBUG_DISKCTLR
    fprintf (outputfile, "\n%f: disk_initiate_seek to devno %d, blkno %ld, bcount %d, flags %x\n", simtime, curr->devno, curr->blkno, curr->bcount, curr->flags);
    dump_disk_buffer_seqment ( outputfile, seg, -1 );
    fprintf (outputfile, "\n" );
    fflush(outputfile);
#endif

    double metmp;
    double rotationTimeMsec = (double)currdisk->model->mech->dm_period(currdisk->model)/1000000000.0;
    double realAngle = modf(simtime/rotationTimeMsec, &metmp) * 360.0;
    struct dm_mech_acctimes mech_acctimes;

    curr->type = NULL_EVENT;
    seg->time = simtime + delay;
    //  remapsector = FALSE;

    // @019
    struct dm_layout_zone stNew_zone_meta_data;
    int nNew_zone;
	LBA_TYPE nPrev_lba;
	struct dm_pbn stPrev_pbn, stNew_zone_start_pbn;
    OUTPUT_HDD_CALCULATE_ACCESS_TIME stOutput_calc_HDD;
    static int nPrevTagId;

	//stNew_zone_meta_data
    nNew_zone = currdisk->model->layout->dm_get_zone_meta_data_by_lbn(currdisk->model, curr->blkno,
					&stNew_zone_meta_data);

    SIM_RESULT_SMR_WRRO stSMR_wrro_calc;
    if(currdisk->model->cFlag_is_smr == 1)
    {
		if(iFlag_init_zone_meta_data == 0)
		{
			iFlag_init_zone_meta_data = 1;
			stPrev_pbn.cyl = currdisk->mech_state.cyl;
			stPrev_pbn.head = currdisk->mech_state.head;
			stPrev_pbn.sector = 0;
			nPrev_lba = currdisk->model->layout->dm_translate_ptol(currdisk->model, &stPrev_pbn, 0);

			currdisk->nCurrent_zone_id =
					currdisk->model->layout->dm_get_zone_meta_data_by_lbn(currdisk->model, nPrev_lba,
					&currdisk->stCurr_zone_meta_data);
		}

		INPUT_HDD_CALCULATE_ACCESS_TIME stInput_calc_HDD;

		if(nPrevTagId != curr->tagID)
		{
		    currdisk->tUpdate_smr_wrro_ms = 0;
		    stSMR_wrro_calc.iFlag_smr_write_update_wrro = 0;
		    stSMR_wrro_calc.tUpdate_smr_wrro_ms = 0;
		    stSMR_wrro_calc.nZone_id = nNew_zone;

			if((nNew_zone != currdisk->nCurrent_zone_id) &&
					((curr->flags & READ) != READ)	)
			{
				currdisk->iFlag_smr_write_needs_update_wrro = 1;
				currdisk->stCurr_zone_meta_data = stNew_zone_meta_data;
				currdisk->nCurrent_zone_id = nNew_zone;
			}
			else
			{
				currdisk->iFlag_smr_write_needs_update_wrro = 0;
			}


			if(currdisk->iFlag_smr_write_needs_update_wrro == 1)
			{
				stPrev_pbn.cyl = currdisk->mech_state.cyl;
				stPrev_pbn.head = currdisk->mech_state.head;
				stPrev_pbn.sector = 0;
				stInput_calc_HDD.nStartLBA =
						currdisk->model->layout->dm_translate_ptol(currdisk->model, &stPrev_pbn, 0);

				stNew_zone_start_pbn.cyl = stNew_zone_meta_data.cyl_low;
				stNew_zone_start_pbn.head = currdisk->mech_state.head;
				stNew_zone_start_pbn.sector = 0;
				stInput_calc_HDD.nTargetLBA =
						currdisk->model->layout->dm_translate_ptol(currdisk->model, &stPrev_pbn, 0);
				stInput_calc_HDD.nLen = (int)(stNew_zone_meta_data.nNum_sectors_WRRO);
				stInput_calc_HDD.nFlag = READ;

				hdd_model_calculate_access_time(currdisk->model, &stInput_calc_HDD,
						&stOutput_calc_HDD);
				stSMR_wrro_calc.iFlag_smr_write_update_wrro = 1;
				stSMR_wrro_calc.tUpdate_smr_wrro_ms = stOutput_calc_HDD.tAccessTime_ms;
				stSMR_wrro_calc.nNumber_sectors_WRRO = stNew_zone_meta_data.nNum_sectors_WRRO;
				currdisk->tUpdate_smr_wrro_ms = stOutput_calc_HDD.tAccessTime_ms;

			}
		}
		else
		{

		}
    }
    else
    {
    	currdisk->iFlag_smr_write_needs_update_wrro = 0;
    }
    if(nPrevTagId != curr->tagID)
    {
    	nPrevTagId = curr->tagID;
    	simresult_update_smr_wrro_access(curr->tagID, &stSMR_wrro_calc);  // @019
    }
//    	currdisk->nCurrent_zone_id = nCurr_zone;

    // new ltop
    {
        int rv;
        uint64_t nsecs;
        struct dm_mech_state end;
        struct dm_mech_state begin = currdisk->mech_state;

        rv = currdisk->model->layout->dm_translate_ltop(
                currdisk->model,
                curr->blkno,
                MAP_FULL,
                &destpbn,
                &remapsector);
        ddbg_assert(rv == DM_OK);

        simresult_update_mechanicalstate( curr->tagID, begin, realAngle, destpbn);
        disk_calc_rpo_time( currdisk, curr, &mech_acctimes );
        simresult_update_mech_acctimes( curr->tagID, &mech_acctimes );

        if(curr->blkno == 784805368) // 1096530432// 1159721576 // @10, 1141628888  // 1123995024
        {
        	fprintf(stderr, "simtime:%f, Start access %d, %d\n", simtime, curr->blkno, curr->bcount);
        }

        seekdist = abs(currdisk->mech_state.cyl - destpbn.cyl);
        end.cyl = destpbn.cyl;
        end.head = destpbn.head;
        end.theta = 0;

        curr->cause = destpbn.sector;

        // new acctime
        //  seektime = diskacctime(currdisk, curr->tempptr1, DISKSEEKTIME,
        //		 (curr->flags & READ), seg->time, global_currcylno,
        //		 global_currsurface, curr->cause, curr->bcount, 0);


        nsecs = currdisk->model->mech->dm_seek_time(
                currdisk->model,
                &begin,
                &end,
                (curr->flags & READ));
        seektime = dm_time_itod(nsecs);

#ifdef __DISK_POWER__
        // @012
        double fVCMSeekEnergy =
        		currdisk->model->stpPowerHDD->dm_vcm_seek_energy(currdisk->model,
        		&begin, &end, (curr->flags & READ));

        stat_update (&(currdisk->stat.stVCM_SeekEnergyStats), 0.001 * fVCMSeekEnergy * seektime);  // @012

        double fSpindlePowerPrevZone;
        double fVCM_BiasPowerPrevZone;
        fSpindlePowerPrevZone =
        		currdisk->model->stpPowerHDD->dm_spindle_power(currdisk->model, currdisk->nRegLastZone);
        // The time's unit is 1ms, so it needs a factor of 0.001
        stat_update(&(currdisk->stat.stSpindleEnergyStats),
        		0.001 * fSpindlePowerPrevZone * (simtime + seektime - currdisk->tRegEndSeekTime) );

        fVCM_BiasPowerPrevZone =
        		currdisk->model->stpPowerHDD->dm_vcm_bias_power(currdisk->model, currdisk->nRegLastZone);
        stat_update(&(currdisk->stat.stVCM_BiasEnergyStats),
        		0.001 * fVCM_BiasPowerPrevZone * (simtime + seektime - currdisk->tRegEndSeekTime) );

        int nTargetZone;
        nTargetZone = currdisk->model->layout->dm_get_zone_id_by_lbn(currdisk->model,curr->blkno);
        currdisk->nRegLastZone = nTargetZone;

        currdisk->tRegStartSeekTime = simtime;
        currdisk->tRegEndSeekTime = simtime + seektime; // @012
#endif // @012
    }

#ifdef DEBUG_DISKCTLR
    fprintf (outputfile, "%f: disk_initiate_seek  devno %d, blkno %ld, bcount %d, flags %x, currCyl %d, currHead %d, currAngle %u, destCyl %d, destHead %d, destSector %d, distance %d, seektime %f\n", simtime, curr->devno, curr->blkno, curr->bcount, curr->flags, currdisk->mech_state.cyl, currdisk->mech_state.head, currdisk->mech_state.theta, destpbn.cyl, destpbn.head, destpbn.sector, seekdist, seektime );
    fflush(outputfile);
#endif

#ifdef DISKLOG_ON
    if( NULL != DISKSIM_DISK_LOG )
    {
        fprintf( DISKSIM_DISK_LOG, "\n%f %d %d %d %d (%x)   currCyl %d, currHead %d, currAngle %u, rotationTimeMSec %f, realAngle %f, destCyl %d, destHead %d, destSector %d, seekdist %d, seektime %f",
                                simtime, curr->devno, curr->blkno, curr->bcount, curr->flags, curr->flags,
                                currdisk->mech_state.cyl, currdisk->mech_state.head, currdisk->mech_state.theta, rotationTimeMsec, realAngle, destpbn.cyl, destpbn.head, destpbn.sector, seekdist, seektime  );
        fflush( DISKSIM_DISK_LOG );
    }
#endif

    if(seektime < mintime) {
        seg->time += mintime - seektime;
    }

    if(currdisk->iEndOfCurrentTrackFlagSeekToNextTrack == 0)  // @10
    {
    	currdisk->stRegLastEvent = *curr;  // @10
    	currdisk->stRegLastEvent.bcount = curr->bcount;
    	currdisk->nBlkAccessCnt = 0;  // @10.1
    } // @10

    curr->time = seg->time + seektime;
    if((curr->flags & BUFFER_BACKGROUND)
            && (curr->flags & READ))
    {
        if((currdisk->contread == BUFFER_READ_UNTIL_CYL_END)
                && (seekdist != 0))
        {
            return FALSE;
        }

        if((currdisk->contread == BUFFER_READ_UNTIL_TRACK_END)
                && ((seekdist != 0) |
                        (currdisk->mech_state.head != destpbn.head)))
        {
            return FALSE;
        }
    }

    if(firstseek) {
        currdisk->stat.seekdistance = seekdist;
        currdisk->stat.seektime = seektime;
        currdisk->stat.latency = (double) -1.0;
        currdisk->stat.xfertime = (double) -1.0;
    }
    else if(remapsector == 0) {
        // currdisk->stat.xfertime  += seektime; // @10
        // fprintf(stderr, "# simtime: %f, %d, %s, xfertime:%f, seektime:%f\n", simtime, __LINE__, __func__, currdisk->stat.xfertime, seektime);  // @10
    }
    curr->type = DEVICE_BUFFER_SEEKDONE;
    if(remapsector != 0) {
        disk_get_remapped_sector(currdisk, curr);
    }
    addtointq((event *) curr);

#if 0
    if( NULL != DISKSIM_DISK_LOG )
    {
        fprintf (DISKSIM_DISK_LOG, ", latency %f, xfertime %f\n", currdisk->stat.latency, currdisk->stat.xfertime );
        fflush( DISKSIM_DISK_LOG );
    }
#endif

#ifdef DEBUG_DISKCTLR
    fprintf (outputfile, "%f: disk_initiate_seek  Stats seekdistance %d, seektime %f, latency %f, xfertime %f\n", simtime, currdisk->stat.seekdistance, currdisk->stat.seektime, currdisk->stat.latency, currdisk->stat.xfertime );
    fflush(outputfile);
#endif

    return TRUE;
} // disk_initiate_seek()

static void
disk_buffer_sector_done (disk *currdisk, ioreq_event *curr)
{
    segment *seg;
    diskreq *currdiskreq = currdisk->effectivehda;
    ioreq_event *tmpioreq;

    LBA_TYPE first, last;    // first/last lbn on track // @9
    LBA_TYPE next; // first lbn on next track
    LBA_TYPE firstblkno;
    LBA_TYPE lastblkno; //@9
    int endlat = 0;

    // As far as I can tell, these are set up to be the lbn and sector
    // prior (rotationally, on the track) to curr->blkno and curr->cause.
    LBA_TYPE currblkno = -1;  // @9
    LBA_TYPE currcause = -1;  // @9

    dm_time_t diff_i;
    double mydiff;
    int remapsector = 0;

    int rv;
    struct dm_pbn pbn;

#ifdef DEBUG_DISKCTLR
    fprintf (outputfile, "%f: disk_buffer_sector_done - Entering  type %d, cause %d, devno %d, blkno %ld, bcount %d\n", simtime, curr->type, curr->cause, curr->devno, curr->blkno, curr->bcount );
    fflush( outputfile );
#endif

    //  currdisk->fpcheck--;
    //  ddbg_assert(currdisk->fpcheck); // see the comment in the header

    //  printf("%s %d %d\n", __func__, curr->blkno, curr->cause);

    ddbg_assert2(currdiskreq != 0, "No effectivehda");

    seg = currdiskreq->seg;

    dbsd_setup(currdisk, curr,
            &currblkno, &currcause,
            &first, &last, &next,
            &remapsector);

    //   printf("%s():%d curr->blkno %ld\n", __func__, __LINE__, curr->blkno);
    //   printf("%s():%d curr->cause %d\n", __func__, __LINE__, curr->cause);
    //   printf("%s():%d currblkno %ld\n", __func__, __LINE__, currblkno);
    //   printf("%s():%d currcause %d\n", __func__, __LINE__, currcause);
    //   printf("%s():%d first %d\n", __func__, __LINE__, first);
    //   printf("%s():%d last %d\n", __func__, __LINE__, next);


    if(remapsector | (currblkno < 0)) {
        /* previous pbn is slipped or relocated */
        currblkno = -1;
        if(curr->bcount) {
            curr->bcount = 2;
        }
    }


    if(!curr->bcount) { // first sector after repos (? see comment below)
        curr->time = simtime;

        diff_i = (dm_time_dtoi(seg->time) - currdisk->currtime_i) % currdisk->model->mech->dm_period(currdisk->model);
        currdisk->mech_state.theta += currdisk->model->mech->dm_rotate(currdisk->model, &diff_i);
    }


    // update the rotational state of the disk
    diff_i = dm_time_dtoi(simtime - seg->time);
    currdisk->mech_state.theta += currdisk->model->mech->dm_rotate(currdisk->model, &diff_i );

    // for bcount == 0, used to dbsd_check_times() here

    currdisk->currtime = simtime;
    currdisk->currtime_i = dm_time_dtoi(simtime);


    if(!currdisk->read_direct_to_buffer
            && (curr->flags & READ)
            && (curr->bcount == 1)
            && !(disk_buffer_block_available(currdisk, seg, currblkno)))
    {
        curr->bcount = 2;
    }


    /* OK, here comes the weird stuff. bcount doesn't mean what you think.
     * Ganger has seen fit to overload its meaning. bcount may equal 0, 1
     * or 2.
     * 0 = first block read/written after a seek?
     * 1 = middle of reading/writing?
     * 2 = previous sector is remapped or slipped?
     * 2 = writing - searching for first block
     * If you are able to confirm or deny, please fix comments.
     */
    if(seg->recyclereq == currdiskreq) {
        curr->bcount = 2;
        firstblkno = currdiskreq->inblkno;
        tmpioreq = currdiskreq->ioreqlist;
        while (tmpioreq->next) {
            tmpioreq = tmpioreq->next;
        }
        lastblkno = min((tmpioreq->blkno + tmpioreq->bcount), next);
    }
    else if(seg->state == BUFFER_READING) {
        firstblkno = seg->endblkno;
        if(curr->flags & BUFFER_BACKGROUND) {
            lastblkno = min(seg->maxreadaheadblkno, next);
        }
        else {
            tmpioreq = currdiskreq->ioreqlist;
            while (tmpioreq->next) {
                tmpioreq = tmpioreq->next;
            }
            lastblkno = min((tmpioreq->blkno + tmpioreq->bcount), next);
        }
    }
    else {
        firstblkno = currdiskreq->inblkno;
        lastblkno = min(seg->endblkno, next);
    }

    if(currdisk->stat.xfertime == -1.0) {
        endlat++;
    }


    ddbg_assert((0 <= curr->bcount) && (curr->bcount <= 2));

    // It seems like we "dry-fire" d_b_s_d() for slips -- we simulate
    // the rotation of a sector but don't do any of the following code
    // which simulates the media xfer.
    if(curr->bcount == 1) {
        if(currblkno == firstblkno) {
            /* Oh look, we read a wanted block */

            // oops ... what if firstblkno is the last block on the disk! bucy 2001

            // ewww ... this assertion fails in disksim-2 ... so reading the
            // last+1 sector must mean something special to the rest of the
            // controller code

            firstblkno++;
            ddbg_assert(firstblkno < (currdisk->model->dm_sectors+1));
            if(firstblkno == currdisk->immedstart) {
                firstblkno = currdisk->immedend;

                currdisk->immedstart = next + 1;
                currdisk->immedend = currdisk->immedstart;
            }
            endlat++;
        }
        else if(currblkno < seg->startblkno) {
            /* We've started reading (NOT writing) before the
             * starting block. Must be buffering
             */
            ddbg_assert3(((seg->state == BUFFER_READING)
                    && currdisk->readanyfreeblocks),
                    ("seg->state 0x%x, readanyfreeblocks %d",
                            seg->state,
                            currdisk->readanyfreeblocks));

            seg->startblkno = currblkno;
            firstblkno = currblkno + 1;
            ddbg_assert(firstblkno < currdisk->model->dm_sectors);
        }
        else if((currdisk->immed)
                && (currdisk->immedstart >= next))
        {
            /* zero latency, still figuring this one out  // @011 */
            if(currblkno >= lastblkno) {
                if((seg->state == BUFFER_READING)
                        && (currdisk->contread != BUFFER_NO_READ_AHEAD)
                        && (currblkno < currdiskreq->inblkno))
                {
                    currdisk->immedstart = currblkno;
                    currdisk->immedend = currblkno + 1;
                }
            }
            else if(currblkno > firstblkno) {
                currdisk->immedstart = currblkno;
                currdisk->immedend = currblkno + 1;
                endlat++;
            }
        }
        else if((currblkno == currdisk->immedend)
                && ((currblkno < lastblkno)
                        || (currblkno < currdiskreq->inblkno)))
        {
            currdisk->immedend++;
            disk_buffer_segment_wrap(seg, currdisk->immedend);
        }
        else if((currblkno > currdisk->immedend) && (currblkno < lastblkno)) {
            currdisk->immedstart = currblkno;
            currdisk->immedend = currblkno + 1;
        }
    } // if(curr->bcount == 1)

    /* This may have to do with trackacc, in which case it will be removed */
    if((currdiskreq != seg->recyclereq) &&
            (seg->outstate == BUFFER_TRANSFERING)) {
        disk_buffer_update_outbuffer(currdisk, seg);
    }


    /* Statistics gathering */
#ifdef DEBUG_DISKCTLR
    fprintf (outputfile, "********** %f: disk_buffer_sector_done before - seg->time %f, seekdistance %d, seektime %f, latency %f, xfertime %f\n",
            simtime,
            seg->time,
            currdisk->stat.seekdistance,
            currdisk->stat.seektime,
            currdisk->stat.latency,
            currdisk->stat.xfertime );
    fflush( outputfile );
#endif

    if(endlat == 2) {
        currdisk->stat.latency = seg->time - currdisk->stat.latency;
        currdisk->stat.xfertime = (double) 0.0;
#ifdef DISKLOG_ON
    // this conditional concatenates it's output with the conditional in disk_initiate_seek
        if( NULL != DISKSIM_DISK_LOG )
        {
            fprintf (DISKSIM_DISK_LOG, ", latency %f, xfertime %f  SEEK\n",
                    currdisk->stat.latency,
                    currdisk->stat.xfertime );
            fflush( DISKSIM_DISK_LOG );
        }
#endif

#ifdef DEBUG_DISKCTLR
    fprintf (outputfile, "%f: disk_buffer_sector_done after - endlat==2  seg %p, seg->time %f, seekdistance %d, seektime %f, latency %f, xfertime %f\n",
            simtime,
            seg,
            seg->time,
            currdisk->stat.seekdistance,
            currdisk->stat.seektime,
            currdisk->stat.latency,
            currdisk->stat.xfertime );
    fflush( outputfile );
#endif
    }

    if(currdisk->stat.xfertime != (double) -1) {
    	if((curr->blkno - currdisk->stRegLastEvent.blkno) < currdisk->stRegLastEvent.bcount &&
				(curr->blkno - currdisk->stRegLastEvent.blkno) >= 0	) // @10
    	{
    		if(currdisk->iEndOfCurrentTrackFlagSeekToNextTrack == 0 )
    		{
    			if(curr->bcount == 1) // @10, diskbuffer may read/write additional 2nd chance when bcount == 2,
    			{
    				currdisk->stat.xfertime += simtime - seg->time;
    				currdisk->nBlkAccessCnt ++; // @10.1
    			}
    		}
    	    else // Reset the flag
    	    {
    	    	currdisk->iEndOfCurrentTrackFlagSeekToNextTrack = 0;
    	    }  // @10

    	}
#ifdef DEBUG_IBRW
    double rotatetime =
            dm_time_itod(currdisk->model->mech->dm_period(currdisk->model));

/*    &&		((curr->blkno - stRegLastEvent.blkno) > stRegLastEvent.bcount ||
            				(curr->blkno - stRegLastEvent.blkno) < 0	) */
        if(currdisk->stat.xfertime > rotatetime - 3.0 )
        {
             fprintf(outputfile, "#simtime:%f, %d, %s, xfertime:%f:%f,+= %f, blk:%ld,cnt:%d, Exp:blk:%ld, bcount:%d\n", simtime,
                      __LINE__, __func__, currdisk->stat.xfertime, seg->time, (simtime - seg->time),
                      curr->blkno, curr->bcount, stRegLastEvent.blkno, stRegLastEvent.bcount);  // @10  ((ioreq_event *)currdiskreq)
        }
#endif // DEBUG_DISKCTLR_LARGE_TRANSFER_TIME

#ifdef DEBUG_DISKCTLR
    fprintf (outputfile, "********** %f: disk_buffer_sector_done after - xfertime!=-1.0  seg->time %f, seekdistance %d, seektime %f, latency %f, xfertime %f\n",
            simtime,
            seg->time,
            currdisk->stat.seekdistance,
            currdisk->stat.seektime,
            currdisk->stat.latency,
            currdisk->stat.xfertime );
    fflush( outputfile );
#endif
    }

#ifdef DEBUG_DISKCTLR
    fprintf (outputfile, "********** %f: disk_buffer_sector_done after - seg->time %f, seekdistance %d, seektime %f, latency %f, xfertime %f\n",
            simtime,
            seg->time,
            currdisk->stat.seekdistance,
            currdisk->stat.seektime,
            currdisk->stat.latency,
            currdisk->stat.xfertime );
    fflush( outputfile );
#endif

    if(currdiskreq != seg->recyclereq) {
        if(seg->state == BUFFER_READING) {
            seg->endblkno = firstblkno;
        }
        else {
            currdiskreq->inblkno = firstblkno;
        }

        disk_buffer_segment_wrap(seg, seg->endblkno);

#ifdef DEBUG_IBRW
        if((curr->blkno - currdisk->stRegLastEvent.blkno) == currdisk->stRegLastEvent.bcount)
        {
        	fprintf(outputfile, "simtime:%f, check r/w end: blkno:%d, bcount:%d, expect<start, total>: <%d, %d>\n",
        			simtime, curr->blkno, curr->bcount, stRegLastEvent.blkno, stRegLastEvent.bcount);
        }
#endif
        if(disk_buffer_request_complete(currdisk, currdiskreq)) {
            /* fprintf (outputfile, "Leaving disk_buffer_sector_done\n"); */
#ifdef DEBUG_IBRW
    double rotatetime =
            dm_time_itod(currdisk->model->mech->dm_period(currdisk->model));
        if((currdisk->stat.xfertime > rotatetime - 3.0) && (currdisk->stat.xfertime <= rotatetime))
        {
                fprintf (outputfile, "\n********** %f: disk_buffer_sector_done ACCTIMESTATS: outwait:%d,distance %d, seektime %f, latency %f, xfertime %f, blk:%d, count:%d",
                        simtime,
                        currdisk->outwait,
                        currdisk->stat.seekdistance,
                        currdisk->stat.seektime,
                        currdisk->stat.latency,
                        currdisk->stat.xfertime,
                        ((ioreq_event *)currdiskreq)->blkno,
                        ((ioreq_event *)currdiskreq)->bcount); // @10
        }
#endif
            return;
        }
    }


    // In the case of immediate-access, firstblkno gets fiddled above.

    // The request still isn't done.  We're either done with this
    // track in which case we'll reposition to the next
    // or we'll rotate and do another sector.
    if(firstblkno >= next) {
        // We reached the end of the track, seek to the next.

    	currdisk->iEndOfCurrentTrackFlagSeekToNextTrack = 1;
        curr->blkno = next;
        if(!(disk_initiate_seek(currdisk, seg, curr, 0, 0.0, 0.0))) {
            disk_release_hda(currdisk,currdiskreq);
            return;
        }
    }
    // is it firstblkno > last ok?
    else {
        // Here, we need to set up curr->blkno and curr->cause to reflect
        // moving forward one sector (rotationally, on this track).

        // old way:
        // 1. subtract current sector number (curr->cause) out of current
        // lbn
        // 2. increment current sector number modulo the track length
        // 3. add the sector number back into the lbn


        if(curr->blkno < last) {
            curr->blkno++;
        }
        else {
            curr->blkno = first;
        }

        //    ddbg_assert(curr->blkno != 54281913);
        ddbg_assert(curr->blkno <= currdisk->track_high);

        rv =
                currdisk->model->layout->dm_translate_ltop(currdisk->model,
                        curr->blkno,
                        MAP_FULL,
                        &pbn,
                        &remapsector);
        // save this here
        currcause = curr->cause;
        curr->cause = pbn.sector;

        //    printf("%s():%d curr->blkno %ld\n", __func__, __LINE__, curr->blkno);
        //        printf("%s():%d curr->cause %d\n", __func__, __LINE__, curr->cause);

        /* NOTE: curr->blkno may be < start_of_track
         * ie if there is a slipped blk in the track and sectpercylspare.  I
         * think this is messy and end_of_track should specify the # of
         * the last track so we don't have to do this.  -rcohen */
        /* end of bad assumption code */

        seg->time = simtime;

        curr->time = seg->time + dm_time_itod(currdisk->model->mech->dm_xfertime(currdisk->model, &currdisk->mech_state, 1));


        // this seems like a type error; currcause was a sector number, now its
        // an lbn.
        {
            LBA_TYPE newcurrcause; // @9
            struct dm_pbn pbn;
            pbn.cyl = currdisk->mech_state.cyl;
            pbn.head = currdisk->mech_state.head;
            pbn.sector = currcause;

            newcurrcause = currdisk->model->layout->dm_translate_ptol(
                    currdisk->model,
                    &pbn,
                    &remapsector);

            currcause = newcurrcause; // currcause becomes an LBN here
        }

        if(remapsector) {
            currcause = DM_SLIPPED; // DM_SLIPPED
        }

        if((currdiskreq != seg->recyclereq)
                && (currcause == -2) // DM_REMAPPED
                && (seg->state == BUFFER_READING)
                && (currdiskreq->ioreqlist)
                && (currdisk->readanyfreeblocks)
                && (currblkno >= 0)
                && (currblkno == (seg->endblkno-1))
                && (seg->endblkno < currdiskreq->ioreqlist->blkno)
                && (curr->cause > 0))
        {
            seg->startblkno = currdiskreq->ioreqlist->blkno;
            seg->endblkno = seg->startblkno;
            currcause = DM_SLIPPED; // DM_SLIPPED
        }

        if((currcause == DM_REMAPPED)  // DM_REMAPPED
                && (currblkno >= 0)
                && (currblkno == (firstblkno-1)))
        {
            curr->blkno--;

            if(curr->cause == 0) {
                curr->blkno = next;
            }

            disk_get_remapped_sector(currdisk, curr);
        }
        else {
            curr->bcount = 1;
            if(((currdisk->read_direct_to_buffer
                    || !(curr->flags & READ))
                    && ((currdiskreq == seg->recyclereq)
                            || !(disk_buffer_block_available(currdisk, seg, currcause))))
                    || (currcause < 0))
            {
                curr->bcount = 2;
            }
        }

        addtointq((event *) curr);

    } // else  ( firstblkno != (<) last)


} // disk_buffer_sector_done()

/*** FUNCTIONS FOR USE BY QUEUING ALGORITHMS  -rcohen ***/
/* Possible improvements:  rundelay is not used currently */
/* NOTE: this is used for calculating actual access times -rcohen */
static double
disk_buffer_estimate_servtime(disk *currdisk,
        ioreq_event *curr,
        int checkcache,
        double maxtime)
{
    struct dm_pbn destpbn;
    struct dm_mech_acctimes mech_acctimes;
    double tmptime;
    int tmpblkno;
    LBA_TYPE lastontrack;
    int hittype = BUFFER_NOMATCH;

#ifdef DEBUG_DISKCTLR
    fprintf (outputfile, "********** %f: disk_buffer_estimate_servtime\n", simtime );
    fflush(outputfile);
#endif

    if(currdisk->const_acctime) {
        // SIMPLEDISK device path
        return(currdisk->acctime);
    }

    // DISK device path
    if(checkcache) {
        int buffer_reading = FALSE;

        hittype = disk_buffer_check_segments(currdisk,curr,&buffer_reading);
        if(hittype == BUFFER_APPEND) {
            return 0.0;
        }
        else if(hittype == BUFFER_WHOLE) {
            return(buffer_reading ? READING_BUFFER_WHOLE_SERVTIME : BUFFER_WHOLE_SERVTIME);
        }
        else if(hittype == BUFFER_PARTIAL) {
            return(buffer_reading ? READING_BUFFER_PARTIAL_SERVTIME : BUFFER_PARTIAL_SERVTIME);
        }
    }

    tmpblkno = curr->bcount;  // TODO hurst_r need to investigate this...save/restore bcount??
    tmptime = curr->time;


    {
        uint64_t nsecs;
        struct dm_mech_state end;
        //curr->tempptr1 =
        currdisk->model->layout->dm_translate_ltop(currdisk->model,
                curr->blkno,
                MAP_FULL,
                &destpbn,
                0);
        end.cyl = destpbn.cyl;
        end.head = destpbn.head;
        end.theta = 0;
        curr->cause = destpbn.sector;

        // was diskacctime(DISKSEEKTIME)
        nsecs =
                currdisk->model->mech->dm_seek_time(currdisk->model,
                        &currdisk->mech_state,
                        &end,
                        (curr->flags & READ));

        curr->time = dm_time_itod(nsecs);
    }

    if (curr->time < maxtime) {
        curr->time = tmptime;

        currdisk->model->layout->dm_get_track_boundaries(currdisk->model, &destpbn, 0, &lastontrack, 0);
        // track_boundaries new semantics
        lastontrack++;

        curr->bcount = min((LBA_TYPE)curr->bcount, (lastontrack - curr->blkno)); // @9

        {
            dm_time_t nsecs;
            struct dm_pbn pbn;
            currdisk->model->layout->dm_translate_ltop(currdisk->model,
                    curr->blkno, MAP_FULL, &pbn, 0);
            curr->cause = pbn.sector;

            if (curr->flags & READ) {
                currdisk->immed = currdisk->immedread;   // 0; // @011  //
            } else {
                currdisk->immed = currdisk->immedwrite; // 0; // @011
            }

            // It was decided that "servtime" was extremely confusing so we
            // are now referring to it as "non-xfer" time.  it consists of
            // all of the time taken to service the request excluding the
            // actual data transfer, i.e. additional intermediate rotational
            // latency in a zero-latency access, etc.  bucy 5/20/2002.

            // having said all that, it isn't obvious to me that non-xfer
            // time is wanted instead of access time here...

            /* tmptime = diskacctime(currdisk, */
            /*                       curr->tempptr1, */
            /*                       DISKSERVTIME, */
            /*                       (curr->flags & READ), */
            /*                       curr->time, */
            /*                       global_currcylno, */
            /*                       global_currsurface, */
            /*                       curr->cause, */
            /*                       curr->bcount, */
            /*                       currdisk->immed); */

            // dm doesn't provide a direct interface to non-xfer time; we
            // obtain it by subtracting xfertime from acctime
            nsecs = currdisk->model->mech->dm_acctime(currdisk->model,
                    &currdisk->mech_state, &pbn, curr->bcount,
                    (curr->flags & READ), currdisk->immed,  //0, // @011
                    0,  // result state
                    &mech_acctimes); // breakdown
//                    0); // breakdown

            nsecs -= currdisk->model->mech->dm_xfertime(currdisk->model,
                    (struct dm_mech_state *) &pbn, curr->bcount);

            tmptime = dm_time_itod(nsecs);
        }
        curr->bcount = tmpblkno;  // TODO hurst_r need to investigate this...save/restore bcount??
        if ((!(curr->flags & READ))
                && (tmptime < currdisk->minimum_seek_delay)) {
            tmptime = currdisk->minimum_seek_delay;
        }
    }
    else { // hurst_r  if nothing else returns maxtime (passed by call) + 1
        tmptime = maxtime + 1.0;
    }

#ifdef DEBUG_DISKCTLR
    fprintf (outputfile, "********** %f: disk_buffer_estimate_servtime  servtime %f, currcyl %d, currhead %d, currangle %u, destcyl %d, desthead %d, destsector %d\n",
            simtime, tmptime, currdisk->mech_state.cyl, currdisk->mech_state.head, currdisk->mech_state.theta, destpbn.cyl, destpbn.head, destpbn.sector );
    fflush(outputfile);
#endif

    return tmptime;
}
/* Possible improvements:  rundelay is not used currently */

static double
disk_buffer_estimate_seektime(
        disk *currdisk,
        ioreq_event *curr,
        int checkcache,
        double maxtime)
{
    double tmptime;
    int hittype = BUFFER_NOMATCH;

#ifdef DEBUG_DISKCTLR
    fprintf (outputfile, "********** %f: disk_buffer_estimate_seektime  const_seektime %d, checkcache %d\n", simtime, currdisk->const_seektime, checkcache );
    fflush(outputfile);
#endif

    if( currdisk->const_seektime ) {
        return currdisk->seektime;
    }

    if(checkcache) {
        int buffer_reading = FALSE;
        hittype = disk_buffer_check_segments(currdisk,curr,&buffer_reading);

        switch(hittype) {
        case BUFFER_APPEND:
            return 0.0;

        case BUFFER_WHOLE:
            if(buffer_reading) {
                return READING_BUFFER_WHOLE_SERVTIME;
            }
            else {
                return BUFFER_WHOLE_SERVTIME;
            }

        case BUFFER_PARTIAL:
            if(buffer_reading) {
                return READING_BUFFER_PARTIAL_SERVTIME;
            }
            else {
                return BUFFER_PARTIAL_SERVTIME;
            }

        default:
            assert(0);
            break;
        }
    }


    {
        dm_time_t nsecs;
        struct dm_pbn pbn;

        currdisk->model->layout->dm_translate_ltop(
                currdisk->model,
                curr->blkno,
                MAP_FULL,
                &pbn,
                0);

        nsecs = currdisk->model->mech->dm_seek_time(
                currdisk->model,
                &currdisk->mech_state,
                (struct dm_mech_state *)&pbn,
                (curr->flags & READ));

        tmptime = dm_time_itod(nsecs);
    }

    if(tmptime < maxtime)
    {
        if( (!(curr->flags & READ)) && (tmptime < currdisk->minimum_seek_delay) )
        {
            tmptime = currdisk->minimum_seek_delay;
        }
    }
    //    else
    //    {
    //        tmptime = maxtime + 1.0;
    //    }

    return tmptime;
}
