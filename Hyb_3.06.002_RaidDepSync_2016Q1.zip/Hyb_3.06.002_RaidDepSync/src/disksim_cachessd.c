/*
 * DiskSim Storage Subsystem Simulation Environment (Version 4.0)
 * Revision Authors: John Bucy, Greg Ganger
 * Contributors: John Griffin, Jiri Schindler, Steve Schlosser
 *
 * Copyright (c) of Carnegie Mellon University, 2001-2008.
 *
 * This software is being provided by the copyright holders under the
 * following license. By obtaining, using and/or copying this software,
 * you agree that you have read, understood, and will comply with the
 * following terms and conditions:
 *
 * Permission to reproduce, use, and prepare derivative works of this
 * software is granted provided the copyright and "No Warranty" statements
 * are included with all reproductions and derivative works and associated
 * documentation. This software may also be redistributed without charge
 * provided that the copyright and "No Warranty" statements are included
 * in all redistributions.
 *
 * NO WARRANTY. THIS SOFTWARE IS FURNISHED ON AN "AS IS" BASIS.
 * CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED AS TO THE MATTER INCLUDING, BUT NOT LIMITED
 * TO: WARRANTY OF FITNESS FOR PURPOSE OR MERCHANTABILITY, EXCLUSIVITY
 * OF RESULTS OR RESULTS OBTAINED FROM USE OF THIS SOFTWARE. CARNEGIE
 * MELLON UNIVERSITY DOES NOT MAKE ANY WARRANTY OF ANY KIND WITH RESPECT
 * TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.
 * COPYRIGHT HOLDERS WILL BEAR NO LIABILITY FOR ANY USE OF THIS SOFTWARE
 * OR DOCUMENTATION.
 *
 */



/*
 * DiskSim Storage Subsystem Simulation Environment (Version 2.0)
 * Revision Authors: Greg Ganger
 * Contributors: Ross Cohen, John Griffin, Steve Schlosser
 *
 * Copyright (c) of Carnegie Mellon University, 1999.
 *
 * Permission to reproduce, use, and prepare derivative works of
 * this software for internal use is granted provided the copyright
 * and "No Warranty" statements are included with all reproductions
 * and derivative works. This software may also be redistributed
 * without charge provided that the copyright and "No Warranty"
 * statements are included in all redistributions.
 *
 * NO WARRANTY. THIS SOFTWARE IS FURNISHED ON AN "AS IS" BASIS.
 * CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED AS TO THE MATTER INCLUDING, BUT NOT LIMITED
 * TO: WARRANTY OF FITNESS FOR PURPOSE OR MERCHANTABILITY, EXCLUSIVITY
 * OF RESULTS OR RESULTS OBTAINED FROM USE OF THIS SOFTWARE. CARNEGIE
 * MELLON UNIVERSITY DOES NOT MAKE ANY WARRANTY OF ANY KIND WITH RESPECT
 * TO FREEDOM FROM PATENT, TRADEMARK, OR COPYRIGHT INFRINGEMENT.
 */

/*
 * DiskSim Storage Subsystem Simulation Environment
 * Authors: Greg Ganger, Bruce Worthington, Yale Patt
 *
 * Copyright (C) 1993, 1995, 1997 The Regents of the University of Michigan
 *
 * This software is being provided by the copyright holders under the
 * following license. By obtaining, using and/or copying this software,
 * you agree that you have read, understood, and will comply with the
 * following terms and conditions:
 *
 * Permission to use, copy, modify, distribute, and sell this software
 * and its documentation for any purpose and without fee or royalty is
 * hereby granted, provided that the full text of this NOTICE appears on
 * ALL copies of the software and documentation or portions thereof,
 * including modifications, that you make.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS," AND COPYRIGHT HOLDERS MAKE NO
 * REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED. BY WAY OF EXAMPLE,
 * BUT NOT LIMITATION, COPYRIGHT HOLDERS MAKE NO REPRESENTATIONS OR
 * WARRANTIES OF MERCHANTABILITY OR FITNESS FOR ANY PARTICULAR PURPOSE OR
 * THAT THE USE OF THE SOFTWARE OR DOCUMENTATION WILL NOT INFRINGE ANY
 * THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS. COPYRIGHT
 * HOLDERS WILL BEAR NO LIABILITY FOR ANY USE OF THIS SOFTWARE OR
 * DOCUMENTATION.
 *
 *  This software is provided AS IS, WITHOUT REPRESENTATION FROM THE
 * UNIVERSITY OF MICHIGAN AS TO ITS FITNESS FOR ANY PURPOSE, AND
 * WITHOUT WARRANTY BY THE UNIVERSITY OF MICHIGAN OF ANY KIND, EITHER
 * EXPRESSED OR IMPLIED, INCLUDING WITHOUT LIMITATION THE IMPLIED
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE REGENTS
 * OF THE UNIVERSITY OF MICHIGAN SHALL NOT BE LIABLE FOR ANY DAMAGES,
 * INCLUDING SPECIAL , INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * WITH RESPECT TO ANY CLAIM ARISING OUT OF OR IN CONNECTION WITH THE
 * USE OF OR IN CONNECTION WITH THE USE OF THE SOFTWARE, EVEN IF IT HAS
 * BEEN OR IS HEREAFTER ADVISED OF THE POSSIBILITY OF SUCH DAMAGES
 *
 * The names and trademarks of copyright holders or authors may NOT be
 * used in advertising or publicity pertaining to the software without
 * specific, written prior permission. Title to copyright in this software
 * and any associated documentation will at all times remain with copyright
 * holders.
 */

#include "modules/modules.h"
#include "disksim_cachessd.h"


static void
cachessd_add_ongoing_request (struct cache_ssd *cache,
			      void *crq)
{
  struct cache_ssd_event *cachereq = (struct cache_ssd_event *)crq;
   cachereq->next = cache->ongoing_requests;
   cachereq->prev = NULL;
   if (cachereq->next) {
      cachereq->next->prev = cachereq;
   }
   cache->ongoing_requests = cachereq;
}


static void
cachessd_remove_ongoing_request (struct cache_ssd *cache,
				 struct cache_ssd_event *cachereq)
{
   if (cachereq->next) {
      cachereq->next->prev = cachereq->prev;
   }
   if (cachereq->prev) {
      cachereq->prev->next = cachereq->next;
   }
   if (cache->ongoing_requests == cachereq) {
      cache->ongoing_requests = cachereq->next;
   }
}


static struct cache_ssd_event * cachessd_find_ongoing_request (struct cache_ssd *cache, ioreq_event *req)
{
   struct cache_ssd_event *tmp = cache->ongoing_requests;

   /* Is this enough to ensure equivalence?? */
   while ((tmp != NULL) && ((req->opid != tmp->req->opid) || (req->blkno != tmp->req->blkno) || (req->bcount != tmp->req->bcount) || (req->buf != tmp->req->buf))) {
      tmp = tmp->next;
   }

   return (tmp);
}


static void
add_to_list(struct cache_ssd *cache,
		cache_ssd_atom* atom)
{
	if(cache->mapping_list == NULL)
	{
		cache->mapping_list = atom;
		cache->mapping_list->next = NULL;
		cache->mapping_list->prev = NULL;
	}
	else
	{
		cache->mapping_list->prev = atom;
		atom->next = cache->mapping_list;
		cache->mapping_list = cache->mapping_list->prev;
	}
}

static cache_ssd_atom*
get_least_valuable_atom(struct cache_ssd *cache)
{
	cache_ssd_atom* temp = cache->mapping_list;
	cache_ssd_atom* least_valuable = NULL;
	float value = 1000.0;
	float temp_value = 0.0;

	while(temp != NULL)
	{
		temp_value = (temp->last_access_time - simtime) * 0.001 + temp->access_frequency;
		if(temp_value < value )
		{
			value = temp_value;
			least_valuable = temp;
		}
		temp = temp->next;
	}
	return least_valuable;
}

static cache_ssd_atom*
remove_last(struct cache_ssd *cache)
{
	cache_ssd_atom* temp = cache->mapping_list;
	while(temp->next != NULL)
	{
		temp = temp->next;
	}
	temp->prev->next = NULL;

	return temp;
}

static void
remove_from_list(struct cache_ssd *cache,
		cache_ssd_atom* atom)
{
	cache_ssd_atom* temp = cache->mapping_list;
	while(temp != NULL)
	{
		if(temp == atom)
		{
			if(temp->next == NULL)
			{
				temp->prev->next = NULL;
			}
			else if(temp->prev == NULL)
			{
				temp = temp->next;
				temp->prev = NULL;
			}
			else
			{
				temp->prev->next = atom->next;
				temp->next->prev = temp->prev;
			}
			break;
		}
		temp = temp->next;
	}
}

static cache_ssd_atom*
get_from_list(struct cache_ssd *cache,
		  ioreq_event* req)
{
	cache_ssd_atom* temp = cache->mapping_list;
	while(temp != NULL)
	{
		if(temp->lba_HDD < req->blkno && temp->lba_HDD + temp->blkno > req->blkno)
		{
			return temp;
		}
		temp = temp->next;
	}
	return NULL;
}

/******************************************************************************************************
 *When there is a write hit on dirty item, then the dirty range needs to be updated
 *****************************************************************************************************/
static void add_valid_block(cache_ssd_atom* temp_atom, LBA_TYPE valid_start, LBA_TYPE valid_end)
{
	ASSERT(temp_atom != NULL);

	if(temp_atom->valid_start > valid_start)
	{
		temp_atom->valid_start = valid_start;
	}
	if(temp_atom->valid_end < valid_end - 1)
	{
		temp_atom->valid_end = valid_end - 1;
	}
}


static cache_ssd_atom*
is_write_hit(struct cache_ssd *cache, ioreq_event* req)
{
	ASSERT(req != NULL);

	LBA_TYPE blkno = req->blkno;
	int bcount = req->bcount;

	cache_ssd_atom* temp_atom = cache->mapping_list;
	while(temp_atom != NULL)
{
		if(temp_atom->valid_start <= blkno && temp_atom->valid_end >= blkno)
		{
			//remove_from_lru_list(cache, temp_atom);
			//add_to_lru_list(cache, temp_atom);
			add_valid_block(temp_atom, blkno, blkno + bcount);
			break;
		}
		temp_atom = temp_atom->next;
	}
	return temp_atom;
}

/******************************************************************************************************
 *THis is to check whether there is still has non-dirty cache item for use
 *****************************************************************************************************/
static int is_free_space_available(struct cache_ssd *cache)
{
	int available = -1;
	int i = 0;

	for (i=0; i<cache->cachemapsize; i++)
	{
		if( !bit_test(cache->validmap,i)) //has space to write
		{
			available = i;
			break;
		}
	}
	return available;
}

/******************************************************************************************************
 *THis is to check whether there is still has non-dirty cache item for use
 *****************************************************************************************************/
static int get_num_free_space_available(struct cache_ssd *cache)
{
	int available = 0;
	int i = 0;

	for (i=0; i<cache->cachemapsize; i++)
	{
		if( !bit_test(cache->validmap,i)) //has space to write
		{
			available++;
		}
	}
	return available;
}

/******************************************************************************************************
 *Cache allocation.
 *All the cache item's parameters need to be initialized
 *****************************************************************************************************/
static cache_ssd_atom*
create_cache_atom(struct cache_ssd *cache, ioreq_event* req, int cache_id)
{
	cache_ssd_atom *created = (cache_ssd_atom *)calloc(1, sizeof( cache_ssd_atom));
	created->lba_SSD = cache_id * cache->cacheblksize;
	created->lba_HDD = req->blkno;
	created->blkno = req->bcount;
	created->last_access_time = simtime; //initialize the access time when it is created
	created->access_frequency = 1; //the access frequency will be 1 when it is initialized

	return created;
}

static cache_ssd_atom*
cache_write_access(struct cache_ssd *cache, ioreq_event* req, int cache_id)
{
	return create_cache_atom(cache, req, cache_id);
}

static cache_ssd_atom*
cachessd_isreadhit(struct cache_ssd *cache,
		  ioreq_event* req)
{
	ASSERT(req != NULL);

	LBA_TYPE blkno = req->blkno;
	int bcount = req->bcount;

	cache_ssd_atom* temp_atom = cache->mapping_list;

	while(temp_atom != NULL)
	{
		if(temp_atom->lba_HDD <= blkno && temp_atom->lba_HDD + temp_atom->blkno - 1 >= blkno)
		{
			temp_atom->last_access_time = simtime;
			temp_atom->access_frequency++;
			break;
		}
		temp_atom = temp_atom->next;
	}
	return temp_atom;
}

static cache_ssd_atom*
cachessd_isreadhit(struct cache_ssd *cache,
		  ioreq_event* req, int &near_sequential_count)
{
	ASSERT(req != NULL);

	LBA_TYPE blkno = req->blkno;
	int bcount = req->bcount;

	cache_ssd_atom* temp_atom = cache->mapping_list;

	int smallest_distance = 1024;
	int current_sequential_count = 0;
	int temp_distance = 0;
	while(temp_atom != NULL)
	{
		if(temp_atom->lba_HDD <= blkno && temp_atom->lba_HDD + temp_atom->blkno - 1 >= blkno)
		{
			temp_atom->last_access_time = simtime;
			temp_atom->access_frequency++;
			break;
		}
		else
		{
			temp_distance = blkno - (temp_atom->lba_HDD + temp_atom->blkno - 1);
			if(temp_distance <= CACHE_HOLE_LIMIT && temp_distance > 0)
			{
				if(current_sequential_count <= temp_atom->access_frequency)
				{
					current_sequential_count = temp_atom->access_frequency;
					temp_atom->access_frequency ++;
				}
			}
		}
		temp_atom = temp_atom->next;
	}
	near_sequential_count = current_sequential_count;
	return temp_atom;
}

static cache_ssd_atom*
cachessd_iswritehit(struct cache_ssd *cache,
		  ioreq_event* req)
{
	cache_ssd_atom* temp_atom = NULL;
	int free_space_avail = 0;

	temp_atom = is_write_hit(cache, req);

	if(temp_atom == NULL)
	{
		free_space_avail = is_free_space_available(cache);
		if(free_space_avail >= 0)
		{
			temp_atom = cache_write_access(cache, req, free_space_avail);
			add_to_list(cache, temp_atom);
			bit_nset (cache->validmap, free_space_avail, free_space_avail);
		}
		else
		{
			temp_atom = NULL;
		}
	}
	return temp_atom;
}

static int
cachessd_handle_read_request(struct cache_ssd *cache,
							 struct cache_ssd_event *readdesc, int &near_sequential_count)
{
	ioreq_event * req = readdesc->req;
	ioreq_event * fillreq = NULL;
	cache_ssd_atom* ret_atom = NULL;
	int ret_val = -1;

	int sequential_count = 0;
	ret_atom = cachessd_isreadhit(cache, req, near_sequential_count);
	if(ret_atom == NULL)
	{
		return CACHESSD_READ_MISS;
	}
	else
	{
		cachessd_add_ongoing_request (cache, readdesc);

		fillreq = ioreq_copy (req);
		fillreq->buf = readdesc;
		fillreq->type = IO_ACCESS_ARRIVE;
		fillreq->blkno = ret_atom->lba_SSD;

		(*cache->issuefunc)(cache->issueparam, fillreq);
	}

    return 0;
}

static int
cachessd_handle_write_request(struct cache_ssd *cache,
							  struct cache_ssd_event *writedesc)
{
	cachessd_add_ongoing_request (cache, writedesc);

	cache_ssd_atom* ret_atom = NULL;
	cache_ssd_atom* temp_atom = NULL;
	int free_space_avail = -1;
	int need_flush = 0;
	//printf("cachessd_handle_write_request\n");
	ret_atom = is_write_hit(cache, writedesc->req);
	if(ret_atom == NULL)
	{
		free_space_avail = get_num_free_space_available(cache);
		if(free_space_avail < 10)
		{
			need_flush = 10 - free_space_avail;
		}
	}

	if(need_flush)
	{
		for (int i=0; i<need_flush; i++)
		{
			//remove_from_list(cache, cache->mapping_list);
			//temp_atom = remove_last(cache);
			temp_atom = get_least_valuable_atom(cache);
			remove_from_list(cache, temp_atom);
			int id = temp_atom->lba_SSD / cache->cacheblksize;
			//printf("Clear cache at id = %d\n", id);
			bit_nclear (cache->validmap, id, id);
		}
	}

	(*writedesc->donefunc)(writedesc->doneparam, writedesc->req);

	return 0;
}

static int
cachessd_get_block(struct cache_if *c,
							  ioreq_event* req,
							  void (**donefunc)(void*, ioreq_event*),
							  void *doneparam)
{
	int retVal = -1;

	struct cache_ssd *cache = (struct cache_ssd *)c;
	struct cache_ssd_event *rwdesc = (struct cache_ssd_event *) getfromextraq();

	rwdesc->type = (req->flags & READ) ? CACHE_EVENT_READ : CACHE_EVENT_WRITE;
	if(req->type == DATA_MIGRATION_INITIALIZE)
	{
		rwdesc->type = CACHE_EVENT_MIGRATION;
	}
    rwdesc->donefunc = donefunc;
    rwdesc->doneparam = doneparam;
    rwdesc->req = req;
    req->next = NULL;
    req->prev = NULL;
    rwdesc->flags = 0;


    //printf("SSD request = %d\n", cache->count);
    cache->count ++;
	if( req->flags & READ)
	{
		int near_sequential_count = -1;
		retVal = cachessd_handle_read_request(cache, rwdesc, near_sequential_count);
		req->near_sequential_count = near_sequential_count;
	}
	else
	{
		retVal = cachessd_handle_write_request(cache, rwdesc);
	}
	return retVal;
}

static void
cachessd_free_block_clean(struct cache_if* c,
						  ioreq_event* req)
{
	struct cache_ssd *cache = (struct cache_ssd *)c;
    struct cache_ssd_event *rwdesc;


    rwdesc = cachessd_find_ongoing_request (cache, req);
    ASSERT (rwdesc != NULL);

    if (rwdesc->type == CACHE_EVENT_READ) {
	   cachessd_remove_ongoing_request (cache, rwdesc);
	   addtoextraq ((event *) rwdesc);
    } else {
	   ASSERT (rwdesc->type == CACHE_EVENT_POPULATE_ALSO);
	   rwdesc->type = CACHE_EVENT_POPULATE_ONLY;
    }
}

static int
cachessd_free_block_dirty(struct cache_if *c,
						  ioreq_event* req,
						  void (**donefunc)(void *, ioreq_event *),
						  void *doneparam)
{
   struct cache_ssd *cache = (struct cache_ssd *)c;
   ioreq_event *flushreq;
   struct cache_ssd_event *writedesc;

   writedesc = cachessd_find_ongoing_request (cache, req);
   ASSERT (writedesc != NULL);
   ASSERT (writedesc->type == CACHE_EVENT_WRITE || writedesc->type == CACHE_EVENT_MIGRATION);

   writedesc->donefunc = donefunc;
   writedesc->doneparam = doneparam;
   writedesc->req = req;
   req->type = IO_REQUEST_ARRIVE;
   req->next = NULL;
   req->prev = NULL;
   //printf("cachessd_free_block_dirty\n");
   cache_ssd_atom *created = cachessd_iswritehit(cache, writedesc->req);
	if(created == NULL)
	{
		ASSERT(0);
	}
	else
	{
		/* For now, just assume both device's store bits at same LBNs */
	   flushreq = ioreq_copy(req);
	   flushreq->type = IO_ACCESS_ARRIVE;
	   flushreq->buf = writedesc;

	   //flushreq->devno = 1;
	   flushreq->blkno = created->lba_SSD;
	   (*cache->issuefunc)(cache->issueparam, flushreq);
	}
	return 0;
}

static int
cachessd_get_maxreqsize (struct cache_if *c)
{
  struct cache_ssd *cache = (struct cache_ssd *)c;
  return(cache->maxreqsize);
}

int cachessd_sync (struct cache_if *c)
{
  return(0);
}

static void*
cachessd_disk_access_complete(struct cache_if *c,
							  ioreq_event* curr)
{
	struct cache_ssd *cache = (struct cache_ssd *)c;
	   struct cache_ssd_event *rwdesc = (struct cache_ssd_event *)curr->buf;
	   cache_ssd_event* next_event = NULL;
	   struct cache_ssd_event *tmp = NULL;
	   int blkno;

	   switch(rwdesc->type) {
	   case CACHE_EVENT_READ:
	      (*rwdesc->donefunc)(rwdesc->doneparam,rwdesc->req);

	      break;
	   case CACHE_EVENT_WRITE:
	      (*rwdesc->donefunc)(rwdesc->doneparam,rwdesc->req);
	         cachessd_remove_ongoing_request (cache, rwdesc);
	         addtoextraq ((event *) rwdesc);
	         cache->bufferspace -= curr->bcount;

	      break;
	   case CACHE_EVENT_MIGRATION:
		   cachessd_remove_ongoing_request (cache, rwdesc);
		   addtoextraq ((event *) rwdesc);
		   cache->bufferspace -= curr->bcount;
		   break;

	   default:
	     ddbg_assert2(0, "Unknown cachedev event type");
	     break;
	   }

	   addtoextraq((event *) curr);

	   /* returned cacheevent will get forwarded to cachedev_wakeup_continue... */
	   return(tmp);
}

static void
cachessd_wakeup_complete (struct cache_if *c,
			  void *d) // really struct cache_dev_event
{

}

static void
cachessd_resetstats (struct cache_if *c)
{

}


void
cachessd_setcallbacks(void)
{
}


static void
cachessd_initialize (struct cache_if *c,
		     void (**issuefunc)(void *,ioreq_event *),
		     void *issueparam,
		     struct ioq * (**queuefind)(void *,int),
		     void *queuefindparam,
		     void (**wakeupfunc)(void *, struct cacheevent *),
		     void *wakeupparam,
		     void (**migrationfunc)(void*, int blkno, int bcount),
		     void *migrationparam,
		     int numdevs)
{
	struct cache_ssd *cache = (struct cache_ssd *)c;
	StaticAssert (sizeof(struct cache_ssd_event) <= DISKSIM_EVENT_SIZE);

	cache->issuefunc = issuefunc;
    cache->issueparam = issueparam;
    cache->queuefind = queuefind;
    cache->queuefindparam = queuefindparam;
    cache->wakeupfunc = wakeupfunc;
    cache->wakeupparam = wakeupparam;
    cache->bufferspace = 0;
    cache->ongoing_requests = NULL;
    cache->count = 0;
}


static void
cachessd_cleanstats (struct cache_if *cache)
{
}


static void
cachessd_printstats (struct cache_if *c, char *prefix)
{

}


static struct cache_if *
cachessd_copy (struct cache_if *c)
{
	return c;
}


static struct cache_if disksim_cache_ssd = {
  cachessd_setcallbacks,
  cachessd_initialize,
  cachessd_resetstats,
  cachessd_printstats,
  cachessd_cleanstats,
  cachessd_copy,
  cachessd_get_block,
  cachessd_free_block_clean,
  cachessd_free_block_dirty,
  cachessd_disk_access_complete,
  cachessd_wakeup_complete,
  cachessd_sync,
  cachessd_get_maxreqsize
};

struct cache_if *disksim_cachessd_loadparams(struct lp_block *b)
{
  int c;
  struct cache_ssd *result;

  result = (cache_ssd *)calloc(1, sizeof(struct cache_ssd));
  result->hdr = disksim_cache_ssd;


  //result->name = b->name ? strdup(b->name) : 0;


  //#include "modules/disksim_cachedev_param.c"
  lp_loadparams(result, b, &disksim_cachessd_mod);

  return (struct cache_if *)result;
}

