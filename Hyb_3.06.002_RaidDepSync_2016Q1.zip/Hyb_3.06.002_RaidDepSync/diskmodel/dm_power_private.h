
#ifndef __DM_POWER_PRIVATE_H_
#define __DM_POWER_PRIVATE_H_


#endif


